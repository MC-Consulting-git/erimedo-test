// eRimedo test environment on Azure. See docs/deploy-azure-test.md.
// Test sizing only: Postgres is reachable from Azure services with a password. Harden before production
// (private networking, Entra authentication for the database, Key Vault).
targetScope = 'resourceGroup'

@description('Short lowercase name used as a prefix, letters and digits only.')
@minLength(3)
@maxLength(12)
param name string = 'erimedotest'

param location string = 'swedencentral'

@description('Full image reference. Empty on the first run: a placeholder image is used until the real one is built.')
param image string = ''

@description('Administrator login of the PostgreSQL server.')
param postgresAdminLogin string = 'erimedoadmin'

@secure()
@description('Administrator password. Use a long random string of letters and digits.')
param postgresAdminPassword string

@description('Token issuer of the identity provider (Entra External ID). Empty = no sign-in, protected endpoints answer 401.')
param authenticationAuthority string = ''

@description('Audience (application id) expected in tokens.')
param authenticationAudience string = ''

@description('Claim that identifies the person. Verify against the real tenant: sub or oid.')
param authenticationSubjectClaim string = 'sub'

@description('Price per entitlement. There is no default price (ADR-0001).')
param walletFeeAmount string = '100'

param walletCurrency string = 'SEK'

@description('Apply database migrations when the app starts. Fine for test, not for production.')
param migrateOnStartup bool = true

var uniq = uniqueString(resourceGroup().id)
var acrName = '${name}${uniq}'
var postgresName = '${name}-pg-${uniq}'
var databaseName = 'erimedo'
var placeholderImage = 'mcr.microsoft.com/k8se/quickstart:latest'
var effectiveImage = empty(image) ? placeholderImage : image
var acrPullRoleId = '7f951dda-4ed3-4680-a7ca-43fe172d538d'

resource logs 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: '${name}-logs'
  location: location
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: acrName
  location: location
  sku: { name: 'Basic' }
  properties: { adminUserEnabled: false }
}

resource identity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: '${name}-id'
  location: location
}

resource acrPull 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(acr.id, identity.id, acrPullRoleId)
  scope: acr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', acrPullRoleId)
    principalId: identity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource postgres 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' = {
  name: postgresName
  location: location
  sku: {
    name: 'Standard_B1ms'
    tier: 'Burstable'
  }
  properties: {
    version: '17'
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
    storage: { storageSizeGB: 32 }
    backup: { backupRetentionDays: 7, geoRedundantBackup: 'Disabled' }
    highAvailability: { mode: 'Disabled' }
    network: { publicNetworkAccess: 'Enabled' }
  }
}

resource database 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: postgres
  name: databaseName
}

// 0.0.0.0 to 0.0.0.0 is Azure's convention for "allow Azure services". Test only.
resource allowAzure 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2024-08-01' = {
  parent: postgres
  name: 'AllowAzureServices'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

resource env 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: '${name}-env'
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logs.properties.customerId
        sharedKey: logs.listKeys().primarySharedKey
      }
    }
  }
}

resource app 'Microsoft.App/containerApps@2024-03-01' = {
  name: '${name}-app'
  location: location
  dependsOn: [acrPull]
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${identity.id}': {} }
  }
  properties: {
    managedEnvironmentId: env.id
    configuration: {
      ingress: {
        external: true
        targetPort: empty(image) ? 80 : 8080
        transport: 'auto'
        allowInsecure: false
      }
      registries: [
        {
          server: acr.properties.loginServer
          identity: identity.id
        }
      ]
      secrets: [
        {
          name: 'db-connection'
          value: 'Host=${postgres.properties.fullyQualifiedDomainName};Database=${databaseName};Username=${postgresAdminLogin};Password=${postgresAdminPassword};SSL Mode=Require'
        }
      ]
    }
    template: {
      containers: [
        {
          name: 'erimedo'
          image: effectiveImage
          resources: { cpu: json('0.5'), memory: '1Gi' }
          env: empty(image) ? [] : [
            // Container Apps terminates TLS in front of the app; trust its forwarded headers.
            { name: 'ASPNETCORE_FORWARDEDHEADERS_ENABLED', value: 'true' }
            { name: 'ConnectionStrings__Erimedo', secretRef: 'db-connection' }
            { name: 'Database__MigrateOnStartup', value: string(migrateOnStartup) }
            { name: 'Wallet__Purchase__FeeAmount', value: walletFeeAmount }
            { name: 'Wallet__Purchase__Currency', value: walletCurrency }
            { name: 'Authentication__Authority', value: authenticationAuthority }
            { name: 'Authentication__Audience', value: authenticationAudience }
            { name: 'Authentication__SubjectClaim', value: authenticationSubjectClaim }
          ]
          probes: empty(image) ? [] : [
            {
              type: 'Liveness'
              httpGet: { path: '/health', port: 8080 }
              periodSeconds: 30
            }
            {
              type: 'Readiness'
              httpGet: { path: '/health', port: 8080 }
              periodSeconds: 10
            }
          ]
        }
      ]
      scale: { minReplicas: 1, maxReplicas: 1 }
    }
  }
}

output acrName string = acr.name
output acrLoginServer string = acr.properties.loginServer
output appName string = app.name
output appUrl string = 'https://${app.properties.configuration.ingress.fqdn}'
output postgresServer string = postgres.properties.fullyQualifiedDomainName

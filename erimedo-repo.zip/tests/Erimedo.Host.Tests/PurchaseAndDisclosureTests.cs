using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Wallet.Contracts;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using Xunit;

namespace Erimedo.Host.Tests;

/// <summary>
/// The whole path through the real wiring: money in the wallet, a purchase, then disclosure of contact details.
/// There is no public way to top up a wallet or create a profile yet (payment provider and Identity are not
/// built), so these tests seed those rows with SQL.
/// </summary>
[Collection(HostCollection.Name)]
public sealed class PurchaseAndDisclosureTests(HostFixture host)
{
    private readonly Guid _organization = Guid.NewGuid();
    private readonly Guid _buyer = Guid.NewGuid();
    private readonly string _run = Guid.NewGuid().ToString("N");
    private Guid _profile;

    private async Task<NpgsqlCommand> CommandAsync(string sql, params (string Name, object Value)[] parameters)
    {
        var connection = new NpgsqlConnection(host.ConnectionString);
        await connection.OpenAsync();
        var command = new NpgsqlCommand(sql, connection);
        foreach (var (name, value) in parameters)
        {
            command.Parameters.AddWithValue(name, value);
        }

        return command;
    }

    private async Task SeedProfileAsync()
    {
        _profile = Guid.NewGuid();
        await using var command = await CommandAsync(
            "INSERT INTO profiles.consultant_profiles (\"Id\", \"IsPublished\", \"ContactFullName\", \"ContactEmail\", \"ContactPhone\") VALUES (@id, true, 'Test Consultant', @email, '+46700000000')",
            ("id", _profile), ("email", $"{_run}@example.test"));
        await command.ExecuteNonQueryAsync();
    }

    private async Task TopUpAsync(decimal amount)
    {
        var transaction = Guid.NewGuid();
        await using var command = await CommandAsync(
            """
            INSERT INTO wallet.ledger_transactions ("Id", "IdempotencyKey", "PostedAt", "Reference") VALUES (@t, @key, now(), 'test top-up');
            INSERT INTO wallet.ledger_lines ("Id", "TransactionId", "Position", "AccountCode", "AccountKind", "Direction", "Amount", "Currency")
            VALUES (gen_random_uuid(), @t, 0, @clearing, 'PaymentClearing', 'Debit', @amount, 'SEK'),
                   (gen_random_uuid(), @t, 1, @wallet, 'CustomerWallet', 'Credit', @amount, 'SEK');
            """,
            ("t", transaction), ("key", $"{_run}-top"), ("clearing", $"clearing:{_run}"),
            ("wallet", $"wallet:{_organization:N}"), ("amount", amount));
        await command.ExecuteNonQueryAsync();
    }

    private async Task<DisclosureRequest> InitAsync(decimal funds)
    {
        await SeedProfileAsync();
        await TopUpAsync(funds);
        return new DisclosureRequest(_organization, _buyer, _profile);
    }

    [Fact]
    public async Task Without_a_purchase_the_details_are_not_disclosed()
    {
        var request = await InitAsync(1000m);
        await using var scope = host.Services.CreateAsyncScope();

        var result = await scope.ServiceProvider.GetRequiredService<IContactDisclosureService>()
            .DiscloseAsync(request, default);

        Assert.Equal("disclosure.no_entitlement", result.Error!.Code);
    }

    [Fact]
    public async Task After_a_purchase_the_details_are_disclosed_under_that_entitlement()
    {
        var request = await InitAsync(1000m);
        await using var scope = host.Services.CreateAsyncScope();
        var purchase = await scope.ServiceProvider.GetRequiredService<IEntitlementService>()
            .PurchaseAsync(new PurchaseEntitlementRequest(_organization, _buyer, _profile, $"{_run}-buy"), default);
        Assert.True(purchase.IsSuccess);

        await using var disclosureScope = host.Services.CreateAsyncScope();
        var result = await disclosureScope.ServiceProvider.GetRequiredService<IContactDisclosureService>()
            .DiscloseAsync(request, default);

        Assert.True(result.IsSuccess);
        Assert.Equal($"{_run}@example.test", result.Value.Email);
        Assert.Equal(purchase.Value.ExpiresAt, result.Value.AccessExpiresAt);

        await using var command = await CommandAsync(
            "SELECT \"EntitlementId\" FROM profiles.disclosure_audit WHERE \"ConsultantProfileId\" = @p", ("p", _profile));
        var audited = (Guid?)await command.ExecuteScalarAsync();
        Assert.Equal(purchase.Value.EntitlementId, audited);
    }

    [Fact]
    public async Task Another_organization_does_not_get_the_details()
    {
        var request = await InitAsync(1000m);
        await using var scope = host.Services.CreateAsyncScope();
        await scope.ServiceProvider.GetRequiredService<IEntitlementService>()
            .PurchaseAsync(new PurchaseEntitlementRequest(_organization, _buyer, _profile, $"{_run}-buy"), default);

        await using var otherScope = host.Services.CreateAsyncScope();
        var result = await otherScope.ServiceProvider.GetRequiredService<IContactDisclosureService>()
            .DiscloseAsync(request with { OrganizationId = Guid.NewGuid() }, default);

        Assert.Equal("disclosure.no_entitlement", result.Error!.Code);
    }

    [Fact]
    public async Task When_the_access_window_has_passed_the_details_are_no_longer_disclosed()
    {
        var request = await InitAsync(1000m);
        await using var scope = host.Services.CreateAsyncScope();
        await scope.ServiceProvider.GetRequiredService<IEntitlementService>()
            .PurchaseAsync(new PurchaseEntitlementRequest(_organization, _buyer, _profile, $"{_run}-buy"), default);

        host.Time.Advance(TimeSpan.FromDays(31));
        try
        {
            await using var later = host.Services.CreateAsyncScope();
            var result = await later.ServiceProvider.GetRequiredService<IContactDisclosureService>()
                .DiscloseAsync(request, default);

            Assert.Equal("disclosure.no_entitlement", result.Error!.Code);
        }
        finally
        {
            host.Time.Advance(TimeSpan.FromDays(-31));
        }
    }
}

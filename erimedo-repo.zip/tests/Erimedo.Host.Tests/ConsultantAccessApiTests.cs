using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Erimedo.Modules.Identity.Contracts;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using Xunit;

namespace Erimedo.Host.Tests;

/// <summary>Authorization through the real HTTP pipeline: who may buy and who may read contact details.</summary>
[Collection(HostCollection.Name)]
public sealed class ConsultantAccessApiTests(HostFixture host)
{
    private readonly string _run = Guid.NewGuid().ToString("N");
    private readonly Guid _organization = Guid.NewGuid();

    private async Task ExecuteAsync(string sql, params (string Name, object Value)[] parameters)
    {
        await using var connection = new NpgsqlConnection(host.ConnectionString);
        await connection.OpenAsync();
        await using var command = new NpgsqlCommand(sql, connection);
        foreach (var (name, value) in parameters)
        {
            command.Parameters.AddWithValue(name, value);
        }

        await command.ExecuteNonQueryAsync();
    }

    private async Task<Guid> SeedProfileAsync()
    {
        var id = Guid.NewGuid();
        await ExecuteAsync(
            "INSERT INTO profiles.consultant_profiles (\"Id\", \"IsPublished\", \"ContactFullName\", \"ContactEmail\", \"ContactPhone\") VALUES (@id, true, 'Test Consultant', @email, '+46700000000')",
            ("id", id), ("email", $"{_run}@example.test"));
        return id;
    }

    private Task TopUpAsync(Guid organization, decimal amount) => ExecuteAsync(
        """
        INSERT INTO wallet.ledger_transactions ("Id", "IdempotencyKey", "PostedAt", "Reference") VALUES (@t, @key, now(), 'test top-up');
        INSERT INTO wallet.ledger_lines ("Id", "TransactionId", "Position", "AccountCode", "AccountKind", "Direction", "Amount", "Currency")
        VALUES (gen_random_uuid(), @t, 0, @clearing, 'PaymentClearing', 'Debit', @amount, 'SEK'),
               (gen_random_uuid(), @t, 1, @wallet, 'CustomerWallet', 'Credit', @amount, 'SEK');
        """,
        ("t", Guid.NewGuid()), ("key", $"{_run}-top-{organization:N}"), ("clearing", $"clearing:{_run}"),
        ("wallet", $"wallet:{organization:N}"), ("amount", amount));

    private async Task<string> SignedUpAsync(Guid organization, params MembershipRole[] roles)
    {
        var subject = $"sub-{Guid.NewGuid():N}";
        await using var scope = host.Api.Services.CreateAsyncScope();
        var person = await scope.ServiceProvider.GetRequiredService<IPersonDirectory>().GetOrCreatePersonAsync(subject, default);
        var memberships = scope.ServiceProvider.GetRequiredService<IMembershipService>();
        foreach (var role in roles)
        {
            Assert.True((await memberships.GrantRoleAsync(person, organization, role, default)).IsSuccess);
        }

        return subject;
    }

    private HttpClient ClientFor(string? subject)
    {
        var client = host.Api.CreateClient();
        if (subject is not null)
        {
            client.DefaultRequestHeaders.Add(TestAuthHandler.Header, subject);
        }

        return client;
    }

    private static HttpRequestMessage Purchase(Guid profile, string? key, object? body = null)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, $"/api/consultants/{profile}/purchase");
        if (key is not null)
        {
            request.Headers.Add("Idempotency-Key", key);
        }

        if (body is not null)
        {
            request.Content = JsonContent.Create(body);
        }

        return request;
    }

    private static async Task<string?> CodeAsync(HttpResponseMessage response) =>
        JsonDocument.Parse(await response.Content.ReadAsStringAsync()).RootElement.GetProperty("code").GetString();

    [Fact]
    public async Task Anonymous_callers_get_401()
    {
        var profile = await SeedProfileAsync();
        using var client = ClientFor(null);

        Assert.Equal(HttpStatusCode.Unauthorized, (await client.GetAsync($"/api/consultants/{profile}/contact")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await client.SendAsync(Purchase(profile, "k"))).StatusCode);
    }

    [Fact]
    public async Task A_signed_in_person_without_membership_gets_403()
    {
        var profile = await SeedProfileAsync();
        using var client = ClientFor($"sub-{Guid.NewGuid():N}");

        var response = await client.GetAsync($"/api/consultants/{profile}/contact");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("authorization.forbidden", await CodeAsync(response));
    }

    [Fact]
    public async Task A_member_without_the_buyer_role_cannot_buy_or_read()
    {
        var profile = await SeedProfileAsync();
        await TopUpAsync(_organization, 1000m);
        using var client = ClientFor(await SignedUpAsync(_organization, MembershipRole.Consultant));

        Assert.Equal(HttpStatusCode.Forbidden, (await client.SendAsync(Purchase(profile, $"{_run}-a"))).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await client.GetAsync($"/api/consultants/{profile}/contact")).StatusCode);
    }

    [Fact]
    public async Task Buying_requires_an_idempotency_key()
    {
        var profile = await SeedProfileAsync();
        using var client = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));

        var response = await client.SendAsync(Purchase(profile, null));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("purchase.idempotency_key_required", await CodeAsync(response));
    }

    [Fact]
    public async Task A_buyer_with_funds_buys_and_then_reads_the_details_with_no_store()
    {
        var profile = await SeedProfileAsync();
        await TopUpAsync(_organization, 1000m);
        using var client = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));

        Assert.Equal(HttpStatusCode.Forbidden, (await client.GetAsync($"/api/consultants/{profile}/contact")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await client.SendAsync(Purchase(profile, $"{_run}-buy"))).StatusCode);

        var contact = await client.GetAsync($"/api/consultants/{profile}/contact");

        Assert.Equal(HttpStatusCode.OK, contact.StatusCode);
        Assert.Contains("no-store", contact.Headers.CacheControl!.ToString());
        Assert.Contains($"{_run}@example.test", await contact.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task A_colleague_in_the_same_organization_may_read_what_was_bought()
    {
        var profile = await SeedProfileAsync();
        await TopUpAsync(_organization, 1000m);
        using var buyer = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));
        using var colleague = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));
        await buyer.SendAsync(Purchase(profile, $"{_run}-buy"));

        Assert.Equal(HttpStatusCode.OK, (await colleague.GetAsync($"/api/consultants/{profile}/contact")).StatusCode);
    }

    [Fact]
    public async Task A_buyer_in_another_organization_is_refused()
    {
        var profile = await SeedProfileAsync();
        await TopUpAsync(_organization, 1000m);
        using var buyer = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));
        using var outsider = ClientFor(await SignedUpAsync(Guid.NewGuid(), MembershipRole.Buyer));
        await buyer.SendAsync(Purchase(profile, $"{_run}-buy"));

        var response = await outsider.GetAsync($"/api/consultants/{profile}/contact");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("disclosure.no_entitlement", await CodeAsync(response));
    }

    [Fact]
    public async Task Insufficient_funds_give_402()
    {
        var profile = await SeedProfileAsync();
        using var client = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));

        var response = await client.SendAsync(Purchase(profile, $"{_run}-poor"));

        Assert.Equal(HttpStatusCode.PaymentRequired, response.StatusCode);
    }

    [Fact]
    public async Task An_organization_id_sent_by_the_client_is_ignored()
    {
        var profile = await SeedProfileAsync();
        var victim = Guid.NewGuid();
        await TopUpAsync(victim, 1000m);
        await TopUpAsync(_organization, 1000m);
        using var client = ClientFor(await SignedUpAsync(_organization, MembershipRole.Buyer));

        var response = await client.SendAsync(Purchase(profile, $"{_run}-spoof", new { organizationId = victim }));

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        await using var connection = new NpgsqlConnection(host.ConnectionString);
        await connection.OpenAsync();
        await using var command = new NpgsqlCommand(
            "SELECT count(*) FROM wallet.entitlements WHERE \"OrganizationId\" = @o", connection);
        command.Parameters.AddWithValue("o", victim);
        var forVictim = (long)(await command.ExecuteScalarAsync())!;
        command.Parameters["o"].Value = _organization;
        var forOwn = (long)(await command.ExecuteScalarAsync())!;
        Assert.Equal(0L, forVictim);
        Assert.Equal(1L, forOwn);
    }
}

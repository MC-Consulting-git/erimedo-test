using Erimedo.Host.Composition;
using Erimedo.TestSupport;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Erimedo.Host.Tests;

/// <summary>PostgreSQL plus the application's real service registration with every module migrated.</summary>
public sealed class HostFixture : PostgresServer
{
    public static readonly DateTimeOffset Start = new(2026, 11, 23, 12, 0, 0, TimeSpan.Zero);

    public ManualTimeProvider Time { get; } = new(Start);

    public ServiceProvider Services { get; private set; } = null!;

    /// <summary>The real application over HTTP, with sign-in replaced by a test scheme (header X-Test-Subject).</summary>
    public WebApplicationFactory<Program> Api { get; private set; } = null!;

    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();

        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:Erimedo"] = ConnectionString,
                ["Wallet:Purchase:FeeAmount"] = "100",
                ["Wallet:Purchase:Currency"] = "SEK",
            })
            .Build();

        var services = new ServiceCollection();
        services.AddSingleton<TimeProvider>(Time);
        services.AddErimedoModules(configuration);
        Services = services.BuildServiceProvider(validateScopes: true);

        await ServiceRegistration.MigrateModulesAsync(Services, CancellationToken.None);

        Api = new TestApiFactory(ConnectionString);
        _ = Api.Server; // start the host so migrations have run before the tests
    }

    public override async Task DisposeAsync()
    {
        await Api.DisposeAsync();
        await Services.DisposeAsync();
        await base.DisposeAsync();
    }
}

[CollectionDefinition(Name)]
public sealed class HostCollection : ICollectionFixture<HostFixture>
{
    public const string Name = "host";
}

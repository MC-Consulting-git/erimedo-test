using Erimedo.Modules.Identity.Contracts;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Erimedo.Identity.Tests;

[Collection(IdentityCollection.Name)]
public sealed class MembershipTests(IdentityFixture fixture)
{
    private Task<Guid> NewPersonAsync() =>
        fixture.InScopeAsync(sp => sp.GetRequiredService<IPersonDirectory>().GetOrCreatePersonAsync($"sub-{Guid.NewGuid():N}", default));

    private Task<T> WithMembershipsAsync<T>(Func<IMembershipService, Task<T>> action) =>
        fixture.InScopeAsync(sp => action(sp.GetRequiredService<IMembershipService>()));

    private Task<T> WithAuthorizerAsync<T>(Func<IMembershipAuthorizer, Task<T>> action) =>
        fixture.InScopeAsync(sp => action(sp.GetRequiredService<IMembershipAuthorizer>()));

    [Fact]
    public async Task The_same_subject_always_gives_the_same_person()
    {
        var subject = $"sub-{Guid.NewGuid():N}";
        var first = await fixture.InScopeAsync(sp => sp.GetRequiredService<IPersonDirectory>().GetOrCreatePersonAsync(subject, default));
        var second = await fixture.InScopeAsync(sp => sp.GetRequiredService<IPersonDirectory>().GetOrCreatePersonAsync(subject, default));
        Assert.Equal(first, second);
    }

    [Fact]
    public async Task Concurrent_first_sign_ins_create_one_person()
    {
        var subject = $"sub-{Guid.NewGuid():N}";
        var ids = await Task.WhenAll(Enumerable.Range(0, 10).Select(_ =>
            fixture.InScopeAsync(sp => sp.GetRequiredService<IPersonDirectory>().GetOrCreatePersonAsync(subject, default))));
        Assert.Single(ids.Distinct());
    }

    [Fact]
    public async Task A_person_without_membership_is_refused()
    {
        var person = await NewPersonAsync();
        var result = await WithAuthorizerAsync(a => a.RequireRoleAsync(person, MembershipRole.Buyer, default));
        Assert.Equal("authorization.forbidden", result.Error!.Code);
    }

    [Fact]
    public async Task A_granted_role_gives_access_to_the_membership_organization()
    {
        var person = await NewPersonAsync();
        var organization = Guid.NewGuid();
        Assert.True((await WithMembershipsAsync(m => m.GrantRoleAsync(person, organization, MembershipRole.Buyer, default))).IsSuccess);

        var result = await WithAuthorizerAsync(a => a.RequireRoleAsync(person, MembershipRole.Buyer, default));

        Assert.True(result.IsSuccess);
        Assert.Equal(organization, result.Value.OrganizationId);
        Assert.Equal(person, result.Value.PersonId);
    }

    [Fact]
    public async Task A_missing_role_gives_the_same_failure_as_no_membership()
    {
        var person = await NewPersonAsync();
        await WithMembershipsAsync(m => m.GrantRoleAsync(person, Guid.NewGuid(), MembershipRole.Consultant, default));
        var stranger = await NewPersonAsync();

        var noRole = await WithAuthorizerAsync(a => a.RequireRoleAsync(person, MembershipRole.Buyer, default));
        var noMembership = await WithAuthorizerAsync(a => a.RequireRoleAsync(stranger, MembershipRole.Buyer, default));

        Assert.Equal(noMembership.Error, noRole.Error);
    }

    [Fact]
    public async Task A_person_cannot_join_a_second_organization()
    {
        var person = await NewPersonAsync();
        await WithMembershipsAsync(m => m.GrantRoleAsync(person, Guid.NewGuid(), MembershipRole.Buyer, default));

        var result = await WithMembershipsAsync(m => m.GrantRoleAsync(person, Guid.NewGuid(), MembershipRole.Buyer, default));

        Assert.Equal("membership.other_organization", result.Error!.Code);
    }

    [Fact]
    public async Task Granting_for_an_unknown_person_fails()
    {
        var result = await WithMembershipsAsync(m => m.GrantRoleAsync(Guid.NewGuid(), Guid.NewGuid(), MembershipRole.Buyer, default));
        Assert.Equal("membership.person_not_found", result.Error!.Code);
    }

    [Fact]
    public async Task Removing_a_role_that_is_not_held_fails()
    {
        var person = await NewPersonAsync();
        var organization = Guid.NewGuid();
        await WithMembershipsAsync(m => m.GrantRoleAsync(person, organization, MembershipRole.Buyer, default));

        var result = await WithMembershipsAsync(m => m.RevokeRoleAsync(person, organization, MembershipRole.Consultant, default));

        Assert.Equal("membership.role_not_held", result.Error!.Code);
    }

    [Fact]
    public async Task Removing_the_last_role_ends_the_membership()
    {
        var person = await NewPersonAsync();
        var organization = Guid.NewGuid();
        await WithMembershipsAsync(m => m.GrantRoleAsync(person, organization, MembershipRole.Buyer, default));

        Assert.True((await WithMembershipsAsync(m => m.RevokeRoleAsync(person, organization, MembershipRole.Buyer, default))).IsSuccess);

        Assert.Null(await WithMembershipsAsync(m => m.GetMembershipAsync(person, default)));
        // The person is free to join another organization afterwards.
        Assert.True((await WithMembershipsAsync(m => m.GrantRoleAsync(person, Guid.NewGuid(), MembershipRole.Buyer, default))).IsSuccess);
    }

    [Fact]
    public async Task The_last_company_admin_cannot_be_removed()
    {
        var admin = await NewPersonAsync();
        var organization = Guid.NewGuid();
        await WithMembershipsAsync(m => m.GrantRoleAsync(admin, organization, MembershipRole.CompanyAdmin, default));

        var result = await WithMembershipsAsync(m => m.RevokeRoleAsync(admin, organization, MembershipRole.CompanyAdmin, default));

        Assert.Equal("membership.last_admin", result.Error!.Code);
        Assert.NotNull(await WithMembershipsAsync(m => m.GetMembershipAsync(admin, default)));
    }

    [Fact]
    public async Task Two_admins_removed_at_the_same_time_leave_one()
    {
        var first = await NewPersonAsync();
        var second = await NewPersonAsync();
        var organization = Guid.NewGuid();
        await WithMembershipsAsync(m => m.GrantRoleAsync(first, organization, MembershipRole.CompanyAdmin, default));
        await WithMembershipsAsync(m => m.GrantRoleAsync(second, organization, MembershipRole.CompanyAdmin, default));

        var results = await Task.WhenAll(
            WithMembershipsAsync(m => m.RevokeRoleAsync(first, organization, MembershipRole.CompanyAdmin, default)),
            WithMembershipsAsync(m => m.RevokeRoleAsync(second, organization, MembershipRole.CompanyAdmin, default)));

        Assert.Equal(1, results.Count(r => r.IsSuccess));
        Assert.Equal(1, results.Count(r => !r.IsSuccess));
    }
}

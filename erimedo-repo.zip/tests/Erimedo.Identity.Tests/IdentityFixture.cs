using Erimedo.Modules.Identity;
using Erimedo.TestSupport;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Erimedo.Identity.Tests;

public sealed class IdentityFixture : PostgresServer
{
    public ServiceProvider Services { get; private set; } = null!;

    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["ConnectionStrings:Erimedo"] = ConnectionString })
            .Build();
        var services = new ServiceCollection();
        services.AddSingleton(TimeProvider.System);
        services.AddIdentityModule(configuration);
        Services = services.BuildServiceProvider(validateScopes: true);
        await IdentityModule.MigrateDatabaseAsync(Services, CancellationToken.None);
    }

    public override async Task DisposeAsync()
    {
        await Services.DisposeAsync();
        await base.DisposeAsync();
    }

    public async Task<T> InScopeAsync<T>(Func<IServiceProvider, Task<T>> action)
    {
        await using var scope = Services.CreateAsyncScope();
        return await action(scope.ServiceProvider);
    }
}

[CollectionDefinition(Name)]
public sealed class IdentityCollection : ICollectionFixture<IdentityFixture>
{
    public const string Name = "identity";
}

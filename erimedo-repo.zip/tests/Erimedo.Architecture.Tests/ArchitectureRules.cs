using System.Reflection;

namespace Erimedo.Architecture.Tests;

/// <summary>
/// The module-boundary rules from CLAUDE.md section 3, as plain reflection checks that return violations.
/// Kept free of test-framework types so they are easy to reuse and read.
/// </summary>
public static class ArchitectureRules
{
    public static readonly string[] ModuleNames =
    [
        "Identity", "Organizations", "Profiles", "Taxonomy", "Matching",
        "Needs", "Wallet", "Reviews", "Notifications", "Content",
    ];

    /// <summary>Shared is a small kernel. If it grows past this, move logic into a module.</summary>
    public const int MaxSharedPublicTypes = 15;

    private const string ModulePrefix = "Erimedo.Modules.";
    private const string SharedName = "Erimedo.Shared";
    private const string HostName = "Erimedo.Host";

    public static Assembly LoadModule(string module) => Assembly.Load(ModulePrefix + module);

    public static Assembly LoadShared() => Assembly.Load(SharedName);

    /// <summary>No module may reference another module's assembly. Calls go through contracts or events.</summary>
    public static IReadOnlyList<string> ModulesReferencingOtherModules()
    {
        var violations = new List<string>();
        foreach (var module in ModuleNames)
        {
            var self = ModulePrefix + module;
            foreach (var reference in LoadModule(module).GetReferencedAssemblies())
            {
                var name = reference.Name ?? string.Empty;
                if (name.StartsWith(ModulePrefix, StringComparison.Ordinal) && name != self)
                {
                    violations.Add($"{self} references {name}");
                }
            }
        }

        return violations;
    }

    /// <summary>Neither Shared nor a module may depend on the Host (the composition root).</summary>
    public static IReadOnlyList<string> AssembliesReferencingHost()
    {
        var violations = new List<string>();
        foreach (var assembly in ModuleNames.Select(LoadModule).Append(LoadShared()))
        {
            if (assembly.GetReferencedAssemblies().Any(r => r.Name == HostName))
            {
                violations.Add($"{assembly.GetName().Name} references {HostName}");
            }
        }

        return violations;
    }

    /// <summary>Shared must not know any module.</summary>
    public static IReadOnlyList<string> SharedReferencingModules() =>
        LoadShared().GetReferencedAssemblies()
            .Where(r => r.Name?.StartsWith(ModulePrefix, StringComparison.Ordinal) == true)
            .Select(r => $"{SharedName} references {r.Name}")
            .ToArray();

    /// <summary>A module's only public types are its entry point and anything in its Contracts namespace.</summary>
    public static IReadOnlyList<string> PublicTypesOutsideContracts()
    {
        var violations = new List<string>();
        foreach (var module in ModuleNames)
        {
            var entryPoint = $"{ModulePrefix}{module}.{module}Module";
            var contracts = $"{ModulePrefix}{module}.Contracts";

            foreach (var type in LoadModule(module).GetTypes().Where(t => t.IsVisible))
            {
                var ns = type.Namespace ?? string.Empty;
                // EF Core generates migration classes as public. They are not part of the module's API.
                var isMigration = ns.EndsWith(".Migrations", StringComparison.Ordinal);
                var allowed = type.FullName == entryPoint
                    || ns == contracts
                    || ns.StartsWith(contracts + ".", StringComparison.Ordinal)
                    || isMigration;
                if (!allowed)
                {
                    violations.Add($"{type.FullName} is public but is neither the module entry point nor a contract");
                }
            }
        }

        return violations;
    }

    /// <summary>Keeps Shared tiny.</summary>
    public static IReadOnlyList<string> SharedIsTooBig()
    {
        var count = LoadShared().GetTypes().Count(t => t.IsVisible);
        return count > MaxSharedPublicTypes
            ? [$"{SharedName} has {count} public types; the limit is {MaxSharedPublicTypes}"]
            : [];
    }

    /// <summary>Every module in the rules must actually exist, so a rename cannot silently disable a rule.</summary>
    public static IReadOnlyList<string> MissingModules()
    {
        var missing = new List<string>();
        foreach (var module in ModuleNames)
        {
            try
            {
                LoadModule(module);
            }
            catch (FileNotFoundException)
            {
                missing.Add(ModulePrefix + module);
            }
        }

        return missing;
    }

    private static readonly string[] ContactDataFragments = ["email", "phone", "fullname", "firstname", "lastname", "contactdetail", "cvfile"];

    /// <summary>
    /// Contact details must not appear in search results or list DTOs (CLAUDE.md section 6). Public contract
    /// types may not carry fields that look like contact data. The single exception is <c>ContactDetails</c>,
    /// which is only returned by the disclosure service after an entitlement check and an audit record.
    /// </summary>
    public static IReadOnlyList<string> ContractsExposingContactData()
    {
        var violations = new List<string>();
        foreach (var module in ModuleNames)
        {
            var contracts = $"{ModulePrefix}{module}.Contracts";
            var types = LoadModule(module).GetTypes().Where(t =>
                t.IsVisible && t.Name != "ContactDetails"
                && (t.Namespace == contracts || t.Namespace?.StartsWith(contracts + ".", StringComparison.Ordinal) == true));

            foreach (var type in types)
            {
                var names = type.GetProperties().Select(p => p.Name)
                    .Concat(type.GetConstructors().SelectMany(c => c.GetParameters()).Select(p => p.Name ?? string.Empty))
                    .Concat(type.GetMethods().Where(m => !m.IsSpecialName && m.DeclaringType == type)
                        .SelectMany(m => m.GetParameters()).Select(p => p.Name ?? string.Empty));

                foreach (var name in names.Distinct())
                {
                    if (ContactDataFragments.Any(f => name.Contains(f, StringComparison.OrdinalIgnoreCase)))
                    {
                        violations.Add($"{type.FullName} exposes '{name}', which looks like contact data");
                    }
                }
            }
        }

        return violations;
    }
}

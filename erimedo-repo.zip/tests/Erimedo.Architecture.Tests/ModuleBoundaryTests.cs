using Xunit;

namespace Erimedo.Architecture.Tests;

public class ModuleBoundaryTests
{
    [Fact]
    public void All_modules_in_the_rules_exist() =>
        Assert.Empty(ArchitectureRules.MissingModules());

    [Fact]
    public void Modules_do_not_reference_each_other() =>
        Assert.Empty(ArchitectureRules.ModulesReferencingOtherModules());

    [Fact]
    public void Nothing_but_the_host_references_the_host() =>
        Assert.Empty(ArchitectureRules.AssembliesReferencingHost());

    [Fact]
    public void Shared_does_not_reference_modules() =>
        Assert.Empty(ArchitectureRules.SharedReferencingModules());

    [Fact]
    public void Modules_expose_only_their_entry_point_and_contracts() =>
        Assert.Empty(ArchitectureRules.PublicTypesOutsideContracts());

    [Fact]
    public void Shared_stays_small() =>
        Assert.Empty(ArchitectureRules.SharedIsTooBig());

    [Fact]
    public void Contracts_do_not_carry_contact_data_except_ContactDetails() =>
        Assert.Empty(ArchitectureRules.ContractsExposingContactData());
}

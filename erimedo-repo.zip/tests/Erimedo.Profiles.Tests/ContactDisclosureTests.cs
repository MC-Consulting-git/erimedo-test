using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Profiles.Disclosure;
using Erimedo.Modules.Profiles.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Npgsql;
using Xunit;

namespace Erimedo.Profiles.Tests;

[Collection(ProfilesCollection.Name)]
public sealed class ContactDisclosureTests(ProfilesFixture database)
{
    private static readonly DateTimeOffset Now = new(2026, 11, 23, 12, 0, 0, TimeSpan.Zero);

    private readonly Guid _organization = Guid.NewGuid();
    private readonly Guid _person = Guid.NewGuid();
    private readonly string _email = $"consultant-{Guid.NewGuid():N}@example.test";
    private readonly string _name = $"Test Consultant {Guid.NewGuid():N}";

    private sealed class StubLookup(EntitlementProof? proof) : IEntitlementLookup
    {
        public Task<EntitlementProof?> FindActiveAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken) =>
            Task.FromResult(proof);
    }

    private sealed class FailingSaveInterceptor : SaveChangesInterceptor
    {
        public override ValueTask<InterceptionResult<int>> SavingChangesAsync(
            DbContextEventData eventData, InterceptionResult<int> result, CancellationToken cancellationToken) =>
            throw new InvalidOperationException("the audit record could not be saved");
    }

    private async Task<Guid> SeedProfileAsync(bool published = true)
    {
        var id = Guid.NewGuid();
        await using var db = database.CreateContext();
        db.Profiles.Add(new ProfileRow
        {
            Id = id,
            IsPublished = published,
            ContactFullName = _name,
            ContactEmail = _email,
            ContactPhone = "+46700000000",
        });
        await db.SaveChangesAsync();
        return id;
    }

    private ContactDisclosureService Service(EntitlementProof? proof, ProfilesDbContext? db = null) =>
        new(db ?? database.CreateContext(), new StubLookup(proof), new FixedTime(Now));

    private sealed class FixedTime(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }

    private async Task<List<DisclosureAuditRow>> AuditFor(Guid profile)
    {
        await using var db = database.CreateContext();
        return await db.DisclosureAudit.AsNoTracking().Where(a => a.ConsultantProfileId == profile).ToListAsync();
    }

    [Fact]
    public async Task An_entitled_organization_gets_the_details_and_the_disclosure_is_audited()
    {
        var profile = await SeedProfileAsync();
        var entitlement = new EntitlementProof(Guid.NewGuid(), Now.AddDays(10));

        var result = await Service(entitlement).DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);

        Assert.True(result.IsSuccess);
        Assert.Equal(_name, result.Value.FullName);
        Assert.Equal(_email, result.Value.Email);
        Assert.Equal("+46700000000", result.Value.Phone);
        Assert.Equal(entitlement.ExpiresAt, result.Value.AccessExpiresAt);

        var audit = await AuditFor(profile);
        var row = Assert.Single(audit);
        Assert.Equal(_organization, row.OrganizationId);
        Assert.Equal(_person, row.PersonId);
        Assert.Equal(entitlement.EntitlementId, row.EntitlementId);
        Assert.Equal("contact", row.Kind);
        Assert.Equal(Now, row.DisclosedAt);
    }

    [Fact]
    public async Task The_audit_record_holds_ids_only_and_no_personal_data()
    {
        var profile = await SeedProfileAsync();
        await Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)))
            .DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);

        await using var connection = new NpgsqlConnection(database.ConnectionString);
        await connection.OpenAsync();
        await using var command = new NpgsqlCommand(
            "SELECT row_to_json(a)::text FROM profiles.disclosure_audit a WHERE \"ConsultantProfileId\" = @p", connection);
        command.Parameters.AddWithValue("p", profile);
        var json = (string?)await command.ExecuteScalarAsync();

        Assert.NotNull(json);
        Assert.False(json!.Contains(_email, StringComparison.OrdinalIgnoreCase));
        Assert.False(json.Contains(_name, StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task Without_an_entitlement_nothing_is_disclosed_and_nothing_is_audited()
    {
        var profile = await SeedProfileAsync();

        var result = await Service(proof: null).DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);

        Assert.True(result.IsFailure);
        Assert.Equal("disclosure.no_entitlement", result.Error!.Code);
        Assert.Empty(await AuditFor(profile));
    }

    [Fact]
    public async Task An_unknown_profile_is_not_found()
    {
        var result = await Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)))
            .DiscloseAsync(new DisclosureRequest(_organization, _person, Guid.NewGuid()), default);

        Assert.Equal("disclosure.not_found", result.Error!.Code);
    }

    [Fact]
    public async Task An_unpublished_profile_is_hidden_even_with_an_entitlement()
    {
        var profile = await SeedProfileAsync(published: false);

        var result = await Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)))
            .DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);

        Assert.Equal("disclosure.not_found", result.Error!.Code);
        Assert.Empty(await AuditFor(profile));
    }

    [Fact]
    public async Task Invalid_requests_are_refused()
    {
        var service = Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)));
        var profile = Guid.NewGuid();

        Assert.Equal("disclosure.invalid_request", (await service.DiscloseAsync(new DisclosureRequest(Guid.Empty, _person, profile), default)).Error!.Code);
        Assert.Equal("disclosure.invalid_request", (await service.DiscloseAsync(new DisclosureRequest(_organization, Guid.Empty, profile), default)).Error!.Code);
        Assert.Equal("disclosure.invalid_request", (await service.DiscloseAsync(new DisclosureRequest(_organization, _person, Guid.Empty), default)).Error!.Code);
    }

    [Fact]
    public async Task Every_disclosure_is_audited()
    {
        var profile = await SeedProfileAsync();
        var service = Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)));

        await service.DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);
        await service.DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);

        var count = (await AuditFor(profile)).Count;
        Assert.Equal(2, count);
    }

    [Fact]
    public async Task If_the_audit_record_cannot_be_saved_the_details_are_not_returned()
    {
        var profile = await SeedProfileAsync();
        var service = Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)), database.CreateContext(new FailingSaveInterceptor()));

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            service.DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default));
    }

    [Fact]
    public async Task The_catalog_summary_shows_the_number_and_no_personal_data()
    {
        var profile = await SeedProfileAsync();
        await using var db = database.CreateContext();

        var summary = await new ProfileCatalog(db).GetSummaryAsync(profile, default);

        Assert.NotNull(summary);
        Assert.Equal(profile, summary!.ProfileId);
        Assert.True(summary.ConsultantNumber > 0);
        Assert.True(summary.IsPublished);
        Assert.Null(await new ProfileCatalog(db).GetSummaryAsync(Guid.NewGuid(), default));
    }

    [Fact]
    public async Task The_database_refuses_to_change_recent_audit_records()
    {
        var profile = await SeedProfileAsync();
        await Service(new EntitlementProof(Guid.NewGuid(), Now.AddDays(1)))
            .DiscloseAsync(new DisclosureRequest(_organization, _person, profile), default);
        await using var db = database.CreateContext();

        var update = await Assert.ThrowsAsync<PostgresException>(() =>
            db.Database.ExecuteSqlRawAsync("UPDATE profiles.disclosure_audit SET \"Kind\" = 'x'"));
        var delete = await Assert.ThrowsAsync<PostgresException>(() =>
            db.Database.ExecuteSqlRawAsync("DELETE FROM profiles.disclosure_audit WHERE \"DisclosedAt\" > now() - interval '1 year'"));
        var truncate = await Assert.ThrowsAsync<PostgresException>(() =>
            db.Database.ExecuteSqlRawAsync("TRUNCATE profiles.disclosure_audit"));

        Assert.Contains("append-only", update.MessageText);
        Assert.Contains("append-only", delete.MessageText);
        Assert.Contains("append-only", truncate.MessageText);
    }

    [Fact]
    public async Task Audit_records_older_than_the_two_year_retention_can_be_deleted()
    {
        var id = Guid.NewGuid();
        await using var db = database.CreateContext();
        await db.Database.ExecuteSqlInterpolatedAsync(
            $"INSERT INTO profiles.disclosure_audit (\"Id\", \"ConsultantProfileId\", \"OrganizationId\", \"PersonId\", \"EntitlementId\", \"Kind\", \"DisclosedAt\") VALUES ({id}, {Guid.NewGuid()}, {Guid.NewGuid()}, {Guid.NewGuid()}, {Guid.NewGuid()}, 'contact', now() - interval '3 years')");

        var deleted = await db.Database.ExecuteSqlInterpolatedAsync($"DELETE FROM profiles.disclosure_audit WHERE \"Id\" = {id}");

        Assert.Equal(1, deleted);
    }
}

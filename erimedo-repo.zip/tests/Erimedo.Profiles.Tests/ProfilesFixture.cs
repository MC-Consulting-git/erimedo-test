using Erimedo.Modules.Profiles.Persistence;
using Erimedo.TestSupport;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Erimedo.Profiles.Tests;

/// <summary>PostgreSQL with the Profiles migrations applied. One instance is shared by the whole test project.</summary>
public sealed class ProfilesFixture : PostgresServer
{
    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();
        await using var db = CreateContext();
        await db.Database.MigrateAsync();
    }

    internal ProfilesDbContext CreateContext(params Microsoft.EntityFrameworkCore.Diagnostics.IInterceptor[] interceptors)
    {
        var options = new DbContextOptionsBuilder<ProfilesDbContext>()
            .UseNpgsql(ConnectionString, npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", ProfilesDbContext.Schema))
            .AddInterceptors(interceptors)
            .Options;
        return new ProfilesDbContext(options);
    }
}

[CollectionDefinition(Name)]
public sealed class ProfilesCollection : ICollectionFixture<ProfilesFixture>
{
    public const string Name = "postgres";
}

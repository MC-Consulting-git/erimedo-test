using Testcontainers.PostgreSql;
using Xunit;

namespace Erimedo.TestSupport;

/// <summary>
/// A real PostgreSQL for tests. Starts a Testcontainers container, or uses the database named by
/// ERIMEDO_TEST_POSTGRES when that is set (for machines without Docker). The connection string is
/// never stored in the repository. Derive from it to add module-specific setup, and share one instance
/// per test project through an xUnit collection fixture.
/// </summary>
public class PostgresServer : IAsyncLifetime
{
    private PostgreSqlContainer? _container;

    public string ConnectionString { get; private set; } = string.Empty;

    public virtual async Task InitializeAsync()
    {
        var external = Environment.GetEnvironmentVariable("ERIMEDO_TEST_POSTGRES");
        if (!string.IsNullOrWhiteSpace(external))
        {
            ConnectionString = external;
            return;
        }

        _container = new PostgreSqlBuilder("postgres:17-alpine").Build();
        await _container.StartAsync();
        ConnectionString = _container.GetConnectionString();
    }

    public virtual async Task DisposeAsync()
    {
        if (_container is not null)
        {
            await _container.DisposeAsync();
        }
    }
}

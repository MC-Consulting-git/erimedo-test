using Erimedo.Shared;
using Xunit;

namespace Erimedo.Shared.Tests;

public class MoneyTests
{
    [Fact]
    public void Adds_amounts_in_the_same_currency()
    {
        var sum = Money.Of(100.50m, Currency.Sek) + Money.Of(0.25m, Currency.Sek);

        Assert.Equal(Money.Of(100.75m, Currency.Sek), sum);
    }

    [Fact]
    public void Subtracts_and_negates()
    {
        var difference = Money.Of(10m, Currency.Sek) - Money.Of(25m, Currency.Sek);

        Assert.Equal(Money.Of(-15m, Currency.Sek), difference);
        Assert.Equal(Money.Of(15m, Currency.Sek), -difference);
    }

    [Fact]
    public void Mixing_currencies_is_a_bug_and_throws()
    {
        var threw = false;
        try
        {
            _ = Money.Of(1m, Currency.Sek) + Money.Of(1m, Currency.Eur);
        }
        catch (InvalidOperationException)
        {
            threw = true;
        }

        Assert.True(threw);
    }

    [Fact]
    public void Equal_amounts_compare_equal_regardless_of_trailing_zeros()
    {
        Assert.Equal(Money.Of(1.0m, Currency.Sek), Money.Of(1.00m, Currency.Sek));
    }

    [Fact]
    public void Currency_codes_must_be_three_upper_case_letters()
    {
        Assert.True(Currency.Create("NOK").IsSuccess);
        Assert.True(Currency.Create("nok").IsFailure);
        Assert.True(Currency.Create("NO").IsFailure);
        Assert.True(Currency.Create(null).IsFailure);
    }

    [Fact]
    public void Reading_the_value_of_a_failed_result_is_a_bug_and_throws()
    {
        var failed = Result<int>.Failure("x", "y");
        var threw = false;
        try
        {
            _ = failed.Value;
        }
        catch (InvalidOperationException)
        {
            threw = true;
        }

        Assert.True(threw);
    }
}

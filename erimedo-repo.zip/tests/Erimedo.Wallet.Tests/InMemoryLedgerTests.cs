using Erimedo.Modules.Wallet;

namespace Erimedo.Wallet.Tests;

public sealed class InMemoryLedgerTests : LedgerContractTests
{
    private readonly InMemoryLedger _ledger = new();

    internal override ILedger NewHandle() => _ledger;
}

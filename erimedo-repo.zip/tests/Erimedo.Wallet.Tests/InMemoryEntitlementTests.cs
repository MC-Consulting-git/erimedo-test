using Erimedo.Modules.Wallet;
using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Modules.Wallet.Entitlements;

namespace Erimedo.Wallet.Tests;

public sealed class InMemoryEntitlementTests : EntitlementContractTests
{
    private readonly InMemoryLedger _ledger = new();
    private IEntitlementService? _service;

    internal override (IEntitlementService Service, ILedger Ledger) NewHandle()
    {
        _service ??= new InMemoryEntitlementService(_ledger, Policy, Time);
        return (_service, _ledger);
    }
}

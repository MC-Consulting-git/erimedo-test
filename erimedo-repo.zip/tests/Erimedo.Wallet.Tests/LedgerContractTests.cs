using Erimedo.Modules.Wallet;
using Erimedo.Shared;
using Xunit;

namespace Erimedo.Wallet.Tests;

/// <summary>
/// The ledger rules every implementation must follow. Each test uses its own accounts and keys, so
/// tests can share one database even though the ledger can never be cleared.
/// </summary>
public abstract class LedgerContractTests
{
    private static readonly DateTimeOffset Now = new(2026, 11, 23, 12, 0, 0, TimeSpan.Zero);

    private readonly string _run = Guid.NewGuid().ToString("N");
    private readonly LedgerAccount _wallet;
    private readonly LedgerAccount _clearing;
    private readonly LedgerAccount _revenue;

    protected LedgerContractTests()
    {
        _wallet = new LedgerAccount($"wallet:{_run}", AccountKind.CustomerWallet);
        _clearing = new LedgerAccount($"clearing:{_run}", AccountKind.PaymentClearing);
        _revenue = new LedgerAccount($"revenue:{_run}", AccountKind.Revenue);
    }

    /// <summary>A handle on the ledger. Several handles share the same stored data, like several requests would.</summary>
    internal abstract ILedger NewHandle();

    private static Money Sek(decimal amount) => Money.Of(amount, Currency.Sek);

    private string Key(string name) => $"{_run}-{name}";

    private LedgerTransaction TopUp(string key, decimal amount) =>
        LedgerTransaction.Create(Key(key), Now, "top-up",
        [
            new LedgerLine(_clearing, Direction.Debit, Sek(amount)),
            new LedgerLine(_wallet, Direction.Credit, Sek(amount)),
        ]).Value;

    private LedgerTransaction Purchase(string key, decimal amount) =>
        LedgerTransaction.Create(Key(key), Now, "purchase",
        [
            new LedgerLine(_wallet, Direction.Debit, Sek(amount)),
            new LedgerLine(_revenue, Direction.Credit, Sek(amount)),
        ]).Value;

    [Fact]
    public async Task Top_up_and_purchase_leave_the_expected_balance()
    {
        var ledger = NewHandle();

        Assert.True((await ledger.PostAsync(TopUp("k1", 1000m), default)).IsSuccess);
        Assert.True((await ledger.PostAsync(Purchase("k2", 600m), default)).IsSuccess);

        Assert.Equal(Sek(400m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
        Assert.Equal(Sek(600m), await ledger.BalanceAsync(_revenue, Currency.Sek, default));
        Assert.Equal(Sek(1000m), await ledger.BalanceAsync(_clearing, Currency.Sek, default));
    }

    [Fact]
    public async Task Balance_of_an_account_without_entries_is_zero()
    {
        var balance = await NewHandle().BalanceAsync(_wallet, Currency.Sek, default);

        Assert.Equal(Sek(0m), balance);
    }

    [Fact]
    public void Unbalanced_transaction_is_rejected()
    {
        var result = LedgerTransaction.Create(Key("bad"), Now, "bad",
        [
            new LedgerLine(_clearing, Direction.Debit, Sek(100m)),
            new LedgerLine(_wallet, Direction.Credit, Sek(90m)),
        ]);

        Assert.True(result.IsFailure);
        Assert.Equal("ledger.unbalanced", result.Error!.Code);
    }

    [Fact]
    public void Transaction_needs_an_idempotency_key_two_lines_and_positive_amounts()
    {
        var line = new LedgerLine(_wallet, Direction.Credit, Sek(1m));

        Assert.Equal("ledger.idempotency_key_required", LedgerTransaction.Create(" ", Now, "r", [line, line]).Error!.Code);
        Assert.Equal("ledger.too_few_lines", LedgerTransaction.Create(Key("k"), Now, "r", [line]).Error!.Code);
        Assert.Equal("ledger.amount_not_positive", LedgerTransaction.Create(Key("k"), Now, "r",
        [
            new LedgerLine(_wallet, Direction.Credit, Sek(0m)),
            new LedgerLine(_clearing, Direction.Debit, Sek(0m)),
        ]).Error!.Code);
    }

    [Fact]
    public async Task Retry_with_the_same_key_and_content_posts_once()
    {
        var ledger = NewHandle();

        var first = await ledger.PostAsync(TopUp("same", 500m), default);
        var retry = await NewHandle().PostAsync(TopUp("same", 500m), default);

        Assert.False(first.Value.WasAlreadyPosted);
        Assert.True(retry.Value.WasAlreadyPosted);
        Assert.Equal(first.Value.Transaction.Id, retry.Value.Transaction.Id);
        Assert.Equal(Sek(500m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
        var count = (await ledger.TransactionsForAccountAsync(_wallet, default)).Count;
        Assert.Equal(1, count);
    }

    [Fact]
    public async Task Same_key_with_different_content_is_a_conflict()
    {
        var ledger = NewHandle();
        await ledger.PostAsync(TopUp("same", 500m), default);

        var result = await ledger.PostAsync(TopUp("same", 700m), default);

        Assert.True(result.IsFailure);
        Assert.Equal("ledger.idempotency_conflict", result.Error!.Code);
        Assert.Equal(Sek(500m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
    }

    [Fact]
    public async Task Wallet_cannot_be_overdrawn()
    {
        var ledger = NewHandle();
        await ledger.PostAsync(TopUp("k1", 500m), default);

        var result = await ledger.PostAsync(Purchase("k2", 600m), default);

        Assert.True(result.IsFailure);
        Assert.Equal("wallet.insufficient_funds", result.Error!.Code);
        Assert.Equal(Sek(500m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
        var count = (await ledger.TransactionsForAccountAsync(_wallet, default)).Count;
        Assert.Equal(1, count);
    }

    [Fact]
    public async Task Concurrent_purchases_cannot_overdraw_the_wallet()
    {
        await NewHandle().PostAsync(TopUp("top", 600m), default);

        // Two separate handles, as two web requests would have.
        var attempts = new[] { 0, 1 }.Select(i => Task.Run(() => NewHandle().PostAsync(Purchase($"buy-{i}", 500m), default)));
        var results = await Task.WhenAll(attempts);

        var succeeded = results.Count(r => r.IsSuccess);
        Assert.Equal(1, succeeded);
        Assert.Equal(Sek(100m), await NewHandle().BalanceAsync(_wallet, Currency.Sek, default));
    }

    [Fact]
    public async Task Concurrent_retries_of_the_same_request_post_once()
    {
        var attempts = Enumerable.Range(0, 4).Select(_ => Task.Run(() => NewHandle().PostAsync(TopUp("dup", 250m), default)));
        var results = await Task.WhenAll(attempts);

        Assert.True(results.All(r => r.IsSuccess));
        var posted = results.Count(r => !r.Value.WasAlreadyPosted);
        Assert.Equal(1, posted);
        Assert.Equal(Sek(250m), await NewHandle().BalanceAsync(_wallet, Currency.Sek, default));
    }

    [Fact]
    public async Task Reversal_adds_a_mirror_entry_and_keeps_the_original()
    {
        var ledger = NewHandle();
        await ledger.PostAsync(TopUp("k1", 1000m), default);
        var purchase = (await ledger.PostAsync(Purchase("k2", 600m), default)).Value.Transaction;

        var reversal = await ledger.ReverseAsync(purchase.Id, Key("k3"), Now, default);

        Assert.True(reversal.IsSuccess);
        var count = (await ledger.TransactionsForAccountAsync(_wallet, default)).Count;
        Assert.Equal(3, count);
        Assert.Equal(Sek(1000m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
        Assert.Equal(Sek(0m), await ledger.BalanceAsync(_revenue, Currency.Sek, default));
    }

    [Fact]
    public async Task A_transaction_can_be_reversed_only_once()
    {
        var ledger = NewHandle();
        await ledger.PostAsync(TopUp("k1", 1000m), default);
        var purchase = (await ledger.PostAsync(Purchase("k2", 600m), default)).Value.Transaction;
        await ledger.ReverseAsync(purchase.Id, Key("k3"), Now, default);

        var again = await ledger.ReverseAsync(purchase.Id, Key("k4"), Now, default);
        var retry = await ledger.ReverseAsync(purchase.Id, Key("k3"), Now, default);

        Assert.Equal("ledger.already_reversed", again.Error!.Code);
        Assert.True(retry.Value.WasAlreadyPosted);
        Assert.Equal(Sek(1000m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
    }

    [Fact]
    public async Task Reversing_a_top_up_that_was_already_spent_is_refused()
    {
        var ledger = NewHandle();
        var topUp = (await ledger.PostAsync(TopUp("k1", 1000m), default)).Value.Transaction;
        await ledger.PostAsync(Purchase("k2", 600m), default);

        var result = await ledger.ReverseAsync(topUp.Id, Key("k3"), Now, default);

        Assert.Equal("wallet.insufficient_funds", result.Error!.Code);
        Assert.Equal(Sek(400m), await ledger.BalanceAsync(_wallet, Currency.Sek, default));
    }

    [Fact]
    public async Task Reversing_an_unknown_transaction_fails()
    {
        var result = await NewHandle().ReverseAsync(Guid.NewGuid(), Key("k1"), Now, default);

        Assert.Equal("ledger.not_found", result.Error!.Code);
    }

    [Fact]
    public async Task Statement_lists_transactions_for_the_account_only()
    {
        var ledger = NewHandle();
        await ledger.PostAsync(TopUp("k1", 100m), default);
        var other = new LedgerAccount($"wallet:other-{_run}", AccountKind.CustomerWallet);
        await ledger.PostAsync(LedgerTransaction.Create(Key("k2"), Now, "other top-up",
        [
            new LedgerLine(_clearing, Direction.Debit, Sek(50m)),
            new LedgerLine(other, Direction.Credit, Sek(50m)),
        ]).Value, default);

        var mine = await ledger.TransactionsForAccountAsync(_wallet, default);

        var count = mine.Count;
        Assert.Equal(1, count);
        Assert.Equal(Key("k1"), mine[0].IdempotencyKey);
    }
}

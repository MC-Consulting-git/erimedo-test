using Erimedo.Modules.Wallet;
using Erimedo.Modules.Wallet.Persistence;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using Xunit;

namespace Erimedo.Wallet.Tests;

[Collection(PostgresCollection.Name)]
public sealed class PostgresLedgerTests(PostgresFixture database) : LedgerContractTests
{
    internal override ILedger NewHandle() => new PostgresLedger(database.CreateContext());

    [Fact]
    public async Task The_database_refuses_to_update_a_posted_entry()
    {
        await SeedOneTransactionAsync();
        await using var db = database.CreateContext();

        var error = await Assert.ThrowsAsync<PostgresException>(() =>
            db.Database.ExecuteSqlRawAsync("UPDATE wallet.ledger_lines SET \"Amount\" = \"Amount\" + 1"));

        Assert.Contains("append-only", error.MessageText);
    }

    [Fact]
    public async Task The_database_refuses_to_delete_a_posted_entry()
    {
        await SeedOneTransactionAsync();
        await using var db = database.CreateContext();

        var error = await Assert.ThrowsAsync<PostgresException>(() =>
            db.Database.ExecuteSqlRawAsync("DELETE FROM wallet.ledger_transactions"));

        Assert.Contains("append-only", error.MessageText);
    }

    [Fact]
    public async Task The_database_refuses_to_truncate_the_ledger()
    {
        await SeedOneTransactionAsync();
        await using var db = database.CreateContext();

        var error = await Assert.ThrowsAsync<PostgresException>(() =>
            db.Database.ExecuteSqlRawAsync("TRUNCATE wallet.ledger_lines"));

        Assert.Contains("append-only", error.MessageText);
    }

    [Fact]
    public async Task The_database_refuses_a_line_with_a_non_positive_amount()
    {
        await SeedOneTransactionAsync();
        await using var db = database.CreateContext();

        var error = await Assert.ThrowsAsync<PostgresException>(() => db.Database.ExecuteSqlRawAsync(
            "INSERT INTO wallet.ledger_lines (\"Id\", \"TransactionId\", \"Position\", \"AccountCode\", \"AccountKind\", \"Direction\", \"Amount\", \"Currency\") " +
            "SELECT gen_random_uuid(), \"TransactionId\", 99, 'x', 'Revenue', 'Credit', 0, 'SEK' FROM wallet.ledger_lines LIMIT 1"));

        Assert.Equal("23514", error.SqlState);
    }

    private async Task SeedOneTransactionAsync()
    {
        var run = Guid.NewGuid().ToString("N");
        var wallet = new LedgerAccount($"wallet:{run}", AccountKind.CustomerWallet);
        var clearing = new LedgerAccount($"clearing:{run}", AccountKind.PaymentClearing);
        var amount = Erimedo.Shared.Money.Of(10m, Erimedo.Shared.Currency.Sek);
        var transaction = LedgerTransaction.Create($"seed-{run}", DateTimeOffset.UtcNow, "seed",
        [
            new LedgerLine(clearing, Direction.Debit, amount),
            new LedgerLine(wallet, Direction.Credit, amount),
        ]).Value;

        await NewHandle().PostAsync(transaction, default);
    }
}

using Erimedo.Modules.Wallet.Persistence;
using Erimedo.TestSupport;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Erimedo.Wallet.Tests;

/// <summary>PostgreSQL with the Wallet migrations applied. One instance is shared by the whole test project.</summary>
public sealed class PostgresFixture : PostgresServer
{
    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();
        await using var db = CreateContext();
        await db.Database.MigrateAsync();
    }

    internal WalletDbContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<WalletDbContext>()
            .UseNpgsql(ConnectionString, npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", WalletDbContext.Schema))
            .Options;
        return new WalletDbContext(options);
    }
}

[CollectionDefinition(Name)]
public sealed class PostgresCollection : ICollectionFixture<PostgresFixture>
{
    public const string Name = "postgres";
}

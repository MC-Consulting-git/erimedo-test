using Erimedo.Modules.Wallet;
using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Modules.Wallet.Entitlements;
using Erimedo.Shared;
using Xunit;

namespace Erimedo.Wallet.Tests;

/// <summary>The purchase rules every implementation must follow (ADR-0001, ADR-0006, PUR-08, PUR-27, PUR-42).</summary>
public abstract class EntitlementContractTests
{
    private static readonly DateTimeOffset Start = new(2026, 11, 23, 12, 0, 0, TimeSpan.Zero);

    private readonly string _run = Guid.NewGuid().ToString("N");
    private readonly Guid _organization = Guid.NewGuid();
    private readonly Guid _buyer = Guid.NewGuid();
    private readonly Guid _profile = Guid.NewGuid();

    protected EntitlementContractTests()
    {
        Time = new ManualTimeProvider(Start);
    }

    protected ManualTimeProvider Time { get; }

    internal static PurchasePolicy Policy { get; } = PurchasePolicy.Create(100m, "SEK", 30).Value;

    internal abstract (IEntitlementService Service, ILedger Ledger) NewHandle();

    private static Money Sek(decimal amount) => Money.Of(amount, Currency.Sek);

    private string Key(string name) => $"{_run}-{name}";

    private PurchaseEntitlementRequest Request(string key, Guid? profile = null, Guid? organization = null) =>
        new(organization ?? _organization, _buyer, profile ?? _profile, Key(key));

    private async Task TopUpAsync(decimal amount, string key = "top-up", Guid? organization = null)
    {
        var clearing = new LedgerAccount($"clearing:{_run}", AccountKind.PaymentClearing);
        var wallet = WalletAccounts.For(organization ?? _organization);
        var posted = await NewHandle().Ledger.PostAsync(
            LedgerTransaction.Create(Key(key), Start, "top-up",
            [
                new LedgerLine(clearing, Direction.Debit, Sek(amount)),
                new LedgerLine(wallet, Direction.Credit, Sek(amount)),
            ]).Value, default);
        Assert.True(posted.IsSuccess);
    }

    private Task<Money> BalanceAsync(Guid? organization = null) =>
        NewHandle().Ledger.BalanceAsync(WalletAccounts.For(organization ?? _organization), Currency.Sek, default);

    [Fact]
    public async Task Purchase_charges_the_fee_and_gives_access_for_the_window()
    {
        await TopUpAsync(1000m);
        var (service, _) = NewHandle();

        var result = await service.PurchaseAsync(Request("buy"), default);

        Assert.True(result.IsSuccess);
        Assert.True(result.Value.Charged);
        Assert.False(result.Value.IsReplay);
        Assert.Equal(Start.AddDays(30), result.Value.ExpiresAt);
        Assert.Equal(Sek(900m), await BalanceAsync());
        Assert.True(await service.HasActiveEntitlementAsync(_organization, _profile, default));
    }

    [Fact]
    public async Task Purchase_without_enough_funds_charges_nothing_and_gives_no_access()
    {
        await TopUpAsync(50m);
        var (service, _) = NewHandle();

        var result = await service.PurchaseAsync(Request("buy"), default);

        Assert.True(result.IsFailure);
        Assert.Equal("wallet.insufficient_funds", result.Error!.Code);
        Assert.Equal(Sek(50m), await BalanceAsync());
        Assert.False(await service.HasActiveEntitlementAsync(_organization, _profile, default));
    }

    [Fact]
    public async Task Retry_with_the_same_key_returns_the_original_and_charges_once()
    {
        await TopUpAsync(1000m);

        var first = await NewHandle().Service.PurchaseAsync(Request("buy"), default);
        var retry = await NewHandle().Service.PurchaseAsync(Request("buy"), default);

        Assert.True(retry.IsSuccess);
        Assert.True(retry.Value.IsReplay);
        Assert.Equal(first.Value.EntitlementId, retry.Value.EntitlementId);
        Assert.Equal(Sek(900m), await BalanceAsync());
    }

    [Fact]
    public async Task The_same_key_for_a_different_consultant_is_a_conflict()
    {
        await TopUpAsync(1000m);
        await NewHandle().Service.PurchaseAsync(Request("buy"), default);

        var other = await NewHandle().Service.PurchaseAsync(Request("buy", profile: Guid.NewGuid()), default);

        Assert.True(other.IsFailure);
        Assert.Equal("purchase.idempotency_conflict", other.Error!.Code);
        Assert.Equal(Sek(900m), await BalanceAsync());
    }

    [Fact]
    public async Task Buying_again_while_access_is_active_does_not_charge()
    {
        await TopUpAsync(1000m);
        var first = await NewHandle().Service.PurchaseAsync(Request("buy-1"), default);
        Time.Advance(TimeSpan.FromDays(10));

        var again = await NewHandle().Service.PurchaseAsync(Request("buy-2"), default);

        Assert.True(again.IsSuccess);
        Assert.False(again.Value.Charged);
        Assert.Equal(first.Value.EntitlementId, again.Value.EntitlementId);
        Assert.Equal(first.Value.ExpiresAt, again.Value.ExpiresAt);
        Assert.Equal(Sek(900m), await BalanceAsync());
    }

    [Fact]
    public async Task Access_ends_exactly_at_expiry_and_can_be_bought_again()
    {
        await TopUpAsync(1000m);
        var (service, _) = NewHandle();
        var first = await service.PurchaseAsync(Request("buy-1"), default);

        Time.Advance(TimeSpan.FromDays(30) - TimeSpan.FromSeconds(1));
        Assert.True(await service.HasActiveEntitlementAsync(_organization, _profile, default));

        Time.Advance(TimeSpan.FromSeconds(1));
        Assert.False(await service.HasActiveEntitlementAsync(_organization, _profile, default));

        var again = await service.PurchaseAsync(Request("buy-2"), default);
        Assert.True(again.Value.Charged);
        Assert.False(again.Value.EntitlementId == first.Value.EntitlementId);
        Assert.Equal(Sek(800m), await BalanceAsync());
        Assert.True(await service.HasActiveEntitlementAsync(_organization, _profile, default));
    }

    [Fact]
    public async Task Access_belongs_to_the_buying_organization_only()
    {
        await TopUpAsync(1000m);
        var (service, _) = NewHandle();
        await service.PurchaseAsync(Request("buy"), default);

        Assert.False(await service.HasActiveEntitlementAsync(Guid.NewGuid(), _profile, default));
        Assert.False(await service.HasActiveEntitlementAsync(_organization, Guid.NewGuid(), default));
    }

    [Fact]
    public async Task Invalid_requests_are_refused()
    {
        var (service, _) = NewHandle();

        var noKey = await service.PurchaseAsync(new PurchaseEntitlementRequest(_organization, _buyer, _profile, " "), default);
        var noOrganization = await service.PurchaseAsync(new PurchaseEntitlementRequest(Guid.Empty, _buyer, _profile, Key("x")), default);
        var noProfile = await service.PurchaseAsync(new PurchaseEntitlementRequest(_organization, _buyer, Guid.Empty, Key("x")), default);

        Assert.Equal("purchase.invalid_request", noKey.Error!.Code);
        Assert.Equal("purchase.invalid_request", noOrganization.Error!.Code);
        Assert.Equal("purchase.invalid_request", noProfile.Error!.Code);
    }

    [Fact]
    public async Task Concurrent_purchases_of_the_same_consultant_charge_once()
    {
        await TopUpAsync(1000m);

        var attempts = new[] { "a", "b", "c" }.Select(k => Task.Run(() => NewHandle().Service.PurchaseAsync(Request(k), default)));
        var results = await Task.WhenAll(attempts);

        Assert.True(results.All(r => r.IsSuccess));
        var charged = results.Count(r => r.Value.Charged);
        Assert.Equal(1, charged);
        Assert.Equal(Sek(900m), await BalanceAsync());
    }

    [Fact]
    public async Task Concurrent_purchases_cannot_overdraw_the_wallet()
    {
        await TopUpAsync(150m);

        var attempts = new[] { "a", "b" }.Select(k => Task.Run(() => NewHandle().Service.PurchaseAsync(Request(k, profile: Guid.NewGuid()), default)));
        var results = await Task.WhenAll(attempts);

        var succeeded = results.Count(r => r.IsSuccess);
        Assert.Equal(1, succeeded);
        Assert.Equal(Sek(50m), await BalanceAsync());
    }

    [Fact]
    public async Task One_organizations_funds_are_not_used_by_another()
    {
        var other = Guid.NewGuid();
        await TopUpAsync(1000m, "top-other", other);

        var result = await NewHandle().Service.PurchaseAsync(Request("buy"), default);

        Assert.Equal("wallet.insufficient_funds", result.Error!.Code);
        Assert.Equal(Sek(1000m), await BalanceAsync(other));
    }

    [Fact]
    public async Task The_active_entitlement_can_be_found_until_it_expires()
    {
        await TopUpAsync(1000m);
        var (service, _) = NewHandle();
        var bought = await service.PurchaseAsync(Request("buy"), default);

        var found = await service.FindActiveEntitlementAsync(_organization, _profile, default);
        Assert.NotNull(found);
        Assert.Equal(bought.Value.EntitlementId, found!.EntitlementId);
        Assert.Equal(bought.Value.ExpiresAt, found.ExpiresAt);
        Assert.Null(await service.FindActiveEntitlementAsync(Guid.NewGuid(), _profile, default));

        Time.Advance(TimeSpan.FromDays(30));
        Assert.Null(await service.FindActiveEntitlementAsync(_organization, _profile, default));
    }
}

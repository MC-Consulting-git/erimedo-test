using Erimedo.Modules.Wallet;
using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Modules.Wallet.Entitlements;
using Erimedo.Modules.Wallet.Persistence;
using Erimedo.Shared;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Erimedo.Wallet.Tests;

[Collection(PostgresCollection.Name)]
public sealed class PostgresEntitlementTests(PostgresFixture database)
    : EntitlementContractTests
{
    internal override (IEntitlementService Service, ILedger Ledger) NewHandle()
    {
        var db = database.CreateContext();
        return (new PostgresEntitlementService(db, Policy, Time), new PostgresLedger(db));
    }

    [Fact]
    public async Task A_failed_entitlement_insert_rolls_the_ledger_entries_back()
    {
        var organization = Guid.NewGuid();
        var run = Guid.NewGuid().ToString("N");
        var wallet = WalletAccounts.For(organization);
        var clearing = new LedgerAccount($"clearing:{run}", AccountKind.PaymentClearing);
        var amount = Money.Of(1000m, Currency.Sek);
        var top = LedgerTransaction.Create($"top-{run}", Time.GetUtcNow(), "top-up",
        [
            new LedgerLine(clearing, Direction.Debit, amount),
            new LedgerLine(wallet, Direction.Credit, amount),
        ]).Value;
        await NewHandle().Ledger.PostAsync(top, default);

        // A zero-length window violates the database check on entitlements, after the ledger was written.
        var broken = new PurchasePolicy(Money.Of(100m, Currency.Sek), TimeSpan.Zero);
        await using var db = database.CreateContext();
        var service = new PostgresEntitlementService(db, broken, Time);

        await Assert.ThrowsAsync<DbUpdateException>(() =>
            service.PurchaseAsync(new PurchaseEntitlementRequest(organization, Guid.NewGuid(), Guid.NewGuid(), $"buy-{run}"), default));

        var balance = await NewHandle().Ledger.BalanceAsync(wallet, Currency.Sek, default);
        Assert.Equal(Money.Of(1000m, Currency.Sek), balance);
        var statement = await NewHandle().Ledger.TransactionsForAccountAsync(wallet, default);
        var count = statement.Count;
        Assert.Equal(1, count);
    }
}

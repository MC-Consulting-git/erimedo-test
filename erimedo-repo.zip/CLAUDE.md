# CLAUDE.md — eRimedo

Guidance for AI coding agents and human developers working in this repository.
Keep this file short and current. If a rule here is wrong, fix the rule in the same pull request.

## 1. What we are building

eRimedo is a **direct marketplace for consultants** with no brokers in between.
A buyer states a need (skills, when, where, max rate) and instantly sees matching, available consultants.
**The buyer pays for access to a consultant's CV and contact details.** Consultants and consulting companies use the service for free.

- First vertical: **IT consultants**. The design must not lock us to IT (see section 4).
- Markets: not limited to Sweden. Login, payment, company registry and tax are replaceable per market (section 4).
- Languages: **Swedish and English** from day one, driven by language files (section 7).
- This is a **greenfield rebuild**. Nothing is in production. A 2016 prototype on VirtoCommerce exists, but we reuse only its *functional specification, texts and designs*, never its code or its data model.

## 2. Stack

- .NET (latest LTS, currently .NET 10), C#, nullable reference types on, warnings as errors.
- ASP.NET Core with Blazor (static SSR with interactive components). One language across the stack.
- PostgreSQL as the only data store (relational, full-text, JSONB, distance queries; pgvector later if needed). EF Core for writes, plain SQL/Dapper allowed for read-heavy search.
- Object storage for CV files. Background jobs via a hosted-service queue backed by Postgres.
- Tests: xUnit, Testcontainers (real Postgres), NetArchTest for architecture rules.
- Infrastructure as code. EU region. Containers, managed Postgres, no Kubernetes.

Do **not** introduce: Elasticsearch/Lucene, microservices, a message broker, a custom authentication system, or an e-commerce platform. Ask first if you think one is needed.

## 3. Architecture: modular monolith

One deployable, one database, strict module boundaries.

```
src/
  Erimedo.Host/                 composition root, Blazor UI, endpoints wiring
  Modules/
    Identity/                   accounts, memberships, roles (port: IIdentityProvider)
    Organizations/              companies, invitations, linking requests (port: ICompanyRegistry)
    Profiles/                   consultant profiles, skills, availability, references, documents
    Taxonomy/                   skills per vertical, synonyms, translations, level scales
    Matching/                   the scoring engine (pure, no I/O in the core)
    Needs/                      needs, saved searches, alerts, forwarding to procurement
    Wallet/                     ledger, credits, entitlements (port: IPaymentProvider, ITaxPolicy)
    Reviews/
    Notifications/              e-mail and in-app, localized templates
    Content/                    pages, news, localized
  Shared/                       small kernel only: Result type, Money, ids, clock
infra/                          Bicep for the Azure test environment (docs/deploy-azure-test.md)
tests/
  Erimedo.<Module>.Tests/
  Erimedo.Architecture.Tests/
docs/
  adr/                          one short file per architectural decision
  spec/                         functional specification (from the 2016 prototype)
    README.md                   index, requirement-id and tag legend
    01-roles-and-accounts.md    05-purchase-and-access.md    09-content-localization-legal.md
    02-organizations.md         06-wallet-and-credits.md     10-open-decisions.md
    03-consultant-profile.md    07-reviews-and-references.md 11-prototype-defects.md
    04-search.md                08-notifications.md          12-future.md
```

Rules, enforced by architecture tests:

- A module exposes a small public contract (interfaces + DTOs) and keeps everything else `internal`.
- **No module reads another module's tables or types.** Cross-module calls go through the public contract or in-process integration events.
- Each module owns its own schema in Postgres (`profiles.*`, `wallet.*`, ...) and its own migrations.
- `Shared` stays tiny. Do not put business logic there.

## 4. Replaceable parts (ports and adapters)

The core knows only these interfaces. Concrete providers live in adapter projects and are selected by configuration per market.

| Port | First adapter | Notes |
|---|---|---|
| `IIdentityProvider` | Microsoft Entra External ID with MFA (ADR-0008) | BankID and other eID per market later |
| `IPaymentProvider` | Stripe, card (ADR-0008) | Invoice payment still open (DEC-12). Credits are always booked in *our* ledger |
| `ICompanyRegistry` | Organisation number check against open data (ADR-0007) | Paid registry adapter later; one adapter per country |
| `ITaxPolicy` | Swedish VAT, SEK | EU reverse charge, multi-currency later |

**Verticals are data, not code.** The matching engine works on generic criterion types (skill with level and last-used, rate, availability, location). A vertical supplies a taxonomy, a level scale and optional extra attributes. Adding a vertical must not require changing the engine.

## 5. Domain language

Use these words consistently in code, tables and UI copy.

- **Person**: a login identity. **ConsultantProfile**: what a consultant offers. **Organization**: a company. **Membership**: person-in-organization with a role (`CompanyAdmin`, `Consultant`, `Buyer`).
- **Skill** (from the taxonomy, never free text), with **Level** and **LastUsed** on a profile.
- **Need**: a buyer's structured requirement. A *saved search* is a Need that is stored; it can be shared and forwarded to procurement.
- **Entitlement**: a buyer's/organization's right to see a consultant's contact details and CV, created by a purchase.
- **Ledger**: append-only record of credit movements.
- Only a company admin sets rate and availability, as in the original rules. A consultant who is their own company is their own admin.

## 6. Hard rules (money, access, privacy)

**Ledger and purchases**
- The ledger is append-only and double-entry. Never update or delete a posted entry; correct with a reversing entry.
- Money is `decimal` plus an explicit currency in a `Money` type. Never `double`/`float`.
- Every payment and purchase operation takes an idempotency key.
- A purchase either creates the entitlement and the ledger entries together, or neither (one transaction).

**Contact details**
- Contact details and CV files are returned **only by the server after an entitlement check**. They must never be in a search result, a list DTO, a cache shared across users or client-side state.
- Every disclosure writes an audit record (who, what, when, under which entitlement).
- Reviews can only be written by someone with an entitlement for that consultant, one per reviewer.

**Security and GDPR**
- No secrets, keys or connection strings in the repo. Use configuration and a secret store. (The 2016 prototype committed database credentials; do not repeat that.)
- Authorization is checked on the server for every endpoint and every command, by role and by organization. Never trust ids sent from the client for ownership.
- Never log personal data (names, e-mail, phone, CV content).
- Support data export and account deletion from the start. Define retention per data type in an ADR before storing it.
- Consent is required before processing CVs with an AI model, and only EU-hosted processing is allowed.

## 7. Localization

- Swedish (`sv`) and English (`en`) at launch; adding a language must be a new file, not a code change.
- UI strings live in resource files, never hardcoded. Use ICU-style messages for plurals and dates.
- E-mail templates, content pages, skill names and synonyms are stored per language with a fallback chain (`user language` then `sv` then `en`).
- Format currency, dates and numbers by culture. User-written content (profiles, CVs) is not auto-translated.

## 8. Matching engine

A pure, deterministic, testable function in two steps. No database or HTTP access inside the scoring core.

1. **Hard filters** (SQL): must-have skills, max rate, availability window, part-time, location or remote.
2. **Soft score** per criterion, normalized to 0 to 1, weighted per Need, returned with an **explanation per criterion** that the UI can show (for example "missing Kubernetes", "available 2 weeks later").

Scoring rules (these fix known flaws in the 2016 spreadsheet, which used signed differences and mixed units):

- Penalties are **one-sided**: a cheaper consultant or a more qualified one is never penalised and never gets a bonus that cancels another penalty.
- Rate: penalty only above the buyer's max, capped at 1.
- Skill level: penalty only below the requested level. Missing skill = maximum penalty.
- Last used: penalty grows gradually with time since use (decay curve is configuration).
- Availability: penalty only if available later than requested, scaled over a configurable horizon.
- Distance: between municipality centroids, zero when remote is accepted.
- Weights and curves are configuration, versioned, and stored with each result so a ranking can be reproduced.

Quality gate: a **golden set** of needs and consultants with expected rankings lives in `tests/`. A change to scoring that alters the golden set needs an ADR. Log outcomes (shown, opened, purchased, contacted) so we can calibrate later. Keep the core explainable; do not replace it with an opaque model without a legal review of the EU AI Act implications for ranking people.

## 9. Automation roadmap (context for design choices)

1. Saved searches with alerts in both directions (new consultant matches a need, new need matches an available consultant) and forwarding a need to procurement.
2. CV import with an AI model that *proposes* skills, levels and last-used dates; the consultant confirms. Requires consent.
3. Profile from a LinkedIn link instead of a CV, but contact details always come from our system.
4. Later: incoming requests parsed from e-mail or text, always with a human approving before anything is sent.

## 10. Code conventions

- File-scoped namespaces, `async` all the way with `CancellationToken`, no `.Result`/`.Wait()`.
- No static mutable state. Inject `TimeProvider` instead of calling `DateTime.UtcNow`.
- Prefer simple handlers/services per use case. No generic repository on top of EF Core.
- Validate at the boundary; domain types make invalid states unrepresentable (value objects for `Money`, `Email`, ids).
- Public APIs are small. Default to `internal`.
- Comments explain *why*. Names explain *what*.
- No `catch` that swallows exceptions. Return a `Result` for expected failures; throw for bugs.

## 11. How to work in this repo

- Work in **small vertical slices**: one capability through UI, endpoint, domain, persistence and tests, as one pull request.
- Before saying a task is done: `dotnet build` (zero warnings) and `dotnet test` must pass, including architecture tests.
- Write tests first or together with code for: matching, ledger, entitlements, authorization, anything touching personal data.
- Record each architectural decision as a short ADR in `docs/adr/` (context, decision, consequences).
- Database changes go through migrations in the owning module. Never edit an applied migration.
- Commit messages: imperative mood, one logical change per commit.

**Ask the human before** changing a port interface, the ledger model, authentication or authorization, the schema of personal data, retention rules, or adding a dependency with a non-permissive licence.

**Human review is mandatory** for: identity and authorization code, payments, ledger, entitlement and contact-detail disclosure, GDPR export/deletion, and anything in section 6.

## 12. Commands

Solution file: `Erimedo.slnx`. SDK is pinned in `global.json` (.NET 10).

```
dotnet build Erimedo.slnx        # zero warnings; warnings are errors
dotnet test Erimedo.slnx         # unit, ledger, disclosure, integration and architecture tests; needs Docker for the PostgreSQL tests
dotnet run --project src/Erimedo.Host
docker build -t erimedo .        # image used on Azure; see docs/deploy-azure-test.md
```

Database tests start PostgreSQL with Testcontainers. Without Docker, point `ERIMEDO_TEST_POSTGRES` at a throwaway PostgreSQL database (the ledger cannot be cleared). Authentication: `Authentication:Authority`, `Authentication:Audience`, optional `Authentication:SubjectClaim` (default `sub`); without the first two every protected endpoint answers 401. Configuration for the Wallet module: connection string `ConnectionStrings:Erimedo`, and `Wallet:Purchase:FeeAmount`, `Currency`, `AccessWindowDays` (no default price). Set `Database:MigrateOnStartup=true` in development to apply migrations at start. Add migrations from the module folder: `dotnet ef migrations add <Name> --output-dir Persistence/Migrations`.

Status of the skeleton:
- Done: Shared (`Money`, `Currency`, `Result`), module projects (Wallet, Profiles and Identity have content, seven are empty), Host with a `/health` endpoint, two authorized API endpoints (purchase, contact) and an empty Blazor start page, architecture rules (reflection based), ledger and entitlement purchase in `Wallet`, in memory and in PostgreSQL (ADR-0009, ADR-0010), contact-detail disclosure with audit in `Profiles` (ADR-0011), memberships, roles and server-side authorization with JWT sign-in in `Identity` (ADR-0012), Dockerfile, Bicep and a manual GitHub Actions deploy for an Azure test environment (ADR-0013, not run against a real subscription), all five awaiting review. Build has zero warnings and the 105 tests pass.
- Not done: real UI, Organizations flows (create, link, invite), a real Entra adapter and claim check, CV download, access for the consultant and company admin, profile creation, tax lines, persistence in the other modules, any adapter, NetArchTest (the rules in `tests/Erimedo.Architecture.Tests/ArchitectureRules.cs` are plain reflection and can stay or be ported).
- Each module exposes only `<Module>Module` and types in its `.Contracts` namespace; the architecture tests enforce this. Modules are connected only in `src/Erimedo.Host/Composition/ServiceRegistration.cs`.
- Only `ContactDetails` may carry contact data in a contract; an architecture test enforces it.

## 13. Open decisions (do not assume; ask)

Decided so far: see `docs/adr/` (0001 to 0013). Hosting is Azure, identity is Entra External ID, payment is Stripe, taxonomy is the cleaned prototype list, retention is in ADR-0003.

Still open:
- The exact Azure EU region for production (the test environment uses Sweden Central, ADR-0013).
- Invoice payment for buyers (DEC-12).
- Whether a paid national company registry API is worth using later (check terms).
- Legal review of ranking people under the EU AI Act if we ever move beyond the deterministic engine.
- Remaining defaults in `docs/spec/10-open-decisions.md`.

## 14. Source material

`docs/spec/` holds the functional specification distilled from the 2016 prototype: company linking with approval, invitations, consultant profile with skills/level/last-used, references, CV upload, buyer purchase of access, prepaid company balance, reviews, notification centre and the 12 e-mail types, sv/en content, account deletion. Start with `docs/spec/README.md`. Use it for *what* the system does. Do not copy its code.

How to use the spec:
- Requirements have ids (`ACC-`, `ORG-`, `PRO-`, `SRC-`, `PUR-`, `WAL-` ...). Reference them in tests, ADRs and pull requests.
- Tags: `[Observed]` the prototype does this; `[Intended]` stated in texts or designs; `[Change]` follow this, not the prototype; `[Future]` do not build yet; `[Decision]` open question, **ask the human, do not guess**.
- Open decisions are listed in `docs/spec/10-open-decisions.md`. Record each answer as an ADR.
- Prototype mistakes not to repeat are in `docs/spec/11-prototype-defects.md`. Check them in review.
- If the spec and this file disagree, this file wins; fix the spec in the same pull request.

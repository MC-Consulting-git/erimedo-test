# ADR-0001: Buyer pays a fixed fee per entitlement

Status: Accepted (2026-11-23, decided by Magnus). Resolves DEC-01.

## Context
The 2016 prototype charged the consultant's hourly rate as the price. Marketing texts promised a once-off fee.

## Decision
- The buyer pays a **fixed fee per consultant entitlement**. The amount is configuration per market and currency, versioned, and stored with each purchase.
- The consultant's **hourly rate** is stored separately as `Money` and is used only for filtering and matching. It never sets the price.
- Pricing tiers or percentages are not part of the first version.

## Consequences
- Wallet top-ups and purchases use the fee from configuration (`WAL-*`, `PUR-11`).
- Tax is applied through `ITaxPolicy` on the fee.
- Changing the fee never changes existing entitlements or ledger entries.
- A change to a fee model later (tiers, subscription) needs a new ADR.

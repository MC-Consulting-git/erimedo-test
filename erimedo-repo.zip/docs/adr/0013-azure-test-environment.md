# ADR-0013: Azure test environment

Status: Proposed. Needs human review (infrastructure, secrets handling).

## Context
ADR-0008 chose Azure. We need a place to try the application. The exact production region is still open (CLAUDE.md section 13).

## Decision
- Test environment in **Sweden Central**, described in `infra/main.bicep` (infrastructure as code), deployed by a manually started GitHub Actions workflow using federated credentials (no stored cloud secret).
- Azure Container Apps for the application, Azure Container Registry for the image, PostgreSQL Flexible Server as the only data store. No Kubernetes.
- Configuration is passed as environment variables; the connection string is a Container Apps secret. Nothing secret is in the repository.
- Migrations run at start in test only.
- The region choice applies to the test environment. It does not settle the production region.

## Consequences
- Not production grade: public network access to the database with a password, no Key Vault, one replica, migrations at start, no alerting, no backup restore test.
- The deploying identity needs Owner on the resource group because the template assigns AcrPull.
- Before production: private networking, Key Vault, Entra authentication to the database, a migration bundle step, a decision on region and on separate subscriptions per environment.

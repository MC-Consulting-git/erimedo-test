# ADR-0007: Company lookup, skill taxonomy seed, CV file rules

Status: Accepted (2026-11-23, decided by Magnus). Resolves DEC-06, DEC-07, DEC-08.

## Decisions
- **DEC-06 Company lookup:** The first version asks for the **organisation number**, validates its format (and checksum where the market has one) and, where possible, checks it against **open data**. No paid registry lookup. A paid adapter may be added later behind `ICompanyRegistry` once terms and cost are known.
- **DEC-07 Taxonomy:** Seed from the **cleaned 2016 Swedish skill list**. Each skill gets a stable id, a name in `sv` and `en`, and synonyms. Only the `Skills` branch is used; the prototype's `Levels`, `Last Used`, `Consultants`, `Credits` and `Mobile Rate range` branches are dropped. Countries and regions come from a separate location dataset.
- **DEC-08 Files:** CV and presentation accept **PDF and DOCX, max 10 MB**. Files are **virus-scanned** before they are made available and are stored privately and served only after an entitlement check.

## Consequences
- Company data is no longer read-only registry data (ORG-11): name and address are entered by the user, so a company admin can edit them. The registry check, if any, only confirms the number. A claim to act for a company is still approved by an existing admin (ORG-15), and a mismatch between name and number should be flagged for review.
- Open-data availability and terms must be checked per country before relying on it (CLAUDE.md section 13).
- Cleaning the taxonomy is a task of its own: remove duplicates, merge free-text variants, translate, assign ids. The result needs the owner's review.
- Uploads outside PDF or DOCX, over 10 MB, or failing the scan are rejected with a clear message.

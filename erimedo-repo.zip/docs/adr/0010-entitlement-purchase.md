# ADR-0010: Buying access (entitlement) in one transaction

Status: Proposed. Needs human review (CLAUDE.md section 11: payments, ledger, entitlement).

## Context
ADR-0001 sets a fixed fee per entitlement. ADR-0006 sets the access window (view and download end together). Section 6 requires the entitlement and the ledger entries to be created together or not at all, with an idempotency key.

## Decision
- The Wallet module exposes `IEntitlementService` in `Wallet.Contracts`: `PurchaseAsync` and `HasActiveEntitlementAsync`. Other modules use only this contract.
- An entitlement belongs to an **organization** and a consultant profile, not to a person. Every buyer in the organization shares it (PUR-20). The buying person's id is stored for the audit trail.
- A purchase debits the organization's wallet and credits revenue, then inserts the entitlement, in **one database transaction**. A failed insert rolls back the ledger entries (tested).
- The fee and the window come from configuration (`Wallet:Purchase:FeeAmount`, `Currency`, `AccessWindowDays`, default 30). **There is no default price.** An invalid value stops the application at start-up.
- Access is active while `now < ExpiresAt`. At the expiry instant it has ended.
- A retry with the same key returns the original receipt. The same key for another consultant is a conflict.
- Buying while access is active does **not** charge again and returns the existing entitlement (PUR-27). After expiry a new purchase makes a new entitlement.
- Locks (advisory, per idempotency key, per organization and consultant, per wallet account) serialise concurrent purchases.

## Consequences
- The caller must establish the buyer's organization and Buyer role on the server. This service trusts the ids it is given. That check belongs to Identity and Organizations, which are not built yet.
- Not done: contact-detail disclosure and its audit record, tax lines (`ITaxPolicy`), invoice and card top-ups, refunds (ADR-0004), ending entitlements when a consultant deletes their account (ACC-42), the reviewer check (REV-05).
- A retry of a request that earlier returned "not charged" is evaluated again. If access has expired in between, the retry buys.
- Entitlements are order records and follow the 7-year retention in ADR-0003, minimised.

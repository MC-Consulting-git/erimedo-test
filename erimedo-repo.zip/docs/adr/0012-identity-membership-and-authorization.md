# ADR-0012: Identity, membership and server-side authorization

Status: Proposed. Needs human review (CLAUDE.md section 11: authentication and authorization, schema of personal data).

## Context
Disclosure (ADR-0011) and purchase (ADR-0009, ADR-0010) trust the organization and person ids they are given. Something on the server must establish who the caller is and which organization they act for, and never take that from the client. Sign-in itself is delegated to Microsoft Entra External ID (ADR-0008); we do not build authentication.

## Decision
- The Identity module owns the `identity` schema: `persons` (our pseudonymous id plus the provider's subject, unique), `memberships` (person is the key, so a person belongs to at most one organization, ORG-01) and `membership_roles` (`CompanyAdmin`, `Consultant`, `Buyer`). No name, e-mail or phone is stored here; the identity provider holds them.
- `IPersonDirectory.GetOrCreatePersonAsync` maps the subject to a person id on first sign-in. It is safe under concurrent first sign-ins (tested).
- `IMembershipAuthorizer.RequireRoleAsync(person, role)` is the check behind every command. It returns the person's organization from the server-side membership. A missing membership and a missing role give the same failure `authorization.forbidden`, so the answer does not reveal which.
- `IMembershipService` grants and revokes roles. It refuses a second organization, refuses removing the last company admin (ORG-02), and ends the membership when the last role goes (ORG-03). Advisory locks make concurrent admin removals leave one admin (tested).
- The Host validates bearer tokens (JwtBearer) from `Authentication:Authority` and `Authentication:Audience`. Claim mapping is off. `Authentication:SubjectClaim` names the claim that identifies the person (default `sub`). Without Authority and Audience no token is accepted and protected endpoints answer 401 (fail closed).
- Two endpoints use this: `POST /api/consultants/{id}/purchase` (needs an `Idempotency-Key` header) and `GET /api/consultants/{id}/contact` (`Cache-Control: no-store`). Both require the `Buyer` role. The organization comes from the membership; any organization id in the request is ignored (tested). Error bodies hold a code and a fixed message, no personal data.
- Colleagues with the Buyer role in the same organization share what was bought (PUR-20).

## Consequences
- Not done: creating organizations, linking requests and invitations (Organizations module; today memberships can only be created through `IMembershipService`), access to contact details for the consultant and the company admin (PUR-20 items 1 and 2), export and deletion of identity data (ACC-40), the retention job for `persons`.
- Not verified against a real Entra External ID tenant: the token shape, whether `sub` or `oid` is the stable identifier, and claim names. Choose and test this when the tenant exists. Changing the subject claim later would orphan existing persons.
- Tests use a stand-in authentication scheme (header `X-Test-Subject`), so JWT validation itself is covered only by the framework.
- Authorization is by role and membership only. There is no per-consultant ownership check yet, because no endpoint edits profiles.

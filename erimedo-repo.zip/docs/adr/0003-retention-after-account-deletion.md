# ADR-0003: Retention after account deletion

Status: Accepted (2026-11-23, decided by Magnus). Resolves DEC-04.

## Context
GDPR requires defined retention before personal data is stored. Swedish bookkeeping law requires accounting records for 7 years.

## Decision
| Data | Retention after deletion request or account closure |
|---|---|
| Profile, CV, presentation, contact details, references | Deleted within **30 days** (removed from search immediately) |
| Account and login identity | Deleted within **30 days** |
| Orders, ledger entries, invoices | **7 years**, minimised (no contact details, no CV) |
| Audit records of disclosures | **2 years**, then deleted |
| Reviews | Kept, **anonymised** |
| Notifications | Deleted with the account (30 days) |
| Logs | No personal data is logged (CLAUDE.md section 6); technical logs per hosting default, max 90 days |

## Consequences
- A scheduled background job performs deletion and records that it ran.
- Data export is available before deletion.
- Buyers' entitlements to a deleted consultant end at deletion (ACC-42).
- Any new data type needs a retention line here or in a new ADR before it is stored.
- Figures other than the 7-year rule are our choice and should be checked by someone legally qualified before launch.

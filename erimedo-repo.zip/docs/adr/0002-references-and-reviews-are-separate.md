# ADR-0002: References and reviews are separate concepts

Status: Accepted (confirmed by Magnus 2026-11-23). Resolves DEC-14.

## Context
In the prototype, code lets consultants add reference contacts, while help text describes references as coming from buyers.

## Decision
- **Reviews**: written by buyers with an entitlement, one per reviewer, rating optional.
- **References**: contact persons supplied by the consultant, shown only after purchase, with the consultant's confirmation of consent.

## Consequences
- See `docs/spec/07-reviews-and-references.md`.
- If rejected, drop one of the two; the data model is kept separate so this is cheap.

# ADR-0008: First providers (hosting, identity, payment)

Status: Accepted (2026-11-23, decided by Magnus). Completes DEC-20 together with ADR-0005.

## Decisions
- **Hosting:** Microsoft Azure, an EU region (Sweden or another EU region, to be fixed when the environment is created). Containers on a managed container service, managed PostgreSQL, object storage for files. No Kubernetes.
- **Identity:** Microsoft Entra External ID as the first `IIdentityProvider` adapter, with MFA. BankID or other eID can be added per market later through a partner.
- **Payment:** Stripe as the first `IPaymentProvider` adapter for card payments. Our ledger remains the source of truth.

## Consequences
- The ports stay. Core and modules must not reference Azure, Entra or Stripe types; only adapter projects do.
- **Invoice payment is not covered by the card adapter.** How buyers pay by invoice (own invoicing process, a Stripe feature, or another provider) is still open and tracked as DEC-12.
- Provider terms, pricing, EU data-processing agreements and availability in the target markets must be checked before contracts are signed. This ADR records the intent, not a verified fit.
- Infrastructure is defined as code. No secrets in the repo; use the Azure secret store.
- If a provider later proves unsuitable, replacing it means a new adapter and a new ADR, not a core change.

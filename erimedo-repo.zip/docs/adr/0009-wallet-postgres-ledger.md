# ADR-0009: PostgreSQL ledger in the Wallet module

Status: Proposed. Needs human review (CLAUDE.md section 11: ledger and payments).

## Context
The ledger rules existed only in memory. Persistence must keep the rules in section 6: append-only, double entry, idempotency keys, no overdrawn wallets, one transaction per posting.

## Decision
- The Wallet module owns the `wallet` schema, its own EF Core context and its own migrations (history table `wallet.__ef_migrations`).
- `ILedger` has two implementations with identical rules: `InMemoryLedger` and `PostgresLedger`. One contract test suite runs against both.
- **Append-only is enforced by the database:** triggers reject UPDATE, DELETE and TRUNCATE on the ledger tables. Corrections are reversing entries.
- **Idempotency:** a unique index on the key. A retry with the same content returns the original posting; the same key with different content is a conflict.
- **Concurrency:** each posting runs in one database transaction and takes PostgreSQL advisory locks (per idempotency key, per wallet account, per reversed transaction) in a fixed order. Two purchases cannot spend the same balance.
- **Balance** is derived from the lines, never stored.
- Amounts are `numeric(19,4)`, currency `char(3)`, with a check that amounts are positive.
- The connection string "Erimedo" comes from configuration. Without it the module registers no persistence.
- Tests run against Testcontainers (`postgres:17-alpine`), or against the database in `ERIMEDO_TEST_POSTGRES` where Docker is not available.
- EF generates migration classes as public. The architecture test allows public types in a `.Migrations` namespace.

## Consequences
- Not done yet: a purchase that creates the entitlement and the ledger entries in one transaction (the entitlement does not exist yet), tax lines, a statement export, retention of ledger data (7 years, ADR-0003).
- The ledger has no rule that an account code always has the same kind; callers must use one kind per code.
- Ledger test data cannot be cleaned up because the ledger is append-only. Tests use unique accounts and keys, so use a throwaway database.
- Advisory locks serialise postings per wallet account. That is fine at expected volumes; revisit if one account becomes hot.

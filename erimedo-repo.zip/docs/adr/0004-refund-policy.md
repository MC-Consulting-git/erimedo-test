# ADR-0004: Refund policy

Status: Accepted (confirmed by Magnus 2026-11-23). Resolves DEC-11.

## Decision (assumed)
- Within **7 days** of purchase, if the contact details are demonstrably wrong or the profile was unpublished or deleted, the buyer gets the fee back as **wallet credit**, posted as a reversing ledger entry. Payout to the original payment method only on request and where required by law.
- Otherwise a purchase is final once details have been shown. The terms say so clearly.
- Consumer-law rights for buyers who are private persons are handled in the terms for the market.

## Consequences
- Ledger needs a refund entry type (WAL-10).
- Terms of use (LEG-05) must match this.
- Needs legal review per market.

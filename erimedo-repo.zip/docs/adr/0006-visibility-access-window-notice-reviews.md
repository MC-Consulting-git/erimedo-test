# ADR-0006: Pre-purchase visibility, access window, consultant notice, review display

Status: Accepted (2026-11-23, decided by Magnus). Resolves DEC-02, DEC-03, DEC-10, DEC-13.

## Decisions
- **DEC-02:** Before purchase a buyer sees only the **consultant number**, plus skills with level and last-used, hourly rate, availability, location, reference count and rating. No name or initials.
- **DEC-03:** When the access window ends the buyer loses **both viewing and download**. A new purchase is needed to see the details again.
- **DEC-10:** The consultant gets an **in-app notice** when their details are bought: which company and when, **not the fee**. No e-mail by default.
- **DEC-13:** Only reviews from the **last 24 months** count and are shown. The average and count are calculated over those. Older reviews are kept but hidden from the average.

## Consequences
- Search DTOs contain no name field (SRC-23, SRC-24).
- Entitlements have an expiry; the check applies to view and download (PUR-21, PUR-24).
- New notification type "details purchased" (NTF-07).
- Review rows keep their date; the average is a query over a rolling window.
- With the 24-month window and no minimum count, one review can set the average; the count is always shown beside it.

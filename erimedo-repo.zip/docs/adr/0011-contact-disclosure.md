# ADR-0011: Disclosure of contact details

Status: Proposed. Needs human review (CLAUDE.md section 11: contact-detail disclosure, schema of personal data).

## Context
Section 6: contact details are returned only by the server after an entitlement check, never in search results or list DTOs, and every disclosure is audited. Modules may not reference each other.

## Decision
- The Profiles module owns the `profiles` schema. A profile row holds the consultant number (shown before purchase, ADR-0006), the published flag and the contact columns (full name, e-mail, phone).
- `IContactDisclosureService` is the only way to read contact details. It returns `ContactDetails`, the only contract type allowed to carry personal data.
- Order of steps: validate, find a **published** profile, ask for an active entitlement, **save the audit record**, then return the details. If saving the audit record fails, nothing is returned (tested).
- An unknown id and an unpublished profile give the same answer (`disclosure.not_found`), so the response does not reveal which profiles exist.
- Profiles declares what it needs as `IEntitlementLookup`. The Host implements it on top of Wallet's `IEntitlementService`. Neither module knows the other.
- The audit record holds ids only (profile, organization, person, entitlement, kind, time), never names or contact data. There is no foreign key to the profile, because the audit is kept 2 years (ADR-0003) and the profile is deleted within 30 days of account deletion.
- The database enforces the audit: UPDATE and TRUNCATE are refused; DELETE is allowed only for rows older than 2 years, so a retention job can clean up and nobody can erase recent disclosures.
- An architecture test fails if a public contract type other than `ContactDetails` has a property or parameter that looks like contact data (e-mail, phone, names).
- The Host's service registration is shared with the integration tests, which run purchase, then disclosure, through the real wiring against PostgreSQL.

## Consequences
- Not done: CV download (needs a file store and a scan, ADR-0007), access for the consultant and the company admin (PUR-20, needs Identity), an anonymous-search guard on a real search endpoint, creating and editing profiles, export and deletion of this data (ACC-40), the retention job.
- Contact columns are plain text in PostgreSQL. Encryption at rest comes from the managed database. Field-level encryption has not been decided.
- The caller must establish the buyer's organization, role and person on the server. The service trusts the ids it is given.
- Disclosure is audited on every call, including repeated views by the same person.

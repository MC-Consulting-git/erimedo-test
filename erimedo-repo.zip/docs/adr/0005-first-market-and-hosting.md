# ADR-0005: First market and hosting region

Status: Accepted (confirmed by Magnus 2026-11-23). Resolves DEC-20 in part.

## Decision (assumed)
- First market: **Sweden**. Currency SEK, Swedish VAT via `ITaxPolicy`, Swedish company registry adapter, languages `sv` and `en`.
- Hosting: an **EU region** with a managed PostgreSQL service.
- **Not decided:** hosting provider, identity provider, payment provider. They stay behind their ports (CLAUDE.md section 4) and are chosen in a later ADR.

## Consequences
- No code may depend on a specific provider until chosen.
- Development uses local adapters (fake identity, fake payment).

# Deploy to an Azure test environment

Region: **Sweden Central**. Test sizing only (see ADR-0013 for what must change before production).

## What gets created (`infra/main.bicep`)
Log Analytics, Azure Container Registry (Basic), a user-assigned identity with AcrPull, PostgreSQL Flexible Server 17 (Burstable B1ms, 32 GB) with database `erimedo`, a Container Apps environment and one Container App (0.5 vCPU, 1 replica, external HTTPS ingress, `/health` probes).

## One-time setup
You need an Azure subscription and a GitHub repository with this code.

```bash
az login
SUB=$(az account show --query id -o tsv)
az group create -n rg-erimedo-test -l swedencentral

# An identity for GitHub Actions, using federated credentials (no stored secret).
APP_ID=$(az ad app create --display-name erimedo-github --query appId -o tsv)
az ad sp create --id "$APP_ID"
az ad app federated-credential create --id "$APP_ID" --parameters '{
  "name": "github-main",
  "issuer": "https://token.actions.githubusercontent.com",
  "subject": "repo:<OWNER>/<REPO>:ref:refs/heads/main",
  "audiences": ["api://AzureADTokenExchange"]
}'

# Owner on the resource group, not Contributor: the template creates a role assignment (AcrPull).
az role assignment create --assignee "$APP_ID" --role Owner \
  --scope "/subscriptions/$SUB/resourceGroups/rg-erimedo-test"
echo "client id: $APP_ID  tenant: $(az account show --query tenantId -o tsv)  subscription: $SUB"
```

In GitHub (Settings, Secrets and variables, Actions):

| Kind | Name | Value |
|---|---|---|
| Secret | `AZURE_CLIENT_ID` | the client id above |
| Secret | `AZURE_TENANT_ID` | tenant id |
| Secret | `AZURE_SUBSCRIPTION_ID` | subscription id |
| Secret | `POSTGRES_ADMIN_PASSWORD` | a long random string of letters and digits only |
| Variable | `AUTHENTICATION_AUTHORITY` | token issuer of the identity provider. Leave empty until Entra External ID exists: every protected endpoint then answers 401 |
| Variable | `AUTHENTICATION_AUDIENCE` | the app's id or audience |
| Variable | `AUTHENTICATION_SUBJECT_CLAIM` | `sub` or `oid`. Verify against the real tenant first |
| Variable | `WALLET_FEE_AMOUNT` | price per entitlement for the test (default `100`) |

## Deploy
Run the workflow **Deploy to Azure test** (Actions, Run workflow). It builds and tests, deploys the infrastructure, builds the image in the registry, rolls it out, and checks `/health`. The first run creates the app with a placeholder image and replaces it with the real one in the same run.

The URL is printed by `az deployment group show -g rg-erimedo-test -n main --query properties.outputs.appUrl.value -o tsv`.

## Manual alternative (no GitHub)
```bash
az deployment group create -g rg-erimedo-test -f infra/main.bicep -p postgresAdminPassword='<password>'
ACR=$(az deployment group show -g rg-erimedo-test -n main --query properties.outputs.acrName.value -o tsv)
az acr build -r "$ACR" -t erimedo:test .
az deployment group create -g rg-erimedo-test -f infra/main.bicep \
  -p postgresAdminPassword='<password>' image="$ACR.azurecr.io/erimedo:test"
```

## What a test environment shows today
`/health`, an empty start page, and two API endpoints that need sign-in. There is no way yet to create organizations, memberships or profiles, or to top up a wallet, so the purchase flow can only be tried after seeding rows with SQL. Connect with `psql` after adding your IP as a firewall rule on the server.

## Known limits
- The database password is a Container Apps secret and is also in the deployment parameters. Move it to Key Vault and use Entra authentication for the database before production.
- PostgreSQL is reachable from Azure services with a password. Use private networking before production.
- Migrations run at app start (`Database__MigrateOnStartup`). Production needs a migration bundle run as a separate step.
- Burstable B1ms may not be offered in every subscription or zone in Sweden Central; change `sku` in the template if the deployment says so.
- Not run against a real Azure subscription. The template compiles with the Bicep CLI. The Docker image was built and run locally against PostgreSQL 17 (user `app`, port 8080, migrations applied, `/health` 200, 401 without sign-in). In the sandbox the build needed a proxy and CA certificate; on a normal machine or in Azure Container Registry the plain `Dockerfile` is used.

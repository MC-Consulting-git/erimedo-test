# 01 Roles and accounts

## Actors

| Actor | Description |
|---|---|
| **Visitor** | Not signed in. May browse public pages and **search for consultants**. Needs an account only to buy. |
| **User** | Has an account, not necessarily linked to a company. |
| **Consultant** | A user with the `Consultant` role in a company. Owns a profile. |
| **Buyer** | A user with the `Buyer` role in a company. Can purchase access and use the company balance. |
| **Company admin** | A user with the `CompanyAdmin` role. Manages the company, its members, and rate/availability/publishing of consultant profiles. |
| **Site admin** | Operator staff. Manages taxonomy, content, store configuration. |

A user may hold several roles in the same company (for example admin and consultant, or buyer and admin). A user belongs to **at most one company** at a time.

## Account lifecycle

States: `PendingApproval` (registered, e-mail not confirmed) → `Approved` (confirmed) → `Rejected` (account closed). `LockedOut` is a login outcome, not a stored state.

### Sign-up

- **ACC-01** `[Observed]` A visitor registers with first name, last name, e-mail address and password. The e-mail address is the user name.
  *Prototype: AccountController → Register*
- **ACC-02** `[Observed]` The account starts as `PendingApproval` and cannot log in until the e-mail link has been used.
- **ACC-03** `[Observed]` Registering with an e-mail that already exists returns a state result (`Pending` or `Added`) instead of an error, and creates nothing.
- **ACC-04** `[Observed]` Registering with the e-mail of a closed (`Rejected`) account **reopens** that account: it returns to `PendingApproval`, any old link between the person and a consultant profile is removed, and a new confirmation mail is sent.
- **ACC-05** `[Change]` The reopened account MUST NOT silently inherit old roles, company membership or purchase entitlements. It starts clean, and old personal data follows the retention rules in ACC-40.
- **ACC-06** `[Change]` Responses to sign-up and password-reset MUST NOT reveal whether an e-mail address is registered (prevents account enumeration), except where the user is already authenticated for that address.
- **ACC-07** `[Observed]` The confirmation link contains the user id and a one-time token. Using it activates the account and signs the user in, then sends them to their account page.
- **ACC-08** `[Intended]` After activation the user is asked for phone number and place of residence ("Update account") and to link to a company.

### Login, lockout, password

- **ACC-10** `[Observed]` Login with e-mail and password, optional "remember me", optional return URL.
- **ACC-11** `[Observed]` Distinct outcomes: unknown account, unconfirmed account, wrong credentials, locked out, additional verification required.
- **ACC-12** `[Change]` The user-facing message for unknown account and wrong password MUST be identical (see ACC-06). Unconfirmed accounts MAY get a "resend confirmation" path.
- **ACC-13** `[Observed]` Account lockout after repeated failures exists (a dedicated "locked out" page). The threshold is configuration, not hard-coded.
- **ACC-14** `[Observed]` Forgot password: request by e-mail, receive a link with a one-time token, set a new password. The token is held in a short-lived cookie during the reset.
- **ACC-15** `[Observed]` Change password requires the old password.
- **ACC-16** `[Change]` Authentication is delegated to an external identity provider (see `CLAUDE.md` section 4). The behaviours above are required outcomes, not an instruction to build password storage.
- **ACC-17** `[Change]` MFA SHOULD be available, and MUST be offered to company admins and anyone who can spend company money.

### Update account

- **ACC-20** `[Observed]` A user can update first name, last name, phone and address (including country, region, city).
- **ACC-21** `[Intended]` A user sees their company and roles on the account page.

### Account deletion

- **ACC-30** `[Observed]` Deleting an account is a two-step action: the user requests deletion, receives an e-mail with a confirmation link, and the account is closed only after the link is used.
- **ACC-31** `[Observed]` Closing an account unlinks the user from the company first. If this is not allowed (the user is the company's **last administrator**), deletion is refused with a clear message.
- **ACC-32** `[Observed]` On closure: the consultant profile is unpublished (deactivated), the link to it is removed, customer type is cleared, the user is signed out, and company admins receive a "member account deleted" e-mail.
- **ACC-33** `[Observed]` The prototype only **marks the account `Rejected`**. Personal data, purchases and reviews remain.
- **ACC-40** `[Change]` Deletion MUST follow GDPR: the user can request erasure and export. Personal data is erased or anonymised on a defined schedule (see `10-open-decisions.md` DEC-04). Financial records that must be kept by law are retained in minimised form.
- **ACC-41** `[Change]` Reviews written by a deleted user are kept but anonymised. A deleted consultant's profile, CV and contact details are removed from search at once and deleted from storage by the retention schedule.
- **ACC-42** `[Change]` Existing entitlements of buyers to a deleted consultant's contact details stop at deletion (the consultant has withdrawn consent). Downloaded copies are outside our control and the terms must say so.

## Acceptance examples

- *Given* a registered but unconfirmed user, *when* they try to log in, *then* they see a "confirm your e-mail" message and no session is created.
- *Given* the only administrator of a company, *when* they confirm account deletion, *then* deletion is refused and the account stays active until another admin exists or the company is closed.
- *Given* a closed account, *when* the same e-mail registers again, *then* a new confirmation mail is sent and the account has no roles, no company and no entitlements.

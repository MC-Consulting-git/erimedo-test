# 03 Consultant profile and taxonomy

A **consultant profile** is what a buyer searches and, after paying, receives contact details and a CV for. In the prototype it was implemented as a catalog product linked to a contact. In the new system it is a first-class entity (see `CLAUDE.md` section 5).

## Profile content

| Field | Notes | Who edits |
|---|---|---|
| Skills | A set of (skill, level 1 to 5, last used month). See below. | Consultant |
| Working locations | Country, region, optionally city. A profile may list several. | Consultant |
| Hourly rate | Used by buyers' maximum-rate filter. Currency SEK in the prototype. | **Company admin** |
| Available from | Date the consultant can start. | **Company admin** |
| Part-time | Whether part-time assignments are acceptable. | **Company admin** |
| Published | Whether buyers can find the profile. | **Company admin** |
| CV | One file. Required before publishing. | Consultant |
| Presentation | One optional file (PDF or Word). | Consultant |
| References | Zero or more. See `07-reviews-and-references.md`. | Consultant |
| Display name / consultant number | A stable consultant number is shown in search. | System |
| Contact details | Name, e-mail, phone. **Hidden until purchase.** | Consultant (account) |

- **PRO-01** `[Observed]` Rate, availability, part-time flag and published state are controlled by the **company admin**, not the consultant. A consultant who is not an admin must ask the admin. A consultant who is their own company is their own admin.
  *Help text: "If you are the company administrator, you can change these details yourself. If not, you need to contact that person."*
- **PRO-02** `[Intended]` The admin publishes the profile when the consultant has finished the profile **and uploaded a CV**.
- **PRO-03** `[Observed]` A profile is created automatically when a user becomes a consultant (by linking, or by accepting an invitation).
- **PRO-04** `[Observed]` An unpublished profile is invisible to buyers. Leaving the company, deleting the account, or removal by an admin unpublishes the profile.
- **PRO-05** `[Observed]` The admin can edit the profile display name, part-time flag, active flag, price and available-from date on a per-consultant page.
- **PRO-06** `[Observed]` A consultant (or their admin) can update **rate and available-from** quickly without opening the full profile.
- **PRO-07** `[Change]` Rate MUST be stored as `Money` (amount and currency), never in a catalog price record. It is a **rate**, not a price the buyer pays. See DEC-01.
- **PRO-08** `[Change]` Changes to rate, availability and published state MUST be audit-logged (who, when, old and new value). The prototype only recorded "last modified by".

## Skills

- **PRO-10** `[Observed]` Each skill entry has a **skill**, a **level** from 1 to 5 and a **last used** date with **month precision**.
- **PRO-11** `[Observed]` UI defaults when adding a skill: level 3, last used three months ago.
- **PRO-12** `[Observed]` All three are required to save. A skill can be edited and deleted. The list can be sorted by name, last used or level, ascending or descending.
- **PRO-13** `[Observed]` Skills are chosen from a **hierarchical taxonomy** up to five levels deep: pick a general area, then optionally narrower sub-areas.
- **PRO-14** `[Observed]` A consultant who cannot find a skill can **add a new one** under any node. In the prototype this is created **immediately and without approval**, and the site admin gets an e-mail (`AddedNewSkill`).
- **PRO-15** `[Change]` A new skill MUST enter a moderation queue. It is visible to its creator at once, but only becomes searchable for others after a site admin approves it, merges it into an existing skill (as a synonym), or rejects it. Reason: duplicates and free-text variants polluted search in the prototype.
- **PRO-16** `[Observed]` Skills were stored as **a single serialised string** on the profile in the prototype. The new system stores them as rows so they can be filtered and scored. This is an implementation note, not a behaviour.

### Level scale (shown in the UI and used by search)

| Level | Meaning |
|---|---|
| 1 | Newly trained, or has worked under supervision in the field. May need guidance. |
| 2 | Works independently if given clear instructions. |
| 3 | Works independently without instructions. Finds own solutions. |
| 4 | Can mentor and supervise others. Often a key person in the team or for the client. |
| 5 | Role model and leading authority, for example MVP, sought-after speaker or trainer. |

- **PRO-17** `[Intended]` The level scale text is part of the **vertical** (data), not code. See `CLAUDE.md` section 4. IT is the first vertical.

## Taxonomy

- **TAX-01** `[Observed]` The prototype's seed data (`Data/catalog_core_pricing_store.zip`) holds **1,221 categories** in seven top-level groups: `Skills`, `Countries`, `Levels`, `Last Used`, `Consultants`, `Credits`, `Mobile Rate range`. Only `Skills` and `Countries` describe the domain. The others were catalog scaffolding.
- **TAX-02** `[Observed]` `Countries` has about 240 countries, with Swedish counties (län) and their sub-regions below Sweden.
- **TAX-03** `[Observed]` `Skills` is in **Swedish**, with large groups such as Systemförvaltning (about 140 children), Nätverk & Kommunikation (about 76), Upphandling (about 71), Databaser (about 54), Affärssystem (about 40), Operativsystem (about 32), Informations & Kommunikation (about 23).
- **TAX-04** `[Decision]` Whether to seed the new taxonomy from this list (translated and cleaned) or from an open standard. See DEC-07. Whichever is chosen, every skill needs a stable id, a name per language, and synonyms.
- **TAX-05** `[Change]` Locations MUST come from a country/region/city reference dataset, not from taxonomy nodes. Distance for matching uses coordinates (see `04-search.md`).

## Locations

- **PRO-20** `[Observed]` A profile has a working country, region and city. Buyers filter on these. The consultant may state several locations they are willing to work in ("where the consultant is willing to relocate to").
- **PRO-21** `[Intended]` A consultant may accept remote work. The prototype had no explicit remote flag. `[Change]` The new profile has one. See `CLAUDE.md` section 8.

## Documents (CV and presentation)

- **PRO-30** `[Observed]` A consultant uploads **one CV** and **one optional presentation**. Uploading a new file replaces the old one.
- **PRO-31** `[Observed]` The consultant can delete the presentation. The file name is shown back to them.
- **PRO-32** `[Observed]` Who may download a file:
  1. the consultant themselves,
  2. their company admin,
  3. a buyer who bought the profile within the access window,
  4. any **other buyer in the same company** as that buyer, within the same window.
  See `05-purchase-and-access.md`.
- **PRO-33** `[Decision]` Allowed file types and maximum size. The prototype enforced neither in code that could be found. Proposed default: PDF and DOCX, up to 10 MB, malware-scanned. See DEC-08.
- **PRO-34** `[Intended]` Instead of a CV file, a consultant may link a **LinkedIn profile**. Contact details must still come from eRimedo. See `12-future.md`.
- **PRO-35** `[Change]` Files are stored in private object storage and served through the server after an entitlement check. They MUST NOT be reachable by a guessable or permanent public URL.

## Acceptance examples

- *Given* a consultant who is not an admin, *when* they open their profile, *then* rate, availability, part-time and published are shown read-only with a note to contact the company admin.
- *Given* a profile with no CV, *when* the admin tries to publish it, *then* publishing is refused with a clear reason.
- *Given* a consultant adds a skill that does not exist, *when* they save, *then* it appears on their own profile but is not offered to other users or matched in searches until moderation approves it.
- *Given* a consultant leaves the company, *then* their profile becomes unpublished in the same transaction.

# 10 Open decisions

Each decision has an id used in the other files. "Default" is what a developer should assume **only until the owner answers**. Do not build irreversible things on a default.

| Id | Question | Why it matters | Default until decided |
|---|---|---|---|
| **DEC-01** | ✅ **Decided 2026-11-23: fixed fee per entitlement (ADR-0001).** ~~What does the buyer pay per consultant?~~ The prototype charges the consultant's **hourly rate** as the price. Marketing texts say a **once-off fee**. | Drives pricing, tax, the wallet and how rate is stored. The most important commercial decision. | A configurable fixed fee per entitlement. Rate stored separately. |
| **DEC-02** | ✅ **Decided 2026-11-23 (ADR-0006).** What is visible before purchase: consultant number only, or first name or initials? | Privacy versus trust, and how easily buyers can bypass the service. | Consultant number only. |
| **DEC-03** | ✅ **Decided 2026-11-23 (ADR-0006).** After the access window, does the buyer keep **seeing** contact details? | Fair use versus recurring revenue. | Lose downloads and view. |
| **DEC-04** | ✅ **Decided 2026-11-23 (ADR-0003).** **Retention** per data type (accounts, profiles, CVs, orders, ledger, audit, notifications, logs). | GDPR. Must be an ADR before storing the data. | Not defined. Ask. |
| **DEC-05** | Balance, entitlements and orders when a company closes. | Money owed to the customer. | Refundable on request, in the ledger. |
| **DEC-06** | ✅ **Decided 2026-11-23 (ADR-0007).** Company registry: which provider per country, cost per lookup, usage terms. | Cost and legality. | Manual entry plus an optional adapter. |
| **DEC-07** | ✅ **Decided 2026-11-23 (ADR-0007).** Skill taxonomy seed: the prototype's Swedish list (1,221 entries, mostly skills) or an open standard. | Quality of matching, translation effort. | Cleaned prototype list, with stable ids. |
| **DEC-08** | ✅ **Decided 2026-11-23 (ADR-0007).** CV and presentation file types and size. | Security and cost. | PDF and DOCX, 10 MB, scanned. |
| **DEC-09** | Promotion or coupon codes. | Feature scope. | Not in the first version. |
| **DEC-10** | ✅ **Decided 2026-11-23 (ADR-0006).** Tell the consultant when their details are bought? | Trust and consent. | Yes, in-app, no price. |
| **DEC-11** | ✅ **Confirmed 2026-11-23 (ADR-0004).** Refund policy. | Money and terms. | None. Decide before launch. |
| **DEC-12** | Top-ups by card only, or invoice with credit terms? | Credit risk. | Card only. |
| **DEC-13** | ✅ **Decided 2026-11-23 (ADR-0006).** Review expiry and a minimum count before showing an average. | Fairness. | No expiry. Show the count with the average. |
| **DEC-14** | ✅ **Confirmed 2026-11-23 (ADR-0002):** separate. Confirm references (consultant-supplied contacts) are separate from reviews (buyer-written). | The prototype's code and help text disagree. | Separate, as in `07`. |
| **DEC-15** | Legal entity and brand: eRimedo or Cifereca. | Contracts, privacy text, domains. | eRimedo. |
| **DEC-16** | Outbound webhooks or export for operators (the Zapier use). | Operations. | Admin CSV export. |
| **DEC-17** | Invitation expiry. | Security. | 14 days, single use. |
| **DEC-18** | Moderation of new skills, who moderates, how fast. | Taxonomy quality. | Site admin queue. |
| **DEC-19** | Are roles requested in a pending linking request visible to the admin before approval? | ORG-16. | Yes, and none granted. |
| **DEC-20** | ✅ **Decided 2026-11-23: providers (ADR-0008), Sweden first (ADR-0005). Exact EU region open.** First market, first payment provider, first identity provider, hosting region. | Everything with an adapter. | Sweden, EU region. Providers open (`CLAUDE.md` section 13). |

## How to answer

Add a line to the table with the decision and date, then record it as a short ADR in `docs/adr/`.

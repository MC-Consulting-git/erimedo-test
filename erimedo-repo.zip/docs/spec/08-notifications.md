# 08 Notifications

Two channels: an **in-app notification centre** and **e-mail**. Both are localized (`CLAUDE.md` section 7).

## In-app notification centre

- **NTF-01** `[Observed]` Each notification has a type, a status (`Pending`, `Approved`, `Rejected`), a read flag, a sender and recipient, a timestamp and a localized text.
- **NTF-02** `[Observed]` The centre updates **live** (the prototype used SignalR). The unread count shows in the header.
- **NTF-03** `[Observed]` Types:

| Type | Meaning |
|---|---|
| `LinkingToCompanyAsConsultantRequest` | A user asks to join as consultant. Admin acts on it. |
| `LinkingToCompanyAsConsultant` | Result of the request, to the requester. |
| `LinkingToCompanyAsAdministrator` | Same for an administrator request or promotion. |
| `ConsultantUnlinked` | A consultant was removed or left. |
| `UnLinkingToCompanyAsAdministrator` | An administrator was removed. |
| `UnLinkingToCompanyInfoToAdministrator` | Other admins informed that someone left or was removed. |
| `UnLinkingToCompanyInfoToUser` | The removed person is told. |
| `ReminderUpdateProfileNotification` | Admin asks a consultant to update their profile. |

- **NTF-04** `[Observed]` Request notifications are **actionable**: an admin approves or rejects them in the centre, and the status changes.
- **NTF-05** `[Change]` Notifications are never deleted by users. They can be marked read and archived. Retention per DEC-04.
- **NTF-06** `[Change]` In-app text contains no more personal data than needed (name, not contact details).
- **NTF-07** `[Change]` New types: *your details were bought* (DEC-10), *saved search has a new match*, *a new need matches you* (`12-future.md`), *review received*, *skill approved or rejected*.

## E-mail

- **NTF-10** `[Observed]` The prototype has **12 company and account e-mails** plus four from the platform:

| Template | Sent when |
|---|---|
| `InviteCompanyAdministrator` | Admin invites an administrator. |
| `InviteConsultant` | Admin invites a consultant. |
| `InviteCompanyBuyer` | Admin invites a buyer. |
| `LinkingCompanyRequest` | To admins: a user asks to link. |
| `ApprovedLinkingRequest` | To requester: approved. |
| `RejectedLinkingRequest` | To requester: rejected. |
| `NotifyConsultantAddedAsAdmin` | A consultant is made administrator. |
| `RemovedConsultant` | A consultant is removed. |
| `ReminderUpdateProfile` | Admin asks for a profile update. |
| `AddedNewSkill` | To site admin: a consultant added a skill. |
| `DeleteAccountConfirmation` | Confirm account deletion (link). |
| `DeletedAccount` | To company admins: member account deleted. |
| Platform: registration confirmation, password reset, order receipt, `DeleteCompanyInform` | See `01`, `05`, `02`. |

- **NTF-11** `[Observed]` Templates use named placeholders such as `{{AccountName}}`, `{{CompanyName}}`, `{{Roles}}`. They exist in English and Swedish.
- **NTF-12** `[Change]` Templates are stored **per language** with the fallback `user language`, then `sv`, then `en`. Adding a language is a new set of files.
- **NTF-13** `[Change]` Every e-mail has a plain-text and an HTML part, a sender per market, and a footer with the company details.
- **NTF-14** `[Change]` Sending goes through the background job queue with retry. A failed send never fails the business action.
- **NTF-15** `[Change]` Mail addresses and bodies are never written to logs.
- **NTF-16** `[Change]` Users can opt out of **non-essential** mail (reminders, alerts). Security, invitation and receipt mail is always sent.
- **NTF-17** `[Change]` The prototype template texts mention the old product name and should be reviewed. They are source for **tone and structure**, not to copy blindly.

## Acceptance examples

- *Given* a user with language `sv`, *then* the invitation mail is in Swedish. If a Swedish template is missing, it falls back to English.
- *Given* the mail service is down, *when* an admin invites a consultant, *then* the invitation is stored and sending retries.
- *Given* an admin approves a request, *then* the requester gets both an e-mail and an in-app notice.

# 06 Wallet and credits (prepaid balance)

A company can prepay and then buy access without going through a payment provider each time. In the prototype this was a single number on the organization. In the new system it is the **Wallet** module with an append-only ledger (`CLAUDE.md` section 6).

## Observed behaviour

- **WAL-01** `[Observed]` The balance belongs to the **organization**, not the person. It starts at 0.
- **WAL-02** `[Observed]` A company **tops up** by buying a "credit" product (catalog category *Credits*) and paying through the normal payment provider. When the order is paid, the balance increases by the **price** of that credit product.
- **WAL-03** `[Observed]` The balance is **spent** by choosing "Account balance" at checkout. It is available only to users with the Buyer role. The order total is deducted, and the order becomes `Paid`.
- **WAL-04** `[Observed]` If the balance is lower than the total, the payment is refused.
- **WAL-05** `[Observed]` Any buyer in the company may spend the balance. Only company admins and buyers see it.
- **WAL-06** `[Observed]` Gaps in the prototype: the balance update and the order update are **not atomic**; there is **no refund**; the **balance is lost** when the company is deleted; there is no history of movements.

## Required behaviour

- **WAL-10** `[Change]` Every movement is a **ledger entry**: top-up, purchase, refund, correction, expiry. Entries are append-only and double-entry. Mistakes are fixed with a reversing entry, never an update or delete.
- **WAL-11** `[Change]` The balance is **derived** from the ledger, never stored as an editable number.
- **WAL-12** `[Change]` Money is `Money` (decimal and currency). A wallet holds **one currency**. Mixing currencies requires an explicit conversion entry.
- **WAL-13** `[Change]` A purchase from the wallet and its entitlement are created in **one transaction**. Concurrent purchases cannot overdraw the balance.
- **WAL-14** `[Change]` Every top-up and spend takes an **idempotency key**.
- **WAL-15** `[Change]` Buyers and admins see a **statement**: date, type, amount, balance, who, reference. It can be exported.
- **WAL-16** `[Change]` Top-up amounts are free amounts within configured limits, not fixed catalogue products.
- **WAL-17** `[Change]` A company can have a **spending limit per buyer** (optional, later).
- **WAL-18** `[Decision]` Whether unused balance **expires**, can be **refunded** to the payer, and what happens on company closure. See DEC-05.
- **WAL-19** `[Decision]` Are top-ups invoiced (30-day terms) or prepaid by card? See DEC-12.
- **WAL-20** `[Change]` Tax (VAT) treatment of top-ups versus purchases is decided by `ITaxPolicy`. Selling a prepaid voucher and selling the service can have different VAT timing in some markets, so the ledger records the tax amount for each entry.

## Acceptance examples

- *Given* a balance of 1,000 SEK and a purchase of 600 SEK, *then* one purchase entry of -600 exists and the balance is 400.
- *Given* two buyers purchase at the same moment with 600 SEK left and 500 SEK each, *then* exactly one succeeds.
- *Given* a retry of the same top-up request with the same key, *then* the balance rises once.
- *Given* a mistaken entry, *then* a reversing entry is posted and the original stays visible.

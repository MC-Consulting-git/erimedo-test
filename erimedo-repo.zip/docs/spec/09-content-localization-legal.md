# 09 Content, localization and legal

## Content

- **CNT-01** `[Observed]` Static pages are **Markdown files per language** (`en-US`, `sv-SE`): about, how it works, help for buyers, help for consultants, cookies, user agreement, privacy.
- **CNT-02** `[Observed]` A **news** blog exists with posts per language.
- **CNT-03** `[Observed]` The start page carries the marketing message: direct contact with consultants, no brokers, affordable rates, a once-off fee, free for consultants and consulting companies.
- **CNT-04** `[Change]` Content is managed in the **Content** module (title, slug, body, language, published, updated). Editors are site admins. A page missing in the user's language falls back (`user`, `sv`, `en`).
- **CNT-05** `[Change]` The prototype's texts are source material for **wording and structure** only. They mention the old company and product names and must be reviewed.

## Localization

- **LOC-01** `[Observed]` The prototype had two cultures, `en-US` and `sv-SE`, default `sv-SE`, and two currencies, SEK and USD. Theme strings lived in `en.json` and `sv.default.json`.
- **LOC-02** `[Change]` UI strings are in resource files per language. Adding a language is a new file (`CLAUDE.md` section 7).
- **LOC-03** `[Change]` Cultures are neutral (`sv`, `en`), with regional formatting for dates, numbers and currency taken from the user's market.
- **LOC-04** `[Change]` Skill names, synonyms, level scale text, locations and e-mail templates are **data per language**.
- **LOC-05** `[Change]` User-written content (profiles, CVs, reviews) is not translated automatically.
- **LOC-06** `[Change]` The user chooses language in the header. The choice is saved on the account and, for visitors, in a cookie.

## Legal pages

- **LEG-01** `[Observed]` The prototype's privacy text names **Cifereca AB** as the data controller and refers to the Swedish Personal Data Act of 1998 (PUL). It also says data may be processed outside the EEA and that no direct marketing is sent beyond the service's own.
- **LEG-02** `[Change]` **The text is out of date.** PUL has been replaced by GDPR. It MUST be rewritten by someone legally qualified before launch. Required content at minimum: controller identity, purposes and legal basis per purpose (consultants' details are disclosed to buyers), retention (DEC-04), recipients (payment provider, identity provider, hosting), transfers (EU hosting only, `CLAUDE.md` section 6), rights (access, export, erasure, objection) and how to use them.
- **LEG-03** `[Change]` The consultant's **consent to disclosure** of contact details and CV to paying buyers MUST be an explicit, recorded and withdrawable choice.
- **LEG-04** `[Change]` **AI processing of CVs** needs separate, recorded consent (`CLAUDE.md` section 6).
- **LEG-05** `[Change]` The **user agreement** needs a market-specific version covering: the buyer's rights to use the details (no resale, no bulk copying), refunds (DEC-11), the access window, limitation of liability, and that downloaded copies are outside our control (ACC-42).
- **LEG-06** `[Change]` A **cookie banner** that records consent. Only strictly necessary cookies before consent.
- **LEG-07** `[Decision]` The legal entity and brand that run the new service. See DEC-15.

## Integrations seen in the prototype

- **INT-01** `[Observed]` **Company registry (Bisnode):** company search by name, data prefill, and a "buy company" request on creation. Replaced by `ICompanyRegistry` (ORG-10, DEC-06).
- **INT-02** `[Observed]` **Payment (Payson):** card and invoice. Replaced by `IPaymentProvider` (PUR-09).
- **INT-03** `[Observed]` **Zapier:** polling of new contacts and new orders, and creation of contacts, so the owner could feed a CRM or spreadsheet. `[Decision]` Whether to offer an outbound webhook or export for operators. See DEC-16.
- **INT-04** `[Observed]` **Elasticsearch** powered search. Replaced by PostgreSQL (`CLAUDE.md` section 2).
- **INT-05** `[Observed]` **SignalR** pushed notifications. Replaced by a Blazor-native mechanism.

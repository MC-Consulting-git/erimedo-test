# 02 Organizations (companies)

An **Organization** is a company. It owns consultants' profiles, buyers' purchasing rights, a prepaid balance (see `06-wallet-and-credits.md`) and a set of administrators. Both consulting companies and buying companies are organizations. One person can be consultant, buyer and admin in the same organization.

## Rules that always hold

- **ORG-01** `[Observed]` A user belongs to **at most one** organization. To join another, the user must first leave the current one.
- **ORG-02** `[Observed]` Every organization has **at least one administrator**. The last administrator cannot leave, be removed or delete their account. To get out, they must invite another administrator or close the organization.
- **ORG-03** `[Observed]` Roles are per user inside the organization: `CompanyAdmin`, `Consultant`, `Buyer`. Removing a user's last role also unlinks them from the organization.
- **ORG-04** `[Observed]` An admin can only act on members of **their own** organization. (The prototype enforces this with an explicit check per action; in the new system it is enforced centrally, see CLAUDE.md section 6.)
- **ORG-05** `[Observed]` A new organization starts with a balance of zero.

## Creating or joining a company

The first thing a new user normally does after confirming their account.

- **ORG-10** `[Observed]` The user types a company name. The system looks it up in a **company registry** (the prototype used Bisnode, paged results) and shows matches. The user selects one.
  *Prototype: CompanyController → CompanyRefreshJson*
- **ORG-11** `[Observed]` Registry data (legal name, address, phone, country, registration number) is **read-only** for the company. Corrections go through support. The company can edit only its **contact person** details.
- **ORG-12** `[Observed]` The user ticks which role(s) they have: buyer, consultant, admin.
- **ORG-13** `[Observed]` **If the company does not yet exist in eRimedo:** the organization is created and the requesting user becomes its administrator **regardless of which boxes were ticked**. If they ticked consultant, a consultant profile is created for them. If they ticked buyer, they get the buyer role.
  *Help text: "Please note that if the company doesn't have an account in eRimedo, the account will be created … your account will automatically set you up as the administrator."*
- **ORG-14** `[Intended]` Someone not authorised to act for the company should abort and ask an authorised person to create the company account first.
- **ORG-15** `[Observed]` **If the company already exists:** the user does not join directly. A **linking request** is created in state `Pending` for the requested role(s), and the company's administrators are told (in-app notification and e-mail). The requester also gets an in-app "request sent, wait for approval" notice.
- **ORG-16** `[Change]` While a request is `Pending`, the requester MUST have **no** company role and no company permissions. (The prototype applies the requested roles at request time. Whether it revokes them on rejection could not be verified, which is a privilege-escalation risk. Roles are granted on approval only.)
- **ORG-17** `[Observed]` An administrator approves or rejects the request from the notification centre. The requester is told the outcome by e-mail (`ApprovedLinkingRequest` / `RejectedLinkingRequest`) and in-app.
- **ORG-18** `[Observed]` Only one pending linking request per user.
- **ORG-19** `[Decision made]` First version: the user enters the organisation number; it is validated and, where possible, checked against open data. No paid registry lookup. See DEC-06 and ADR-0007. This supersedes the registry-prefill behaviour in ORG-10 and the read-only rule in ORG-11 until a registry adapter exists.

## Invitations

An admin can invite people by e-mail as **administrator**, **consultant** or **buyer**.

- **ORG-20** `[Observed]` The invitation e-mail contains a link with a signed token bound to the **e-mail address, the organization and an expiry**.
- **ORG-21** `[Observed]` Validity period is store configuration in days. `0` meant "never expires" in the prototype.
- **ORG-22** `[Change]` Invitations MUST always expire (default 14 days), MUST be single-use, and an admin MUST be able to revoke a pending invitation.
- **ORG-23** `[Observed]` To accept, the invitee must be **signed in as the invited e-mail address**. Otherwise they are told they are logged in as the wrong user.
- **ORG-24** `[Observed]` Acceptance fails, with a specific message, when: the token is invalid; the person is already in a different company; they already hold that role; the invitation has expired.
- **ORG-25** `[Observed]` On acceptance as consultant, the user gets the consultant role, is linked to the organization and a consultant profile is created if none exists. As buyer or administrator, they get that role and are linked.
- **ORG-26** `[Observed]` If an admin "adds an administrator" and that e-mail already belongs to a user **in the same organization**, the person is promoted immediately and receives a "you are now administrator" e-mail (`NotifyConsultantAddedAsAdmin`). If the user is in another organization, or does not exist, an invitation is sent instead.
- **ORG-27** `[Change]` Promotion of an existing member to administrator SHOULD require that member's acceptance, or at least be recorded in an audit log visible to all admins.

## Leaving and removing

- **ORG-30** `[Observed]` A member can **leave** (unlink). Leaving clears all their roles and customer type. A leaving consultant's profile is unpublished. All other admins are notified (in-app, `UnLinkingToCompanyInfoToAdministrator`).
- **ORG-31** `[Observed]` An admin can **remove a buyer**, **remove an administrator** (not the last one), or **remove a consultant**. The removed person receives an in-app notice and, for consultants, the `RemovedConsultant` e-mail. Other admins are informed when an administrator is removed.
- **ORG-32** `[Observed]` Removing a role from someone who has other roles only removes that role. If it was their only role, they are unlinked as well.

## Closing a company

- **ORG-40** `[Observed]` An admin can delete the organization. All members are unlinked, their roles and customer types cleared, each member is e-mailed (`DeleteCompanyInform`), and the organization is deleted.
- **ORG-41** `[Decision]` What happens to the remaining **prepaid balance**, to **entitlements** the company bought, and to **order history** on closure. The prototype defined nothing, so the balance is simply lost. See DEC-05.
- **ORG-42** `[Change]` Closure MUST require an explicit confirmation that states the consequences, and SHOULD be reversible for a grace period.

## Company administration screens (admin only)

- **ORG-50** `[Observed]` **Company details:** registry data (read-only) and editable contact person.
- **ORG-51** `[Observed]` **Associated consultants:** list with rate, available-from date, last profile update and who made it. Actions: open a consultant's management page, send an "update your profile" reminder, remove a consultant, invite a new consultant.
- **ORG-52** `[Observed]` **Company administrators:** list, invite or add, remove (not the last).
- **ORG-53** `[Observed]` **Company buyers:** list, invite, remove.
- **ORG-54** `[Observed]` **Reminder:** an admin can ask a consultant to update their profile. This sends an e-mail (`ReminderUpdateProfile`) and an in-app notification.

## Acceptance examples

- *Given* a registry company that has no eRimedo account, *when* a user links to it and ticks only "consultant", *then* the organization exists, the user is its administrator **and** consultant, and a profile is created for them.
- *Given* a company with two admins, *when* one is removed, *then* the removed admin is notified and unlinked if they had no other role, and the remaining admin cannot be removed or leave.
- *Given* a pending linking request, *when* the requester opens the app, *then* they have no company permissions until an admin approves.
- *Given* an invitation older than its expiry, *when* the invitee opens it, *then* it is refused with an "expired" message and no role is assigned.

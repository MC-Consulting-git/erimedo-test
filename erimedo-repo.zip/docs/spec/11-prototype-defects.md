# 11 Prototype defects not to repeat

Collected while reading the 2016 code. This is a **checklist for reviewers**, not a to-do for the old code. Every item has a counterpart requirement.

| # | Defect | Risk | Counterpart |
|---|---|---|---|
| 1 | Database credentials committed in configuration. | Critical | `CLAUDE.md` section 6 (no secrets in the repo) |
| 2 | Roles applied at **request** time of a company linking request. Revocation on rejection not verified. | Privilege escalation | ORG-16 |
| 3 | Invitation validity of `0` means never expires. Tokens are not single-use or revocable. | Account takeover window | ORG-22 |
| 4 | Distinct messages for unknown e-mail and wrong password; sign-up reveals existing accounts. | Account enumeration | ACC-06, ACC-12 |
| 5 | Account deletion only marks `Rejected`. Data stays. A closed account can be reopened with old links. | GDPR, stale access | ACC-05, ACC-33, ACC-40 |
| 6 | Balance stored as a number, updated apart from the order. No refund. Lost on company deletion. | Money errors | WAL-06, WAL-10 to WAL-13 |
| 7 | Price of a consultant used as the price the buyer pays. Same word "rate" for money and stars. | Confused pricing | DEC-01, `04` naming trap |
| 8 | Skills stored as one serialised string. | Cannot filter or score | PRO-16 |
| 9 | New skills created immediately, unmoderated. | Duplicate and free-text skills | PRO-15 |
| 10 | No file type, size or malware check found on CV upload. | Malware, cost | PRO-33 |
| 11 | CV and presentation served by a controller with a role check, not an entitlement record and audit. | Weak access trail | PUR-26, PRO-35 |
| 12 | The "almost match" spreadsheet mixed signed differences and units (km, percent, days, levels) with arbitrary factors. Bonuses could cancel penalties. | Unexplainable, wrong ranking | `CLAUDE.md` section 8, FUT-02 |
| 13 | Privacy text refers to the repealed Swedish act and to processing outside the EEA. | GDPR | LEG-02 |
| 14 | Help text on references contradicts the code. | Wrong user expectations | REF-02, DEC-14 |
| 15 | Heavy commercial platform for a simple domain; search in a separate engine. | Cost, complexity | `CLAUDE.md` section 2 |

## Not verified

Some inherited platform modules (order, cart, catalog, customer and back-office screens) were **not read in depth**. Where this spec says something about them, it is based on the code that calls them. Check anything marked `[Observed]` in `05` and `06` against a running prototype if one can be started.

# 05 Purchase and access to contact details

The buyer **pays for access** to a consultant's contact details, CV and presentation. Consultants and consulting companies use the service for free.
*Marketing text: "Affordable rates. We only charge a once-off fee." / "eRimedo.com is free of charge for consultants and consulting companies."*

In the prototype the thing sold was a catalog product (the "CV"), bought through a shopping cart. In the new system the thing sold is an **entitlement** (see `CLAUDE.md` section 5). The flow below is what the buyer experiences.

## Flow

1. The buyer searches and adds one or more profiles to the **cart**.
2. The buyer signs in or signs up, then goes to **checkout**.
3. The buyer provides a billing address and chooses a payment method.
4. On success, the order is `Paid`, a **receipt** e-mail lists the consultants bought, and the buyer **immediately** sees names, contact details, CV and presentation.
5. Access lasts a **configured number of days** (the **access window**).

## Cart and checkout

- **PUR-01** `[Observed]` Cart operations: add a profile, remove one, clear the cart, view the cart. Quantity is meaningful only as 1 per profile.
- **PUR-02** `[Observed]` A buyer pays by one of: **card**, **invoice**, or the **company prepaid balance**. Invoice and prepaid balance are available **only to users with the Buyer role**. Card is available to any signed-in user.
  *Prototype gateways: PaysonCredit (card), Payson (invoice), AccountBalance (prepaid).*
- **PUR-03** `[Observed]` Billing address is collected at checkout. The prototype also supported a shipping step that is irrelevant here (nothing is shipped).
- **PUR-04** `[Observed]` If prepaid balance is chosen and the company balance is lower than the order total, checkout is refused with a clear message. The company can top up (`06-wallet-and-credits.md`).
- **PUR-05** `[Observed]` Coupon codes existed (inherited from the commerce platform). `[Decision]` whether we want promotions. See DEC-09.
- **PUR-06** `[Observed]` After successful payment the buyer lands on a "thanks" page offering immediate download.
- **PUR-07** `[Observed]` An unpaid order that is abandoned (for example after leaving to the payment provider and coming back) must not block a new order. The prototype deleted old `New` orders before creating a new credit order.
- **PUR-08** `[Change]` Every payment operation takes an **idempotency key**, so a retry or a double click cannot charge twice or grant access twice.
- **PUR-09** `[Change]` Payment providers are replaceable per market (`CLAUDE.md` section 4). Our own order and ledger records are the source of truth, not the provider's.
- **PUR-10** `[Observed]` Currency is SEK by default, with USD configured as a second currency. `[Change]` Multi-currency with VAT handling is built behind `ITaxPolicy`.
- **PUR-11** `[Decision made]` The buyer pays a **fixed fee per entitlement**, configured per market and currency. The consultant's hourly rate is separate and never sets the price. The prototype used the rate as the price. See DEC-01 and ADR-0001.

## Access to contact details and files

- **PUR-20** `[Observed]` Who may see contact details and download the CV and presentation of a consultant:
  1. the **consultant** themselves,
  2. their **company admin**,
  3. a **buyer who bought** the profile, within the access window,
  4. **every other buyer in the buyer's company**, within the same window. ("Bought CV is shared across all buyers of a company.")
- **PUR-21** `[Observed]` The access window is store configuration, `ResumeLifeCycleTimeSpan` days. The prototype's default in code is **30 days**. After it expires the buyer can no longer download.
- **PUR-22** `[Observed]` A buyer sees a page **"my available consultants"**: the distinct profiles bought by the buyer's company within the window, with download links for CV and presentation, paged.
- **PUR-23** `[Observed]` Contact details are **delivered by the system** (the buyer is told how to reach the consultant). The consultant is not notified of a purchase in the prototype.
- **PUR-24** `[Decision]` After the window, may the buyer still **see** the contact details they paid for, or only lose downloads? See DEC-03.
- **PUR-25** `[Decision]` Whether the consultant should be told when their details are bought, and by which company. Default: yes, in-app, without disclosing price. See DEC-10.
- **PUR-26** `[Change]` Every disclosure of contact details or file download is **audit-logged** (who, which consultant, when, under which entitlement).
- **PUR-27** `[Change]` Buying the same profile again while access is still valid MUST NOT charge twice. After expiry the buyer may re-buy.
- **PUR-28** `[Change]` A buyer MUST be able to buy only **published** profiles. If a profile is unpublished after being put in the cart, checkout removes it with a message.

## Refunds and failures

- **PUR-40** `[Observed]` The prototype had **no refund path** for prepaid balance (the refund method was not implemented).
- **PUR-41** `[Decision]` Refund policy, for example when a consultant turns out to be unavailable or the account was closed right after purchase. See DEC-11.
- **PUR-42** `[Change]` A failed or partial payment MUST leave neither an entitlement nor a ledger movement. Granting access and posting the ledger entries happen in one transaction.

## Receipts

- **PUR-50** `[Observed]` A receipt e-mail is sent on payment. It contains order number, date, total and currency, payment method, billing street, city and country, and a numbered list of the consultants bought (name or number and price), with a link to the order.
- **PUR-51** `[Change]` Invoices and receipts follow the market's tax rules (`ITaxPolicy`): seller details, VAT number, VAT amount.

## Acceptance examples

- *Given* two buyers in the same company and one of them bought profile P, *when* the other opens "my available consultants" within the window, *then* P is listed and downloadable.
- *Given* a buyer in a different company, *when* they request P's CV by direct URL, *then* access is refused.
- *Given* a payment confirmation arrives twice, *then* exactly one entitlement and one set of ledger entries exist.
- *Given* the window has expired, *then* downloads are refused with an explanation and an offer to buy again.

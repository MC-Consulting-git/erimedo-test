# 04 Search

Buyers describe what they need and instantly see which consultants are available. **Anyone can search without an account.** An account is needed only to buy.
*Help text: "Anyone can search for a consultant in eRimedo.com. You only need an account when you want to shop."*

In the new system a search is a **Need** (see `CLAUDE.md` section 5). The prototype behaviour below defines the **hard filters**. The scoring that ranks and explains near-misses is in `CLAUDE.md` section 8 and `12-future.md`.

## Criteria

| Criterion | Prototype behaviour (`[Observed]`) |
|---|---|
| Location | One or more (country, optional region, optional city). A profile matches if it matches **any** selected location. "All countries" switches the location filter off. At least one location is required unless "all countries" is chosen. |
| Skills | One or more. Each has a skill, a **minimum level** (1 to 5) and a **last-used constraint**. A profile must match **every** skill entered. |
| Last used | Per skill: a date plus a comparison (later than, later than or equal, earlier than, earlier than or equal). In the UI this is "how long ago the consultant may last have used it". |
| Available from | The date the buyer needs the consultant. A profile matches if its available-from date is **on or before** that date. |
| Maximum rate per hour | A single maximum, applied as the range 0 to max. (Design review: it is a maximum, **not** a range.) |
| Part-time | If ticked, only profiles that accept part-time assignments match. |
| Must have references | If ticked, only profiles with at least one reference match. |
| Free text | A keyword phrase searched in profile content. |

- **SRC-01** `[Observed]` All criteria combine with **AND**, except locations, which combine with OR.
- **SRC-02** `[Observed]` Only **published** profiles appear. Unpublished and closed-account profiles never match.
- **SRC-03** `[Observed]` Level means "at least this level": a level-4 consultant matches a level-3 requirement.
- **SRC-04** `[Observed]` Default sort is by **price ascending**. A sort control existed in the template but was commented out. Results can be shown as grid or list.
- **SRC-05** `[Observed]` Results are paged. Page size is a request parameter.
- **SRC-06** `[Observed]` The skill picker uses the same hierarchical taxonomy as the profile (`03-consultant-profile.md`).
- **SRC-07** `[Intended]` Selecting a skill offers the key to the 1 to 5 level scale beside it.
- **SRC-08** `[Intended]` "The number of search criteria is not infinite, but they cover the majority of all requirements. Should a user lack a criterion, we will gladly add it." Criteria are therefore **data-driven** and new ones must be cheap to add (see vertical configuration, `CLAUDE.md` section 4).
- **SRC-09** `[Change]` A search that finds nothing MUST say which criteria excluded the most profiles and offer to relax them. (Basis for near-match results, `12-future.md` FUT-02.)
- **SRC-10** `[Change]` Search MUST be fast enough to feel instant on the expected catalogue size. Target: a result page in under 500 ms at the 95th percentile for up to 100,000 profiles on PostgreSQL.
- **SRC-11** `[Change]` The search API MUST NOT be usable to harvest the catalogue. Anonymous search is rate-limited and returns only the pre-purchase view below.

## What a buyer sees before paying (the pre-purchase view)

This is the commercial heart of the product: contact details are what is sold.

- **SRC-20** `[Observed]` Search results and the detail panel show: the **consultant number**, hourly rate, available-from date, number of references, the consultant's average **rating** (stars) if reviewed, and the locations they will work in.
  *Help text: "Detailed information: shows the number of references; the consultant number; date available; hourly rate; average score; locations."*
- **SRC-21** `[Intended]` Skills with level and last-used are shown, since the buyer searched on them.
- **SRC-22** `[Observed]` The buyer can add a profile to the **shopping cart** from the results ("Add"), or open more information ("Show").
- **SRC-23** `[Change]` Before purchase the result MUST NOT contain the person's name, e-mail, phone, address, photo, CV or presentation, in the page, in an API response or in any cached data.
- **SRC-24** `[Decision]` Whether a first name or initials may be shown before purchase. Default: no. See DEC-02.

## Counters on the start page

- **SRC-30** `[Intended]` The home page shows two numbers: **consultants registered** and **consultants available within 30 days** (design "Consultant counter").
- **SRC-31** `[Change]` The counters count only published profiles and are cached.

## Naming trap in the prototype

The word **rate** meant two different things: the consultant's **hourly rate** (money) and the **average review rating** (stars). New code and UI copy MUST use two different words: `HourlyRate` and `Rating`.

## Acceptance examples

- *Given* a profile with skill "Project Management" at level 4, last used 2 months ago, *when* a buyer requires level 3 with last use within 12 months, *then* the profile matches.
- *Given* a buyer who ticks "part-time" and "must have references", *when* the search runs, *then* only profiles satisfying both appear.
- *Given* an unpublished profile that satisfies every criterion, *then* it never appears.
- *Given* an anonymous visitor, *when* they inspect the search response, *then* it contains no personal contact data.

# eRimedo functional specification

This specification describes **what the system does**, distilled from the 2016 prototype (a Niteco/VirtoCommerce build of "Cifereca resource broker", last commit `59c55209`, 2016-11-21), its help pages, design mockups and the "Future releases" notes.
It is the source of truth for *behaviour*. It is **not** a design: how to build it is in `CLAUDE.md` and `docs/adr/`.

## How to read it

Every requirement has an id and a status tag.

| Tag | Meaning |
|---|---|
| `[Observed]` | The prototype code does this. Verified by reading the code. |
| `[Intended]` | Stated in help pages, marketing text, design mockups or user agreement, but not (fully) visible in code. |
| `[Change]` | Deliberate difference from the prototype, usually a fix. Follow this, not the prototype. |
| `[Future]` | Planned, not built. Do not build before the core is done. |
| `[Decision]` | An open question. **Do not guess; ask.** Collected in `10-open-decisions.md`. |

Ids use a prefix per file (`ACC-`, `ORG-`, `PRO-`, `TAX-`, `SRC-`, `PUR-`, `WAL-`, `REV-`, `NTF-`, `CNT-`, `INT-`, `FUT-`, `DEC-`). Reference them in tests, ADRs and pull requests.

Wording: **MUST** and **MUST NOT** are binding, **SHOULD** is a strong default, **MAY** is optional.

## Files

| File | Covers |
|---|---|
| `01-roles-and-accounts.md` | Actors, roles, sign-up, e-mail confirmation, login, password, account update, account deletion |
| `02-organizations.md` | Company creation and linking, invitations, approvals, admins, removal, company deletion |
| `03-consultant-profile.md` | Profile fields, skills with level and last-used, locations, rate, availability, publishing, CV and presentation, taxonomy |
| `04-search.md` | Buyer search criteria, results, what is visible before purchase, sorting, counters |
| `05-purchase-and-access.md` | Cart, checkout, payment methods, access to contact details and CV, download window |
| `06-wallet-and-credits.md` | Prepaid company balance and credit top-up |
| `07-reviews-and-references.md` | Reviews by buyers and references provided by consultants |
| `08-notifications.md` | In-app notification centre and the e-mail catalogue |
| `09-content-localization-legal.md` | Pages, news, languages, currencies, user agreement and privacy |
| `10-open-decisions.md` | Contradictions found in the prototype and decisions we must take |
| `11-prototype-defects.md` | Things the prototype does wrong that we must not reproduce, as testable requirements |
| `12-future.md` | Planned features from "Future releases" and the design comments |

## Scope and honesty about confidence

- Read thoroughly: account, company, invitation, consultant profile, file, cart, credit, notification and e-mail flows, plus all help and legal pages and the seed data.
- **Not read in depth:** the inherited VirtoCommerce modules (marketing, helpdesk, quotes, fulfilment, inventory, tax, generic payment gateways). Nothing in eRimedo's own flows depended on them, so they are out of scope.
- Some behaviours (for example exact file-type limits for CV upload) are not enforced anywhere visible. They are marked `[Decision]` rather than assumed.
- The seed data contains **a taxonomy only: 1,221 categories and zero consultant profiles**. There are no real consultants or orders to learn from or migrate.

## Provenance

Prototype references appear as `Prototype: <file> → <method>` so an engineer can find the original behaviour. They are for understanding, never for copying. The 2016 code, its VirtoCommerce data model and its dynamic-property conventions (`productId`, `customerType`, and so on) must not be reused.

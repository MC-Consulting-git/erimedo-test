# 07 Reviews and references

Two different things share one idea of trust. The prototype and its texts mixed them up, so they are separated here.

| | Reviews | References |
|---|---|---|
| Written by | A **buyer** who bought the consultant | The **consultant** supplies them |
| Content | Rating 1 to 5 (optional) and text | Name, phone, e-mail and comment of a person who can vouch |
| Shown | Average rating in search; text on the profile | A **count** in search ("has references"); details only after purchase |

## Reviews

- **REV-01** `[Observed]` A buyer may review a consultant **only if they, or someone in their company, bought that consultant**.
- **REV-02** `[Observed]` **One review per buyer per consultant.** A buyer can edit their own review.
- **REV-03** `[Observed]` The **rating** (1 to 5) is optional. A review can be text only.
- **REV-04** `[Observed]` Search and profile show the **average rating** (stars) and the count of reviews.
- **REV-05** `[Change]` Reviews are tied to an **entitlement**. The check is on the server. (`CLAUDE.md` section 6.)
- **REV-06** `[Change]` The consultant may **respond** to a review once and may **report** one as abusive. A site admin can hide a review after report. Hidden reviews do not count in the average.
- **REV-07** `[Change]` A review shows the reviewer's **company name or "a buyer"**, per setting. It never shows the reviewer's contact details.
- **REV-08** `[Change]` When a reviewer's account is deleted, the review stays, anonymised (ACC-41).
- **REV-09** `[Decision]` Do reviews expire, or only count if recent? Should a minimum number of reviews be required before showing an average? See DEC-13.

## References

- **REF-01** `[Observed]` In the prototype code, a reference is a **contact person the consultant adds**: name, phone, e-mail and a comment. Adding at least one sets the `hasReference` flag used in search.
- **REF-02** `[Observed]` **The help text says something different:** it describes references as being given by buyers. The code does not do this. That belongs to **reviews**.
  `[Decision]` Confirm that the above separation is what was intended. See DEC-14.
- **REF-03** `[Change]` Reference contact details are personal data of a third party. They MUST be shown only after purchase, with an audit record, and the consultant MUST confirm they have the person's consent to be named.
- **REF-04** `[Change]` The reference's e-mail MAY be used to send them a single request to confirm. A confirmed reference shows a "confirmed" mark. No marketing use.
- **REF-05** `[Change]` The consultant can remove a reference at any time; the buyer's earlier access to details is not revoked.

## Acceptance examples

- *Given* a buyer who never bought a consultant, *when* they post a review, *then* it is refused.
- *Given* a buyer who already reviewed a consultant, *when* they post again, *then* their existing review is edited, not duplicated.
- *Given* a colleague of the buyer, *when* they review, *then* it is allowed once for themselves, because the entitlement is the company's.
- *Given* an anonymous visitor, *when* they open a profile, *then* they see the count of references but no names or numbers.

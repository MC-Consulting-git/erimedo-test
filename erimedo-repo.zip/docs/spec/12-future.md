# 12 Future and design ideas

Requirements that did **not** exist in the 2016 code but come from the owner's design notes and the roadmap in `CLAUDE.md` section 9. Everything here is `[Future]` unless stated. Build the first version so that these fit without a rewrite.

## FUT-01 Needs and saved searches

- A **Need** is a structured requirement: skills (level, last used), maximum rate, available-from, part-time, location or remote, weights.
- A buyer (or any user) can **save** a need, **share** it by link and **forward it to purchasing**.
- The person who has the need may not be the one who buys. A forwarded need opens for the purchaser with the same criteria and results.
- Selected criteria are shown in a frame above the results, **editable and removable** one by one. Design wording: "Max rate per hour", "available from", skills as tags.

## FUT-02 Almost matches

- When no consultant fulfils all criteria, show the **closest** ones with an **explanation per criterion** ("missing Kubernetes", "available 2 weeks later", "rate 10 % above your maximum").
- The scoring follows `CLAUDE.md` section 8: one-sided penalties, 0 to 1 per criterion, weights per need, versioned configuration, stored with each result.
- The owner's 2016 spreadsheet defines the **intent** (distance, price, availability, skill level, last used, missing skill, each with a weight). Its numbers are **not** reused. Example total in the sheet: 74,142.35, built from mixed units. See `11-prototype-defects.md` #12.
- A **golden set** of needs and consultants with expected rankings is created first, with the owner's judgement of what a good ranking is.

## FUT-03 Alerts in both directions

- A saved need notifies the buyer when a **new or newly available consultant** matches.
- A new need notifies **available consultants** who match, **through the platform only**, never revealing the buyer's identity before the buyer chooses.
- Frequency limits and opt-out are required (NTF-16).

## FUT-04 CV import with AI

- The consultant uploads a CV. An AI model **proposes** skills, levels and last-used dates. The consultant **confirms or edits** each one.
- Requires recorded consent (LEG-04). EU-hosted processing only. The CV text is not kept by the provider.
- Proposed skills map to the taxonomy; unknown ones go to moderation (PRO-15).

## FUT-05 Profile from a LinkedIn link

- A consultant may give a LinkedIn link instead of a CV. Skills are proposed as in FUT-04.
- **Contact details always come from eRimedo**, never from the linked page.
- `[Decision]` Terms of use of LinkedIn data must be checked before any automated reading. Until then, the link is stored and shown after purchase only.

## FUT-06 Consultant counter

- Home page numbers: consultants registered and available within 30 days (SRC-30).

## FUT-07 Incoming requests by e-mail or text

- Parse a request received by e-mail or text into a Need. A **human approves** before anything is sent or saved for another person.

## FUT-08 More verticals

- A vertical is data: taxonomy, level scale, optional extra attributes (`CLAUDE.md` section 4). The test that proves it: a second, non-IT vertical seeded without changing the matching engine.

## FUT-09 Further market adapters

- New country: registry adapter, tax policy, identity (national eID), payment, legal pages, e-mail templates and skills in the local language.

## FUT-10 Outcome logging for calibration

- Log shown, opened, added to cart, purchased, contacted. Used to tune weights, **not** to train an opaque model (`CLAUDE.md` section 8, EU AI Act caveat).

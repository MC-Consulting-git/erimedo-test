using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace Erimedo.Host.Authentication;

internal static class AuthenticationSetup
{
    public const string UnconfiguredScheme = "Unconfigured";
    public const string DefaultSubjectClaim = "sub";

    /// <summary>
    /// Sign-in is delegated to an external identity provider (ADR-0008); we validate its tokens and do not
    /// store passwords. Configure <c>Authentication:Authority</c> and <c>Authentication:Audience</c>. Without
    /// them no token is accepted and every protected endpoint answers 401 (fail closed).
    /// <c>Authentication:SubjectClaim</c> names the claim that identifies the person (default "sub").
    /// </summary>
    public static IServiceCollection AddErimedoAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var authority = configuration["Authentication:Authority"];
        var audience = configuration["Authentication:Audience"];

        if (string.IsNullOrWhiteSpace(authority) || string.IsNullOrWhiteSpace(audience))
        {
            services.AddAuthentication(UnconfiguredScheme)
                .AddScheme<AuthenticationSchemeOptions, UnconfiguredHandler>(UnconfiguredScheme, _ => { });
        }
        else
        {
            services.AddAuthentication(Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.Authority = authority;
                    options.Audience = audience;
                    options.MapInboundClaims = false;
                    options.RequireHttpsMetadata = true;
                });
        }

        services.AddAuthorization();
        return services;
    }

    public static string SubjectClaimName(IConfiguration configuration) =>
        configuration["Authentication:SubjectClaim"] is { Length: > 0 } name ? name : DefaultSubjectClaim;

    private sealed class UnconfiguredHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder)
        : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
    {
        protected override Task<AuthenticateResult> HandleAuthenticateAsync() => Task.FromResult(AuthenticateResult.NoResult());
    }
}

/// <summary>Finds the signed-in person's id from the validated token. The id never comes from the request body.</summary>
internal sealed class CurrentPerson(IConfiguration configuration, Erimedo.Modules.Identity.Contracts.IPersonDirectory persons)
{
    public async Task<Guid?> ResolveAsync(ClaimsPrincipal user, CancellationToken cancellationToken)
    {
        var subject = user.FindFirst(AuthenticationSetup.SubjectClaimName(configuration))?.Value;
        return string.IsNullOrWhiteSpace(subject) ? null : await persons.GetOrCreatePersonAsync(subject, cancellationToken);
    }
}

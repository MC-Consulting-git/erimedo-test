using Erimedo.Host.Components;
using Erimedo.Host.Composition;
using Erimedo.Host.Endpoints;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddErimedoModules(builder.Configuration);
builder.Services.AddRazorComponents();

var app = builder.Build();

// For development: apply migrations at start. Production applies them with a migration bundle.
if (app.Configuration.GetValue<bool>("Database:MigrateOnStartup"))
{
    await ServiceRegistration.MigrateModulesAsync(app.Services, CancellationToken.None);
}

app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));
app.MapConsultantAccessEndpoints();
app.MapRazorComponents<App>();

app.Run();

// Lets the integration tests start the real application.
public partial class Program;

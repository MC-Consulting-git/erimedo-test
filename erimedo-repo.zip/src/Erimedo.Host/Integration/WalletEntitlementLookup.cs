using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Wallet.Contracts;

namespace Erimedo.Host.Integration;

/// <summary>
/// Connects Profiles to Wallet. Neither module knows the other; only the composition root does.
/// </summary>
internal sealed class WalletEntitlementLookup(IEntitlementService wallet) : IEntitlementLookup
{
    public async Task<EntitlementProof?> FindActiveAsync(
        Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken)
    {
        var active = await wallet.FindActiveEntitlementAsync(organizationId, consultantProfileId, cancellationToken);
        return active is null ? null : new EntitlementProof(active.EntitlementId, active.ExpiresAt);
    }
}

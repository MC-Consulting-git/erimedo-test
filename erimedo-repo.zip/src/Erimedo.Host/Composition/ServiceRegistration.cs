using Erimedo.Host.Authentication;
using Erimedo.Host.Integration;
using Erimedo.Modules.Content;
using Erimedo.Modules.Identity;
using Erimedo.Modules.Matching;
using Erimedo.Modules.Needs;
using Erimedo.Modules.Notifications;
using Erimedo.Modules.Organizations;
using Erimedo.Modules.Profiles;
using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Reviews;
using Erimedo.Modules.Taxonomy;
using Erimedo.Modules.Wallet;

namespace Erimedo.Host.Composition;

internal static class ServiceRegistration
{
    /// <summary>
    /// The composition root: the only place that knows every module and connects them to each other.
    /// Shared by the application and by the integration tests, so the tests exercise the real wiring.
    /// </summary>
    public static IServiceCollection AddErimedoModules(this IServiceCollection services, IConfiguration configuration)
    {
        services
            .AddIdentityModule(configuration)
            .AddOrganizationsModule()
            .AddProfilesModule(configuration)
            .AddTaxonomyModule()
            .AddMatchingModule()
            .AddNeedsModule()
            .AddWalletModule(configuration)
            .AddReviewsModule()
            .AddNotificationsModule()
            .AddContentModule();

        services.AddErimedoAuthentication(configuration);
        services.AddScoped<CurrentPerson>();

        // Profiles asks "does this organization have access?"; Wallet answers. Neither knows the other.
        services.AddScoped<IEntitlementLookup, WalletEntitlementLookup>();
        return services;
    }

    /// <summary>Applies every module's migrations. For development and tests; production uses a migration bundle.</summary>
    public static async Task MigrateModulesAsync(IServiceProvider services, CancellationToken cancellationToken)
    {
        await IdentityModule.MigrateDatabaseAsync(services, cancellationToken);
        await WalletModule.MigrateDatabaseAsync(services, cancellationToken);
        await ProfilesModule.MigrateDatabaseAsync(services, cancellationToken);
    }
}

using Erimedo.Host.Authentication;
using Erimedo.Modules.Identity.Contracts;
using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Shared;

namespace Erimedo.Host.Endpoints;

internal static class ConsultantAccessEndpoints
{
    public const string IdempotencyHeader = "Idempotency-Key";

    public static IEndpointRouteBuilder MapConsultantAccessEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/consultants").RequireAuthorization();
        group.MapPost("/{profileId:guid}/purchase", PurchaseAsync);
        group.MapGet("/{profileId:guid}/contact", GetContactAsync);
        return app;
    }

    // The organization comes from the person's membership on the server. Any organization id in the
    // request is ignored, so a client cannot spend or read on behalf of someone else's company.
    private static async Task<IResult> PurchaseAsync(
        Guid profileId,
        HttpContext http,
        CurrentPerson currentPerson,
        IMembershipAuthorizer authorizer,
        IEntitlementService entitlements,
        CancellationToken cancellationToken)
    {
        var idempotencyKey = http.Request.Headers[IdempotencyHeader].ToString();
        if (string.IsNullOrWhiteSpace(idempotencyKey))
        {
            return Error(StatusCodes.Status400BadRequest, "purchase.idempotency_key_required", $"The {IdempotencyHeader} header is required.");
        }

        var access = await RequireBuyerAsync(http, currentPerson, authorizer, cancellationToken);
        if (access.Failure is not null)
        {
            return access.Failure;
        }

        var result = await entitlements.PurchaseAsync(
            new PurchaseEntitlementRequest(access.Value!.OrganizationId, access.Value.PersonId, profileId, idempotencyKey),
            cancellationToken);
        return result.IsSuccess
            ? Results.Ok(result.Value)
            : Error(StatusFor(result.Error!.Code), result.Error.Code, result.Error.Message);
    }

    private static async Task<IResult> GetContactAsync(
        Guid profileId,
        HttpContext http,
        CurrentPerson currentPerson,
        IMembershipAuthorizer authorizer,
        IContactDisclosureService disclosure,
        CancellationToken cancellationToken)
    {
        var access = await RequireBuyerAsync(http, currentPerson, authorizer, cancellationToken);
        if (access.Failure is not null)
        {
            return access.Failure;
        }

        // Contact details are personal data: no shared cache may store them.
        http.Response.Headers.CacheControl = "no-store";

        var result = await disclosure.DiscloseAsync(
            new DisclosureRequest(access.Value!.OrganizationId, access.Value.PersonId, profileId), cancellationToken);
        return result.IsSuccess
            ? Results.Ok(result.Value)
            : Error(StatusFor(result.Error!.Code), result.Error.Code, result.Error.Message);
    }

    private static async Task<(OrganizationAccess? Value, IResult? Failure)> RequireBuyerAsync(
        HttpContext http, CurrentPerson currentPerson, IMembershipAuthorizer authorizer, CancellationToken cancellationToken)
    {
        var person = await currentPerson.ResolveAsync(http.User, cancellationToken);
        if (person is null)
        {
            return (null, Error(StatusCodes.Status401Unauthorized, "authentication.no_subject", "The token does not identify a person."));
        }

        var access = await authorizer.RequireRoleAsync(person.Value, MembershipRole.Buyer, cancellationToken);
        return access.IsSuccess
            ? (access.Value, null)
            : (null, Error(StatusCodes.Status403Forbidden, access.Error!.Code, access.Error.Message));
    }

    private static int StatusFor(string code) => code switch
    {
        "purchase.invalid_request" or "disclosure.invalid_request" => StatusCodes.Status400BadRequest,
        "wallet.insufficient_funds" => StatusCodes.Status402PaymentRequired,
        "purchase.idempotency_conflict" => StatusCodes.Status409Conflict,
        "disclosure.not_found" => StatusCodes.Status404NotFound,
        "disclosure.no_entitlement" => StatusCodes.Status403Forbidden,
        _ => StatusCodes.Status400BadRequest,
    };

    // Error bodies carry a code and a fixed message, never personal data.
    private static IResult Error(int status, string code, string message) =>
        Results.Json(new { code, message }, statusCode: status);
}

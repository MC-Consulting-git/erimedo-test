namespace Erimedo.Shared;

/// <summary>An expected failure. Bugs throw; expected failures are returned as an Error.</summary>
public sealed record Error(string Code, string Message);

public class Result
{
    protected Result(Error? error) => Error = error;

    public bool IsSuccess => Error is null;
    public bool IsFailure => Error is not null;
    public Error? Error { get; }

    public static Result Success() => new(null);
    public static Result Failure(Error error) => new(error ?? throw new ArgumentNullException(nameof(error)));
    public static Result Failure(string code, string message) => Failure(new Error(code, message));
}

public sealed class Result<T> : Result
{
    private readonly T? _value;

    private Result(T value) : base(null) => _value = value;
    private Result(Error error) : base(error) { }

    public T Value => IsSuccess
        ? _value!
        : throw new InvalidOperationException("Cannot read the value of a failed result.");

    public static Result<T> Success(T value) => new(value);
    public new static Result<T> Failure(Error error) => new(error ?? throw new ArgumentNullException(nameof(error)));
    public new static Result<T> Failure(string code, string message) => Failure(new Error(code, message));
}

namespace Erimedo.Shared;

/// <summary>An ISO 4217 style currency code. Always three upper-case letters.</summary>
public sealed record Currency
{
    private Currency(string code) => Code = code;

    public string Code { get; }

    public static Currency Sek { get; } = new("SEK");
    public static Currency Eur { get; } = new("EUR");

    public static Result<Currency> Create(string? code)
    {
        if (code is null || code.Length != 3 || !code.All(c => c is >= 'A' and <= 'Z'))
        {
            return Result<Currency>.Failure("currency.invalid", "A currency code is three upper-case letters.");
        }

        return Result<Currency>.Success(new Currency(code));
    }

    public override string ToString() => Code;
}

/// <summary>An amount of money in one currency. Uses decimal; never double or float.</summary>
public sealed record Money
{
    private Money(decimal amount, Currency currency)
    {
        Amount = amount;
        Currency = currency;
    }

    public decimal Amount { get; }
    public Currency Currency { get; }

    public bool IsZero => Amount == 0m;

    public static Money Of(decimal amount, Currency currency) =>
        new(amount, currency ?? throw new ArgumentNullException(nameof(currency)));

    public static Money Zero(Currency currency) => Of(0m, currency);

    // Mixing currencies is a programming error, not an expected failure, so these throw.
    public static Money operator +(Money left, Money right)
    {
        EnsureSameCurrency(left, right);
        return new Money(left.Amount + right.Amount, left.Currency);
    }

    public static Money operator -(Money left, Money right)
    {
        EnsureSameCurrency(left, right);
        return new Money(left.Amount - right.Amount, left.Currency);
    }

    public static Money operator -(Money value) => new(-value.Amount, value.Currency);

    public override string ToString() => $"{Amount} {Currency}";

    private static void EnsureSameCurrency(Money left, Money right)
    {
        if (left.Currency != right.Currency)
        {
            throw new InvalidOperationException(
                $"Cannot combine {left.Currency} and {right.Currency} without an explicit conversion.");
        }
    }
}

using Erimedo.Shared;

namespace Erimedo.Modules.Wallet.Contracts;

/// <summary>
/// The right to see a consultant's contact details and CV, bought by an organization.
/// The caller must have verified on the server that the buyer is a Buyer in that organization;
/// ids from the client are never trusted for ownership (CLAUDE.md section 6).
/// </summary>
public interface IEntitlementService
{
    /// <summary>
    /// Buys access. Ledger entries and the entitlement are created together or not at all.
    /// A retry with the same idempotency key returns the original. Buying a profile the organization
    /// already has active access to does not charge again.
    /// </summary>
    Task<Result<PurchaseReceipt>> PurchaseAsync(PurchaseEntitlementRequest request, CancellationToken cancellationToken);

    /// <summary>True while the organization's access to the consultant has not expired.</summary>
    Task<bool> HasActiveEntitlementAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken);

    /// <summary>The organization's active entitlement for the consultant, or null. Used to record which entitlement a disclosure happened under.</summary>
    Task<ActiveEntitlement?> FindActiveEntitlementAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken);
}

public sealed record ActiveEntitlement(Guid EntitlementId, DateTimeOffset ExpiresAt);

public sealed record PurchaseEntitlementRequest(
    Guid OrganizationId, Guid BuyerPersonId, Guid ConsultantProfileId, string IdempotencyKey);

/// <param name="Charged">False when the organization already had active access, so nothing was charged.</param>
/// <param name="IsReplay">True when this was a retry of an earlier request with the same key.</param>
public sealed record PurchaseReceipt(Guid EntitlementId, DateTimeOffset ExpiresAt, bool Charged, bool IsReplay);

using Erimedo.Shared;

namespace Erimedo.Modules.Wallet;

internal enum AccountKind
{
    /// <summary>What we owe a customer. Credits raise the balance, debits lower it. Must never go negative.</summary>
    CustomerWallet,
    /// <summary>Money received from a payment provider that is not yet in our hands.</summary>
    PaymentClearing,
    /// <summary>What we have earned from selling entitlements.</summary>
    Revenue,
}

internal sealed record LedgerAccount(string Code, AccountKind Kind);

internal enum Direction
{
    Debit,
    Credit,
}

internal sealed record LedgerLine(LedgerAccount Account, Direction Direction, Money Amount);

/// <summary>
/// One balanced posting. Immutable once created. Corrections are new transactions that reverse it.
/// </summary>
internal sealed class LedgerTransaction
{
    private LedgerTransaction(
        Guid id, string idempotencyKey, DateTimeOffset postedAt, string reference, IReadOnlyList<LedgerLine> lines)
    {
        Id = id;
        IdempotencyKey = idempotencyKey;
        PostedAt = postedAt;
        Reference = reference;
        Lines = lines;
    }

    public Guid Id { get; }
    public string IdempotencyKey { get; }
    public DateTimeOffset PostedAt { get; }
    public string Reference { get; }
    public IReadOnlyList<LedgerLine> Lines { get; }

    /// <summary>Rebuilds a transaction that was already validated when it was posted. Used by persistence only.</summary>
    internal static LedgerTransaction Rehydrate(
        Guid id, string idempotencyKey, DateTimeOffset postedAt, string reference, IReadOnlyList<LedgerLine> lines) =>
        new(id, idempotencyKey, postedAt, reference, lines);

    public static Result<LedgerTransaction> Create(
        string idempotencyKey, DateTimeOffset postedAt, string reference, IReadOnlyList<LedgerLine> lines)
    {
        if (string.IsNullOrWhiteSpace(idempotencyKey))
        {
            return Result<LedgerTransaction>.Failure("ledger.idempotency_key_required", "An idempotency key is required.");
        }

        if (lines is null || lines.Count < 2)
        {
            return Result<LedgerTransaction>.Failure("ledger.too_few_lines", "A transaction needs at least two lines.");
        }

        if (lines.Any(l => l.Amount.Amount <= 0m))
        {
            return Result<LedgerTransaction>.Failure("ledger.amount_not_positive", "Line amounts must be positive; direction carries the sign.");
        }

        // Double entry: per currency, debits must equal credits.
        foreach (var byCurrency in lines.GroupBy(l => l.Amount.Currency))
        {
            var debits = byCurrency.Where(l => l.Direction == Direction.Debit).Sum(l => l.Amount.Amount);
            var credits = byCurrency.Where(l => l.Direction == Direction.Credit).Sum(l => l.Amount.Amount);
            if (debits != credits)
            {
                return Result<LedgerTransaction>.Failure("ledger.unbalanced", $"Debits and credits differ in {byCurrency.Key}.");
            }
        }

        return Result<LedgerTransaction>.Success(
            new LedgerTransaction(Guid.NewGuid(), idempotencyKey, postedAt, reference ?? string.Empty, lines.ToArray()));
    }

    /// <summary>True when another request carries the same content, so a retry can be recognised.</summary>
    public bool HasSameContentAs(string reference, IReadOnlyList<LedgerLine> lines) =>
        Reference == reference && Lines.SequenceEqual(lines);
}

using Erimedo.Shared;

namespace Erimedo.Modules.Wallet;

/// <summary>The ledger rules in one place so the in-memory and PostgreSQL versions can be tested the same way.</summary>
internal interface ILedger
{
    Task<Result<PostOutcome>> PostAsync(LedgerTransaction transaction, CancellationToken cancellationToken);

    Task<Result<PostOutcome>> ReverseAsync(
        Guid transactionId, string idempotencyKey, DateTimeOffset postedAt, CancellationToken cancellationToken);

    Task<Money> BalanceAsync(LedgerAccount account, Currency currency, CancellationToken cancellationToken);

    /// <summary>All transactions that touch the account, oldest first. This is the basis of a statement.</summary>
    Task<IReadOnlyList<LedgerTransaction>> TransactionsForAccountAsync(
        LedgerAccount account, CancellationToken cancellationToken);
}

internal static class LedgerRules
{
    /// <summary>Wallet and revenue accounts grow with credits; clearing grows with debits.</summary>
    public static Direction Increasing(AccountKind kind) =>
        kind == AccountKind.PaymentClearing ? Direction.Debit : Direction.Credit;

    public static decimal Signed(AccountKind kind, Direction direction, decimal amount) =>
        direction == Increasing(kind) ? amount : -amount;
}

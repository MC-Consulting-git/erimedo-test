using Erimedo.Shared;

namespace Erimedo.Modules.Wallet;

internal sealed record PostOutcome(LedgerTransaction Transaction, bool WasAlreadyPosted);

/// <summary>
/// Append-only ledger held in memory. It defines the rules; a PostgreSQL implementation with the same
/// rules replaces it when persistence is added. Entries are never updated or removed.
/// </summary>
internal sealed class InMemoryLedger : ILedger
{
    private readonly object _gate = new();
    private readonly List<LedgerTransaction> _transactions = [];
    private readonly Dictionary<string, LedgerTransaction> _byKey = [];
    private readonly Dictionary<Guid, Guid> _reversedBy = [];

    public IReadOnlyList<LedgerTransaction> Transactions
    {
        get { lock (_gate) { return _transactions.ToArray(); } }
    }

    public Result<PostOutcome> Post(LedgerTransaction transaction)
    {
        ArgumentNullException.ThrowIfNull(transaction);

        lock (_gate)
        {
            if (_byKey.TryGetValue(transaction.IdempotencyKey, out var existing))
            {
                // A retry returns the original. The same key with different content is a client bug.
                return existing.HasSameContentAs(transaction.Reference, transaction.Lines)
                    ? Result<PostOutcome>.Success(new PostOutcome(existing, WasAlreadyPosted: true))
                    : Result<PostOutcome>.Failure("ledger.idempotency_conflict", "The key was used for a different request.");
            }

            var overdrawn = FindOverdrawnWallet(transaction);
            if (overdrawn is not null)
            {
                return Result<PostOutcome>.Failure("wallet.insufficient_funds", $"Insufficient funds in {overdrawn}.");
            }

            _transactions.Add(transaction);
            _byKey[transaction.IdempotencyKey] = transaction;
            return Result<PostOutcome>.Success(new PostOutcome(transaction, WasAlreadyPosted: false));
        }
    }

    /// <summary>Corrects a posted transaction by posting its mirror image. The original stays visible.</summary>
    public Result<PostOutcome> Reverse(Guid transactionId, string idempotencyKey, DateTimeOffset postedAt)
    {
        lock (_gate)
        {
            var original = _transactions.FirstOrDefault(t => t.Id == transactionId);
            if (original is null)
            {
                return Result<PostOutcome>.Failure("ledger.not_found", "The transaction does not exist.");
            }

            if (_reversedBy.TryGetValue(transactionId, out var reversalId))
            {
                // Same key as the reversal already posted is a harmless retry; anything else is a second reversal.
                if (_byKey.TryGetValue(idempotencyKey, out var prior) && prior.Id == reversalId)
                {
                    return Result<PostOutcome>.Success(new PostOutcome(prior, WasAlreadyPosted: true));
                }

                return Result<PostOutcome>.Failure("ledger.already_reversed", "The transaction is already reversed.");
            }

            var mirrored = original.Lines
                .Select(l => l with { Direction = l.Direction == Direction.Debit ? Direction.Credit : Direction.Debit })
                .ToArray();

            var created = LedgerTransaction.Create(idempotencyKey, postedAt, $"reversal of {original.Id}", mirrored);
            if (created.IsFailure)
            {
                return Result<PostOutcome>.Failure(created.Error!);
            }

            var posted = Post(created.Value);
            if (posted.IsSuccess && !posted.Value.WasAlreadyPosted)
            {
                _reversedBy[transactionId] = posted.Value.Transaction.Id;
            }

            return posted;
        }
    }

    public Money Balance(LedgerAccount account, Currency currency)
    {
        ArgumentNullException.ThrowIfNull(account);
        lock (_gate) { return BalanceCore(account, currency, extra: null); }
    }

    private LedgerAccount? FindOverdrawnWallet(LedgerTransaction candidate)
    {
        foreach (var account in candidate.Lines.Select(l => l.Account).Where(a => a.Kind == AccountKind.CustomerWallet).Distinct())
        {
            foreach (var currency in candidate.Lines.Where(l => l.Account == account).Select(l => l.Amount.Currency).Distinct())
            {
                if (BalanceCore(account, currency, candidate).Amount < 0m)
                {
                    return account;
                }
            }
        }

        return null;
    }

    private Money BalanceCore(LedgerAccount account, Currency currency, LedgerTransaction? extra)
    {
        var total = Money.Zero(currency);
        var all = extra is null ? _transactions : _transactions.Append(extra);
        foreach (var line in all.SelectMany(t => t.Lines).Where(l => l.Account == account && l.Amount.Currency == currency))
        {
            total += Money.Of(LedgerRules.Signed(account.Kind, line.Direction, line.Amount.Amount), currency);
        }

        return total;
    }

    public Task<Result<PostOutcome>> PostAsync(LedgerTransaction transaction, CancellationToken cancellationToken) =>
        Task.FromResult(Post(transaction));

    public Task<Result<PostOutcome>> ReverseAsync(
        Guid transactionId, string idempotencyKey, DateTimeOffset postedAt, CancellationToken cancellationToken) =>
        Task.FromResult(Reverse(transactionId, idempotencyKey, postedAt));

    public Task<Money> BalanceAsync(LedgerAccount account, Currency currency, CancellationToken cancellationToken) =>
        Task.FromResult(Balance(account, currency));

    public Task<IReadOnlyList<LedgerTransaction>> TransactionsForAccountAsync(
        LedgerAccount account, CancellationToken cancellationToken) =>
        Task.FromResult<IReadOnlyList<LedgerTransaction>>(
            Transactions.Where(t => t.Lines.Any(l => l.Account == account)).ToArray());
}

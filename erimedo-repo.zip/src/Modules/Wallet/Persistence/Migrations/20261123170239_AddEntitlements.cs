﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Erimedo.Modules.Wallet.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddEntitlements : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "entitlements",
                schema: "wallet",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    OrganizationId = table.Column<Guid>(type: "uuid", nullable: false),
                    ConsultantProfileId = table.Column<Guid>(type: "uuid", nullable: false),
                    PurchasedByPersonId = table.Column<Guid>(type: "uuid", nullable: false),
                    PurchasedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    ExpiresAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    LedgerTransactionId = table.Column<Guid>(type: "uuid", nullable: false),
                    IdempotencyKey = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_entitlements", x => x.Id);
                    table.CheckConstraint("ck_entitlements_expires_after_purchase", "\"ExpiresAt\" > \"PurchasedAt\"");
                    table.ForeignKey(
                        name: "FK_entitlements_ledger_transactions_LedgerTransactionId",
                        column: x => x.LedgerTransactionId,
                        principalSchema: "wallet",
                        principalTable: "ledger_transactions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_entitlements_IdempotencyKey",
                schema: "wallet",
                table: "entitlements",
                column: "IdempotencyKey",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_entitlements_LedgerTransactionId",
                schema: "wallet",
                table: "entitlements",
                column: "LedgerTransactionId");

            migrationBuilder.CreateIndex(
                name: "IX_entitlements_OrganizationId_ConsultantProfileId_ExpiresAt",
                schema: "wallet",
                table: "entitlements",
                columns: new[] { "OrganizationId", "ConsultantProfileId", "ExpiresAt" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "entitlements",
                schema: "wallet");
        }
    }
}

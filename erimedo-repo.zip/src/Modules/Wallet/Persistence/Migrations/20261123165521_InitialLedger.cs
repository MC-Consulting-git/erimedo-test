﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Erimedo.Modules.Wallet.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class InitialLedger : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "wallet");

            migrationBuilder.CreateTable(
                name: "ledger_transactions",
                schema: "wallet",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    IdempotencyKey = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    PostedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    Reference = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ledger_transactions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ledger_lines",
                schema: "wallet",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TransactionId = table.Column<Guid>(type: "uuid", nullable: false),
                    Position = table.Column<int>(type: "integer", nullable: false),
                    AccountCode = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    AccountKind = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false),
                    Direction = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    Amount = table.Column<decimal>(type: "numeric(19,4)", precision: 19, scale: 4, nullable: false),
                    Currency = table.Column<string>(type: "character(3)", fixedLength: true, maxLength: 3, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ledger_lines", x => x.Id);
                    table.CheckConstraint("ck_ledger_lines_amount_positive", "\"Amount\" > 0");
                    table.ForeignKey(
                        name: "FK_ledger_lines_ledger_transactions_TransactionId",
                        column: x => x.TransactionId,
                        principalSchema: "wallet",
                        principalTable: "ledger_transactions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ledger_reversals",
                schema: "wallet",
                columns: table => new
                {
                    OriginalTransactionId = table.Column<Guid>(type: "uuid", nullable: false),
                    ReversalTransactionId = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ledger_reversals", x => x.OriginalTransactionId);
                    table.ForeignKey(
                        name: "FK_ledger_reversals_ledger_transactions_OriginalTransactionId",
                        column: x => x.OriginalTransactionId,
                        principalSchema: "wallet",
                        principalTable: "ledger_transactions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ledger_reversals_ledger_transactions_ReversalTransactionId",
                        column: x => x.ReversalTransactionId,
                        principalSchema: "wallet",
                        principalTable: "ledger_transactions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ledger_lines_AccountCode_Currency",
                schema: "wallet",
                table: "ledger_lines",
                columns: new[] { "AccountCode", "Currency" });

            migrationBuilder.CreateIndex(
                name: "IX_ledger_lines_TransactionId_Position",
                schema: "wallet",
                table: "ledger_lines",
                columns: new[] { "TransactionId", "Position" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ledger_reversals_ReversalTransactionId",
                schema: "wallet",
                table: "ledger_reversals",
                column: "ReversalTransactionId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ledger_transactions_IdempotencyKey",
                schema: "wallet",
                table: "ledger_transactions",
                column: "IdempotencyKey",
                unique: true);

            // The ledger is append-only (CLAUDE.md section 6). The database enforces it, so a bug or a
            // manual statement cannot change or remove a posted entry. Corrections are reversing entries.
            migrationBuilder.Sql(@"
CREATE FUNCTION wallet.forbid_ledger_change() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'The wallet ledger is append-only: % on % is not allowed', TG_OP, TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;");
            foreach (var table in new[] { "ledger_transactions", "ledger_lines", "ledger_reversals" })
            {
                migrationBuilder.Sql($@"
CREATE TRIGGER {table}_append_only_rows BEFORE UPDATE OR DELETE ON wallet.{table}
    FOR EACH ROW EXECUTE FUNCTION wallet.forbid_ledger_change();
CREATE TRIGGER {table}_append_only_truncate BEFORE TRUNCATE ON wallet.{table}
    FOR EACH STATEMENT EXECUTE FUNCTION wallet.forbid_ledger_change();");
            }
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ledger_lines",
                schema: "wallet");

            migrationBuilder.DropTable(
                name: "ledger_reversals",
                schema: "wallet");

            migrationBuilder.DropTable(
                name: "ledger_transactions",
                schema: "wallet");
            migrationBuilder.Sql("DROP FUNCTION IF EXISTS wallet.forbid_ledger_change();");
        }
    }
}

using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Modules.Wallet.Entitlements;
using Erimedo.Shared;
using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Wallet.Persistence;

/// <summary>
/// Buys access in one database transaction: the ledger entries and the entitlement commit together or not
/// at all. Advisory locks serialise purchases of the same profile by the same organization, retries with the
/// same key, and spending from the same wallet. Use one instance (one DbContext) per unit of work.
/// </summary>
internal sealed class PostgresEntitlementService(WalletDbContext db, PurchasePolicy policy, TimeProvider time)
    : IEntitlementService
{
    public async Task<Result<PurchaseReceipt>> PurchaseAsync(PurchaseEntitlementRequest request, CancellationToken cancellationToken)
    {
        var valid = PurchaseRules.Validate(request);
        if (valid.IsFailure)
        {
            return Result<PurchaseReceipt>.Failure(valid.Error!);
        }

        var now = time.GetUtcNow();

        await using var scope = await db.Database.BeginTransactionAsync(cancellationToken);
        await AdvisoryLocks.AcquireAsync(db,
        [
            AdvisoryLocks.KeyFor(request.IdempotencyKey),
            AdvisoryLocks.EntitlementFor(request.OrganizationId, request.ConsultantProfileId),
            AdvisoryLocks.AccountFor(WalletAccounts.For(request.OrganizationId)),
        ], cancellationToken);

        var replay = await db.Entitlements.AsNoTracking()
            .SingleOrDefaultAsync(e => e.IdempotencyKey == request.IdempotencyKey, cancellationToken);
        if (replay is not null)
        {
            return replay.OrganizationId == request.OrganizationId && replay.ConsultantProfileId == request.ConsultantProfileId
                ? Result<PurchaseReceipt>.Success(new PurchaseReceipt(replay.Id, replay.ExpiresAt, Charged: true, IsReplay: true))
                : Result<PurchaseReceipt>.Failure("purchase.idempotency_conflict", "The key was used for a different request.");
        }

        var active = await db.Entitlements.AsNoTracking()
            .Where(e => e.OrganizationId == request.OrganizationId
                && e.ConsultantProfileId == request.ConsultantProfileId
                && e.ExpiresAt > now)
            .OrderByDescending(e => e.ExpiresAt)
            .FirstOrDefaultAsync(cancellationToken);
        if (active is not null)
        {
            return Result<PurchaseReceipt>.Success(new PurchaseReceipt(active.Id, active.ExpiresAt, Charged: false, IsReplay: false));
        }

        var transaction = PurchaseRules.BuildLedgerTransaction(request, policy, now);
        if (transaction.IsFailure)
        {
            return Result<PurchaseReceipt>.Failure(transaction.Error!);
        }

        // Joins the transaction above, so the ledger entries commit only if the entitlement is saved too.
        var posted = await new PostgresLedger(db).PostAsync(transaction.Value, cancellationToken);
        if (posted.IsFailure)
        {
            return Result<PurchaseReceipt>.Failure(posted.Error!);
        }

        var entitlement = new EntitlementRow
        {
            Id = Guid.NewGuid(),
            OrganizationId = request.OrganizationId,
            ConsultantProfileId = request.ConsultantProfileId,
            PurchasedByPersonId = request.BuyerPersonId,
            PurchasedAt = now.ToUniversalTime(),
            ExpiresAt = (now + policy.AccessWindow).ToUniversalTime(),
            LedgerTransactionId = posted.Value.Transaction.Id,
            IdempotencyKey = request.IdempotencyKey,
        };
        db.Entitlements.Add(entitlement);
        await db.SaveChangesAsync(cancellationToken);
        await scope.CommitAsync(cancellationToken);

        return Result<PurchaseReceipt>.Success(
            new PurchaseReceipt(entitlement.Id, entitlement.ExpiresAt, Charged: true, IsReplay: false));
    }

    public async Task<bool> HasActiveEntitlementAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken)
    {
        var now = time.GetUtcNow();
        return await db.Entitlements.AsNoTracking().AnyAsync(
            e => e.OrganizationId == organizationId && e.ConsultantProfileId == consultantProfileId && e.ExpiresAt > now,
            cancellationToken);
    }

    public async Task<ActiveEntitlement?> FindActiveEntitlementAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken)
    {
        var now = time.GetUtcNow();
        var active = await db.Entitlements.AsNoTracking()
            .Where(e => e.OrganizationId == organizationId && e.ConsultantProfileId == consultantProfileId && e.ExpiresAt > now)
            .OrderByDescending(e => e.ExpiresAt)
            .FirstOrDefaultAsync(cancellationToken);
        return active is null ? null : new ActiveEntitlement(active.Id, active.ExpiresAt);
    }
}

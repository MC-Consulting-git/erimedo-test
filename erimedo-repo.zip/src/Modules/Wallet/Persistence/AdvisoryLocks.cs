using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Wallet.Persistence;

/// <summary>
/// Transaction-scoped PostgreSQL advisory locks. They serialise work that must not run twice at once.
/// They are released at commit or rollback, and taking the same lock twice in one transaction is harmless.
/// </summary>
internal static class AdvisoryLocks
{
    public static string KeyFor(string idempotencyKey) => "key:" + idempotencyKey;

    public static string AccountFor(LedgerAccount account) => "account:" + account.Code;

    public static string EntitlementFor(Guid organizationId, Guid consultantProfileId) =>
        $"entitlement:{organizationId:N}:{consultantProfileId:N}";

    public static async Task AcquireAsync(DbContext db, IEnumerable<string> keys, CancellationToken cancellationToken)
    {
        // A fixed order avoids deadlocks when two units of work need several of the same locks.
        foreach (var key in keys.Distinct(StringComparer.Ordinal).OrderBy(k => k, StringComparer.Ordinal))
        {
            await db.Database.ExecuteSqlInterpolatedAsync(
                $"SELECT pg_advisory_xact_lock(hashtextextended({key}, 0))", cancellationToken);
        }
    }
}

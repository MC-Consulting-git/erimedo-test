using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Erimedo.Modules.Wallet.Persistence;

/// <summary>
/// Used only by the EF tools (dotnet ef migrations add). Creating a migration does not connect to a
/// database, so the fallback has no host, user or password. Real connections come from configuration.
/// </summary>
internal sealed class WalletDbContextFactory : IDesignTimeDbContextFactory<WalletDbContext>
{
    public WalletDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("ERIMEDO_DB") ?? "Database=erimedo_design_time";
        var options = new DbContextOptionsBuilder<WalletDbContext>()
            .UseNpgsql(connectionString, npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", WalletDbContext.Schema))
            .Options;
        return new WalletDbContext(options);
    }
}

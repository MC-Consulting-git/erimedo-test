using Erimedo.Shared;
using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Wallet.Persistence;

/// <summary>
/// PostgreSQL ledger. The same rules as <see cref="InMemoryLedger"/>. Each posting runs in one database
/// transaction. Advisory locks serialise postings that share an idempotency key, a wallet account or a
/// reversed transaction, so two concurrent purchases cannot both spend the same balance.
/// Not thread-safe: use one instance (one DbContext) per unit of work.
/// </summary>
internal sealed class PostgresLedger(WalletDbContext db) : ILedger
{
    public async Task<Result<PostOutcome>> PostAsync(LedgerTransaction transaction, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(transaction);

        // Join a transaction the caller already started (a purchase), so everything commits together.
        var owned = db.Database.CurrentTransaction is null
            ? await db.Database.BeginTransactionAsync(cancellationToken)
            : null;
        await using var ownedScope = owned;
        await AdvisoryLocks.AcquireAsync(db, LockKeysFor(transaction, extra: null), cancellationToken);

        var result = await PostCoreAsync(transaction, cancellationToken);
        if (owned is not null && result.IsSuccess && !result.Value.WasAlreadyPosted)
        {
            await owned.CommitAsync(cancellationToken);
        }

        // On failure or a replay nothing was written, so leaving the scope disposes (rolls back) harmlessly.
        return result;
    }

    public async Task<Result<PostOutcome>> ReverseAsync(
        Guid transactionId, string idempotencyKey, DateTimeOffset postedAt, CancellationToken cancellationToken)
    {
        // Posted transactions never change, so reading the original before locking is safe.
        var original = await LoadAsync(t => t.Id == transactionId, cancellationToken);
        if (original is null)
        {
            return Result<PostOutcome>.Failure("ledger.not_found", "The transaction does not exist.");
        }

        await using var scope = await db.Database.BeginTransactionAsync(cancellationToken);
        await AdvisoryLocks.AcquireAsync(db, LockKeysFor(original, extra: $"reverse:{transactionId}", idempotencyKey), cancellationToken);

        var existing = await db.Reversals.AsNoTracking()
            .SingleOrDefaultAsync(r => r.OriginalTransactionId == transactionId, cancellationToken);
        if (existing is not null)
        {
            // The same key as the reversal already posted is a harmless retry; anything else is a second reversal.
            var prior = await LoadAsync(t => t.Id == existing.ReversalTransactionId, cancellationToken);
            return prior is not null && prior.IdempotencyKey == idempotencyKey
                ? Result<PostOutcome>.Success(new PostOutcome(prior, WasAlreadyPosted: true))
                : Result<PostOutcome>.Failure("ledger.already_reversed", "The transaction is already reversed.");
        }

        var mirrored = original.Lines
            .Select(l => l with { Direction = l.Direction == Direction.Debit ? Direction.Credit : Direction.Debit })
            .ToArray();
        var created = LedgerTransaction.Create(idempotencyKey, postedAt, $"reversal of {original.Id}", mirrored);
        if (created.IsFailure)
        {
            return Result<PostOutcome>.Failure(created.Error!);
        }

        var posted = await PostCoreAsync(created.Value, cancellationToken);
        if (posted.IsFailure || posted.Value.WasAlreadyPosted)
        {
            return posted;
        }

        db.Reversals.Add(new ReversalRow
        {
            OriginalTransactionId = transactionId,
            ReversalTransactionId = posted.Value.Transaction.Id,
        });
        await db.SaveChangesAsync(cancellationToken);
        await scope.CommitAsync(cancellationToken);
        return posted;
    }

    public async Task<Money> BalanceAsync(LedgerAccount account, Currency currency, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(account);
        var amount = await SignedSumAsync(account, currency, cancellationToken);
        return Money.Of(amount, currency);
    }

    public async Task<IReadOnlyList<LedgerTransaction>> TransactionsForAccountAsync(
        LedgerAccount account, CancellationToken cancellationToken)
    {
        var rows = await db.Transactions.AsNoTracking()
            .Include(t => t.Lines)
            .Where(t => t.Lines.Any(l => l.AccountCode == account.Code))
            .OrderBy(t => t.PostedAt).ThenBy(t => t.Id)
            .ToListAsync(cancellationToken);
        return rows.Select(ToDomain).ToArray();
    }

    private async Task<Result<PostOutcome>> PostCoreAsync(LedgerTransaction transaction, CancellationToken cancellationToken)
    {
        var existing = await LoadAsync(t => t.IdempotencyKey == transaction.IdempotencyKey, cancellationToken);
        if (existing is not null)
        {
            // A retry returns the original. The same key with different content is a client bug.
            return existing.HasSameContentAs(transaction.Reference, transaction.Lines)
                ? Result<PostOutcome>.Success(new PostOutcome(existing, WasAlreadyPosted: true))
                : Result<PostOutcome>.Failure("ledger.idempotency_conflict", "The key was used for a different request.");
        }

        var overdrawn = await FindOverdrawnWalletAsync(transaction, cancellationToken);
        if (overdrawn is not null)
        {
            return Result<PostOutcome>.Failure("wallet.insufficient_funds", $"Insufficient funds in {overdrawn}.");
        }

        db.Transactions.Add(ToRow(transaction));
        await db.SaveChangesAsync(cancellationToken);
        return Result<PostOutcome>.Success(new PostOutcome(transaction, WasAlreadyPosted: false));
    }

    private async Task<string?> FindOverdrawnWalletAsync(LedgerTransaction candidate, CancellationToken cancellationToken)
    {
        var wallets = candidate.Lines
            .Where(l => l.Account.Kind == AccountKind.CustomerWallet)
            .Select(l => (l.Account, l.Amount.Currency))
            .Distinct();

        foreach (var (account, currency) in wallets)
        {
            var stored = await SignedSumAsync(account, currency, cancellationToken);
            var delta = candidate.Lines
                .Where(l => l.Account == account && l.Amount.Currency == currency)
                .Sum(l => LedgerRules.Signed(account.Kind, l.Direction, l.Amount.Amount));
            if (stored + delta < 0m)
            {
                return account.Code;
            }
        }

        return null;
    }

    private async Task<decimal> SignedSumAsync(LedgerAccount account, Currency currency, CancellationToken cancellationToken)
    {
        var increasing = LedgerRules.Increasing(account.Kind);
        var code = account.Code;
        var currencyCode = currency.Code;
        return await db.Lines.AsNoTracking()
            .Where(l => l.AccountCode == code && l.Currency == currencyCode)
            .SumAsync(l => l.Direction == increasing ? l.Amount : -l.Amount, cancellationToken);
    }

    internal static IEnumerable<string> LockKeysFor(LedgerTransaction transaction, string? extra, string? key = null)
    {
        yield return AdvisoryLocks.KeyFor(key ?? transaction.IdempotencyKey);
        foreach (var line in transaction.Lines.Where(l => l.Account.Kind == AccountKind.CustomerWallet))
        {
            yield return AdvisoryLocks.AccountFor(line.Account);
        }

        if (extra is not null)
        {
            yield return extra;
        }
    }

    private async Task<LedgerTransaction?> LoadAsync(
        System.Linq.Expressions.Expression<Func<TransactionRow, bool>> predicate, CancellationToken cancellationToken)
    {
        var row = await db.Transactions.AsNoTracking().Include(t => t.Lines).SingleOrDefaultAsync(predicate, cancellationToken);
        return row is null ? null : ToDomain(row);
    }

    private static TransactionRow ToRow(LedgerTransaction t) => new()
    {
        Id = t.Id,
        IdempotencyKey = t.IdempotencyKey,
        PostedAt = t.PostedAt.ToUniversalTime(),
        Reference = t.Reference,
        Lines = t.Lines.Select((l, i) => new LineRow
        {
            Id = Guid.NewGuid(),
            TransactionId = t.Id,
            Position = i,
            AccountCode = l.Account.Code,
            AccountKind = l.Account.Kind,
            Direction = l.Direction,
            Amount = l.Amount.Amount,
            Currency = l.Amount.Currency.Code,
        }).ToList(),
    };

    private static LedgerTransaction ToDomain(TransactionRow row)
    {
        var lines = row.Lines.OrderBy(l => l.Position).Select(l => new LedgerLine(
            new LedgerAccount(l.AccountCode, l.AccountKind),
            l.Direction,
            Money.Of(l.Amount, Currency.Create(l.Currency).Value))).ToArray();
        return LedgerTransaction.Rehydrate(row.Id, row.IdempotencyKey, row.PostedAt, row.Reference, lines);
    }
}

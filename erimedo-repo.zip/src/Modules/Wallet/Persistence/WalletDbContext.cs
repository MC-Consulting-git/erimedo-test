using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Wallet.Persistence;

internal sealed class TransactionRow
{
    public Guid Id { get; set; }
    public string IdempotencyKey { get; set; } = null!;
    public DateTimeOffset PostedAt { get; set; }
    public string Reference { get; set; } = null!;
    public List<LineRow> Lines { get; set; } = [];
}

internal sealed class LineRow
{
    public Guid Id { get; set; }
    public Guid TransactionId { get; set; }

    /// <summary>Order of the line inside its transaction. Kept so a retry can be compared line by line.</summary>
    public int Position { get; set; }
    public string AccountCode { get; set; } = null!;
    public AccountKind AccountKind { get; set; }
    public Direction Direction { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; } = null!;
}

internal sealed class ReversalRow
{
    public Guid OriginalTransactionId { get; set; }
    public Guid ReversalTransactionId { get; set; }
}

internal sealed class EntitlementRow
{
    public Guid Id { get; set; }
    public Guid OrganizationId { get; set; }
    public Guid ConsultantProfileId { get; set; }

    /// <summary>A pseudonymous id, not a name. Used for the audit trail of who bought.</summary>
    public Guid PurchasedByPersonId { get; set; }
    public DateTimeOffset PurchasedAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public Guid LedgerTransactionId { get; set; }
    public string IdempotencyKey { get; set; } = null!;
}

/// <summary>The Wallet module's own schema. No other module reads these tables.</summary>
internal sealed class WalletDbContext(DbContextOptions<WalletDbContext> options) : DbContext(options)
{
    public const string Schema = "wallet";

    public DbSet<TransactionRow> Transactions => Set<TransactionRow>();
    public DbSet<LineRow> Lines => Set<LineRow>();
    public DbSet<ReversalRow> Reversals => Set<ReversalRow>();
    public DbSet<EntitlementRow> Entitlements => Set<EntitlementRow>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);

        modelBuilder.Entity<TransactionRow>(e =>
        {
            e.ToTable("ledger_transactions");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.IdempotencyKey).HasMaxLength(200).IsRequired();
            e.Property(x => x.Reference).HasMaxLength(500).IsRequired();
            e.HasIndex(x => x.IdempotencyKey).IsUnique();
            e.HasMany(x => x.Lines).WithOne().HasForeignKey(x => x.TransactionId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<LineRow>(e =>
        {
            e.ToTable("ledger_lines", t => t.HasCheckConstraint("ck_ledger_lines_amount_positive", "\"Amount\" > 0"));
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.AccountCode).HasMaxLength(200).IsRequired();
            e.Property(x => x.AccountKind).HasConversion<string>().HasMaxLength(30);
            e.Property(x => x.Direction).HasConversion<string>().HasMaxLength(10);
            e.Property(x => x.Amount).HasPrecision(19, 4);
            e.Property(x => x.Currency).HasMaxLength(3).IsFixedLength().IsRequired();
            e.HasIndex(x => new { x.AccountCode, x.Currency });
            e.HasIndex(x => new { x.TransactionId, x.Position }).IsUnique();
        });

        modelBuilder.Entity<ReversalRow>(e =>
        {
            e.ToTable("ledger_reversals");
            e.HasKey(x => x.OriginalTransactionId);
            e.HasIndex(x => x.ReversalTransactionId).IsUnique();
            e.HasOne<TransactionRow>().WithMany().HasForeignKey(x => x.OriginalTransactionId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne<TransactionRow>().WithMany().HasForeignKey(x => x.ReversalTransactionId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<EntitlementRow>(e =>
        {
            e.ToTable("entitlements", t => t.HasCheckConstraint("ck_entitlements_expires_after_purchase", "\"ExpiresAt\" > \"PurchasedAt\""));
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.IdempotencyKey).HasMaxLength(200).IsRequired();
            e.HasIndex(x => x.IdempotencyKey).IsUnique();
            e.HasIndex(x => new { x.OrganizationId, x.ConsultantProfileId, x.ExpiresAt });
            e.HasOne<TransactionRow>().WithMany().HasForeignKey(x => x.LedgerTransactionId).OnDelete(DeleteBehavior.Restrict);
        });
    }
}

using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Shared;

namespace Erimedo.Modules.Wallet.Entitlements;

/// <summary>The purchase rules held in memory. The PostgreSQL version must behave identically.</summary>
internal sealed class InMemoryEntitlementService(InMemoryLedger ledger, PurchasePolicy policy, TimeProvider time)
    : IEntitlementService
{
    private sealed record Stored(
        Guid Id, Guid OrganizationId, Guid ConsultantProfileId, DateTimeOffset ExpiresAt, string IdempotencyKey);

    private readonly object _gate = new();
    private readonly List<Stored> _entitlements = [];

    public Task<Result<PurchaseReceipt>> PurchaseAsync(PurchaseEntitlementRequest request, CancellationToken cancellationToken)
    {
        var valid = PurchaseRules.Validate(request);
        if (valid.IsFailure)
        {
            return Task.FromResult(Result<PurchaseReceipt>.Failure(valid.Error!));
        }

        lock (_gate)
        {
            var now = time.GetUtcNow();

            var replay = _entitlements.FirstOrDefault(e => e.IdempotencyKey == request.IdempotencyKey);
            if (replay is not null)
            {
                return Task.FromResult(replay.OrganizationId == request.OrganizationId
                    && replay.ConsultantProfileId == request.ConsultantProfileId
                    ? Result<PurchaseReceipt>.Success(new PurchaseReceipt(replay.Id, replay.ExpiresAt, Charged: true, IsReplay: true))
                    : Result<PurchaseReceipt>.Failure("purchase.idempotency_conflict", "The key was used for a different request."));
            }

            var active = _entitlements
                .Where(e => e.OrganizationId == request.OrganizationId
                    && e.ConsultantProfileId == request.ConsultantProfileId
                    && e.ExpiresAt > now)
                .OrderByDescending(e => e.ExpiresAt)
                .FirstOrDefault();
            if (active is not null)
            {
                return Task.FromResult(Result<PurchaseReceipt>.Success(
                    new PurchaseReceipt(active.Id, active.ExpiresAt, Charged: false, IsReplay: false)));
            }

            var transaction = PurchaseRules.BuildLedgerTransaction(request, policy, now);
            if (transaction.IsFailure)
            {
                return Task.FromResult(Result<PurchaseReceipt>.Failure(transaction.Error!));
            }

            var posted = ledger.Post(transaction.Value);
            if (posted.IsFailure)
            {
                return Task.FromResult(Result<PurchaseReceipt>.Failure(posted.Error!));
            }

            var stored = new Stored(
                Guid.NewGuid(), request.OrganizationId, request.ConsultantProfileId,
                now + policy.AccessWindow, request.IdempotencyKey);
            _entitlements.Add(stored);
            return Task.FromResult(Result<PurchaseReceipt>.Success(
                new PurchaseReceipt(stored.Id, stored.ExpiresAt, Charged: true, IsReplay: false)));
        }
    }

    public Task<bool> HasActiveEntitlementAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken)
    {
        lock (_gate)
        {
            var now = time.GetUtcNow();
            return Task.FromResult(_entitlements.Any(e =>
                e.OrganizationId == organizationId && e.ConsultantProfileId == consultantProfileId && e.ExpiresAt > now));
        }
    }

    public Task<ActiveEntitlement?> FindActiveEntitlementAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken)
    {
        lock (_gate)
        {
            var now = time.GetUtcNow();
            var active = _entitlements
                .Where(e => e.OrganizationId == organizationId && e.ConsultantProfileId == consultantProfileId && e.ExpiresAt > now)
                .OrderByDescending(e => e.ExpiresAt)
                .FirstOrDefault();
            return Task.FromResult(active is null ? null : new ActiveEntitlement(active.Id, active.ExpiresAt));
        }
    }
}

using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Shared;

namespace Erimedo.Modules.Wallet.Entitlements;

/// <summary>What an entitlement costs and how long it lasts. Configuration, not code (ADR-0001, ADR-0006).</summary>
internal sealed record PurchasePolicy(Money Fee, TimeSpan AccessWindow)
{
    public const int DefaultAccessWindowDays = 30;

    public static Result<PurchasePolicy> Create(decimal feeAmount, string? currency, int accessWindowDays)
    {
        var parsed = Currency.Create(currency);
        if (parsed.IsFailure)
        {
            return Result<PurchasePolicy>.Failure(parsed.Error!);
        }

        if (feeAmount <= 0m)
        {
            return Result<PurchasePolicy>.Failure("purchase.fee_invalid", "The fee must be greater than zero.");
        }

        if (accessWindowDays <= 0)
        {
            return Result<PurchasePolicy>.Failure("purchase.window_invalid", "The access window must be at least one day.");
        }

        return Result<PurchasePolicy>.Success(
            new PurchasePolicy(Money.Of(feeAmount, parsed.Value), TimeSpan.FromDays(accessWindowDays)));
    }
}

internal static class WalletAccounts
{
    public static LedgerAccount For(Guid organizationId) =>
        new($"wallet:{organizationId:N}", AccountKind.CustomerWallet);

    public static LedgerAccount EntitlementRevenue { get; } = new("revenue:entitlements", AccountKind.Revenue);
}

internal static class PurchaseRules
{
    public static Result Validate(PurchaseEntitlementRequest request)
    {
        if (request is null
            || request.OrganizationId == Guid.Empty
            || request.BuyerPersonId == Guid.Empty
            || request.ConsultantProfileId == Guid.Empty
            || string.IsNullOrWhiteSpace(request.IdempotencyKey))
        {
            return Result.Failure("purchase.invalid_request", "Organization, buyer, consultant and idempotency key are required.");
        }

        return Result.Success();
    }

    /// <summary>Debit the organization's wallet, credit revenue. Tax lines come with the tax policy later.</summary>
    public static Result<LedgerTransaction> BuildLedgerTransaction(
        PurchaseEntitlementRequest request, PurchasePolicy policy, DateTimeOffset now) =>
        LedgerTransaction.Create(
            request.IdempotencyKey,
            now,
            $"entitlement:{request.ConsultantProfileId:N}",
            [
                new LedgerLine(WalletAccounts.For(request.OrganizationId), Direction.Debit, policy.Fee),
                new LedgerLine(WalletAccounts.EntitlementRevenue, Direction.Credit, policy.Fee),
            ]);
}

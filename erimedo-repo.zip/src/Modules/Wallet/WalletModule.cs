using Erimedo.Modules.Wallet.Contracts;
using Erimedo.Modules.Wallet.Entitlements;
using Erimedo.Modules.Wallet.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Wallet;

/// <summary>Entry point of the Wallet module. Everything else in the module is internal.</summary>
public static class WalletModule
{
    public const string ConnectionStringName = "Erimedo";
    public const string PurchaseSection = "Wallet:Purchase";

    /// <summary>
    /// Registers persistence when the connection string "Erimedo" is configured, and the entitlement service
    /// when the purchase policy is configured too:
    /// <c>Wallet:Purchase:FeeAmount</c>, <c>Wallet:Purchase:Currency</c> and optionally
    /// <c>Wallet:Purchase:AccessWindowDays</c> (default 30). There is deliberately no default price.
    /// Secrets and connection strings come from configuration or a secret store, never from the repository.
    /// </summary>
    public static IServiceCollection AddWalletModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString(ConnectionStringName);
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            return services;
        }

        services.AddDbContext<WalletDbContext>(options => options.UseNpgsql(
            connectionString,
            npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", WalletDbContext.Schema)));
        services.AddScoped<ILedger, PostgresLedger>();

        var section = configuration.GetSection(PurchaseSection);
        if (section.Exists())
        {
            var feeAmount = section.GetValue<decimal>("FeeAmount");
            var windowDays = section.GetValue("AccessWindowDays", PurchasePolicy.DefaultAccessWindowDays);
            var policy = PurchasePolicy.Create(feeAmount, section["Currency"], windowDays);
            if (policy.IsFailure)
            {
                // A misconfigured price must stop the application at start-up, not charge a wrong amount.
                throw new InvalidOperationException($"{PurchaseSection} is invalid: {policy.Error!.Message}");
            }

            services.AddSingleton(policy.Value);
            services.AddScoped<IEntitlementService, PostgresEntitlementService>();
        }

        return services;
    }

    /// <summary>Applies the module's migrations. For development and tests; production uses a migration bundle.</summary>
    public static async Task MigrateDatabaseAsync(IServiceProvider services, CancellationToken cancellationToken)
    {
        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetService<WalletDbContext>();
        if (db is not null)
        {
            await db.Database.MigrateAsync(cancellationToken);
        }
    }
}

using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Reviews;

/// <summary>Entry point of the Reviews module. Everything else in the module is internal.</summary>
public static class ReviewsModule
{
    public static IServiceCollection AddReviewsModule(this IServiceCollection services) => services;
}

using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Organizations;

/// <summary>Entry point of the Organizations module. Everything else in the module is internal.</summary>
public static class OrganizationsModule
{
    public static IServiceCollection AddOrganizationsModule(this IServiceCollection services) => services;
}

using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Taxonomy;

/// <summary>Entry point of the Taxonomy module. Everything else in the module is internal.</summary>
public static class TaxonomyModule
{
    public static IServiceCollection AddTaxonomyModule(this IServiceCollection services) => services;
}

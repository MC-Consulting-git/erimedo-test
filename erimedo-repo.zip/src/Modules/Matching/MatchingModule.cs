using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Matching;

/// <summary>Entry point of the Matching module. Everything else in the module is internal.</summary>
public static class MatchingModule
{
    public static IServiceCollection AddMatchingModule(this IServiceCollection services) => services;
}

using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Content;

/// <summary>Entry point of the Content module. Everything else in the module is internal.</summary>
public static class ContentModule
{
    public static IServiceCollection AddContentModule(this IServiceCollection services) => services;
}

using Erimedo.Modules.Identity.Contracts;
using Erimedo.Modules.Identity.Persistence;
using Erimedo.Shared;
using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Identity.Memberships;

internal sealed class PersonDirectory(IdentityDbContext db, TimeProvider time) : IPersonDirectory
{
    public async Task<Guid> GetOrCreatePersonAsync(string externalSubject, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(externalSubject);

        // Two first sign-ins at once must give one person. The unique index decides; the loser reads the winner.
        var id = Guid.NewGuid();
        var createdAt = time.GetUtcNow().ToUniversalTime();
        await db.Database.ExecuteSqlInterpolatedAsync(
            $"""
            INSERT INTO identity.persons ("Id", "ExternalSubject", "CreatedAt")
            VALUES ({id}, {externalSubject}, {createdAt})
            ON CONFLICT ("ExternalSubject") DO NOTHING
            """, cancellationToken);

        return await db.Persons.AsNoTracking()
            .Where(p => p.ExternalSubject == externalSubject)
            .Select(p => p.Id)
            .SingleAsync(cancellationToken);
    }
}

internal sealed class MembershipService(IdentityDbContext db, TimeProvider time) : IMembershipService, IMembershipAuthorizer
{
    public async Task<Membership?> GetMembershipAsync(Guid personId, CancellationToken cancellationToken)
    {
        var membership = await db.Memberships.AsNoTracking().SingleOrDefaultAsync(m => m.PersonId == personId, cancellationToken);
        if (membership is null)
        {
            return null;
        }

        var roles = await db.MembershipRoles.AsNoTracking()
            .Where(r => r.PersonId == personId)
            .Select(r => r.Role)
            .ToListAsync(cancellationToken);
        return new Membership(personId, membership.OrganizationId, roles);
    }

    public async Task<Result<OrganizationAccess>> RequireRoleAsync(
        Guid personId, MembershipRole role, CancellationToken cancellationToken)
    {
        var membership = await GetMembershipAsync(personId, cancellationToken);
        return membership is not null && membership.Roles.Contains(role)
            ? Result<OrganizationAccess>.Success(new OrganizationAccess(personId, membership.OrganizationId, role))
            : Result<OrganizationAccess>.Failure("authorization.forbidden", "The person is not allowed to do this.");
    }

    public async Task<Result> GrantRoleAsync(
        Guid personId, Guid organizationId, MembershipRole role, CancellationToken cancellationToken)
    {
        if (personId == Guid.Empty || organizationId == Guid.Empty || !Enum.IsDefined(role))
        {
            return Result.Failure("membership.invalid_request", "Person, organization and a valid role are required.");
        }

        await using var scope = await db.Database.BeginTransactionAsync(cancellationToken);
        await LockAsync(personId, organizationId, cancellationToken);

        if (!await db.Persons.AnyAsync(p => p.Id == personId, cancellationToken))
        {
            return Result.Failure("membership.person_not_found", "The person does not exist.");
        }

        var membership = await db.Memberships.SingleOrDefaultAsync(m => m.PersonId == personId, cancellationToken);
        if (membership is not null && membership.OrganizationId != organizationId)
        {
            return Result.Failure("membership.other_organization", "The person already belongs to another organization.");
        }

        if (membership is null)
        {
            db.Memberships.Add(new MembershipRow
            {
                PersonId = personId,
                OrganizationId = organizationId,
                CreatedAt = time.GetUtcNow().ToUniversalTime(),
            });
            await db.SaveChangesAsync(cancellationToken);
        }

        if (!await db.MembershipRoles.AnyAsync(r => r.PersonId == personId && r.Role == role, cancellationToken))
        {
            db.MembershipRoles.Add(new MembershipRoleRow { PersonId = personId, Role = role });
            await db.SaveChangesAsync(cancellationToken);
        }

        await scope.CommitAsync(cancellationToken);
        return Result.Success();
    }

    public async Task<Result> RevokeRoleAsync(
        Guid personId, Guid organizationId, MembershipRole role, CancellationToken cancellationToken)
    {
        await using var scope = await db.Database.BeginTransactionAsync(cancellationToken);
        await LockAsync(personId, organizationId, cancellationToken);

        var membership = await db.Memberships.SingleOrDefaultAsync(
            m => m.PersonId == personId && m.OrganizationId == organizationId, cancellationToken);
        var held = membership is null
            ? null
            : await db.MembershipRoles.SingleOrDefaultAsync(r => r.PersonId == personId && r.Role == role, cancellationToken);
        if (membership is null || held is null)
        {
            return Result.Failure("membership.role_not_held", "The person does not hold that role in the organization.");
        }

        if (role == MembershipRole.CompanyAdmin)
        {
            var admins = await (
                from r in db.MembershipRoles
                join m in db.Memberships on r.PersonId equals m.PersonId
                where m.OrganizationId == organizationId && r.Role == MembershipRole.CompanyAdmin
                select r.PersonId).CountAsync(cancellationToken);
            if (admins <= 1)
            {
                return Result.Failure("membership.last_admin", "An organization must keep at least one company admin.");
            }
        }

        db.MembershipRoles.Remove(held);
        await db.SaveChangesAsync(cancellationToken);

        // Removing the last role ends the membership.
        if (!await db.MembershipRoles.AnyAsync(r => r.PersonId == personId, cancellationToken))
        {
            db.Memberships.Remove(membership);
            await db.SaveChangesAsync(cancellationToken);
        }

        await scope.CommitAsync(cancellationToken);
        return Result.Success();
    }

    /// <summary>
    /// Serialises changes to the same person and to the same organization, so two admins cannot remove each
    /// other at the same moment and leave the organization without an admin.
    /// </summary>
    private async Task LockAsync(Guid personId, Guid organizationId, CancellationToken cancellationToken)
    {
        foreach (var key in new[] { $"person:{personId:N}", $"organization:{organizationId:N}" }.Order(StringComparer.Ordinal))
        {
            await db.Database.ExecuteSqlInterpolatedAsync(
                $"SELECT pg_advisory_xact_lock(hashtextextended({key}, 0))", cancellationToken);
        }
    }
}

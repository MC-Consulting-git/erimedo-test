using Erimedo.Modules.Identity.Contracts;
using Erimedo.Modules.Identity.Memberships;
using Erimedo.Modules.Identity.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Identity;

/// <summary>Entry point of the Identity module. Everything else in the module is internal.</summary>
public static class IdentityModule
{
    public const string ConnectionStringName = "Erimedo";

    /// <summary>Registers persistence, membership and authorization when the connection string "Erimedo" is configured.</summary>
    public static IServiceCollection AddIdentityModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString(ConnectionStringName);
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            return services;
        }

        services.AddDbContext<IdentityDbContext>(options => options.UseNpgsql(
            connectionString,
            npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", IdentityDbContext.Schema)));
        services.AddScoped<IPersonDirectory, PersonDirectory>();
        services.AddScoped<MembershipService>();
        services.AddScoped<IMembershipService>(sp => sp.GetRequiredService<MembershipService>());
        services.AddScoped<IMembershipAuthorizer>(sp => sp.GetRequiredService<MembershipService>());
        return services;
    }

    /// <summary>Applies the module's migrations. For development and tests; production uses a migration bundle.</summary>
    public static async Task MigrateDatabaseAsync(IServiceProvider services, CancellationToken cancellationToken)
    {
        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetService<IdentityDbContext>();
        if (db is not null)
        {
            await db.Database.MigrateAsync(cancellationToken);
        }
    }
}

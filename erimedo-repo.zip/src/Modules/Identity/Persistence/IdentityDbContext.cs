using Erimedo.Modules.Identity.Contracts;
using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Identity.Persistence;

internal sealed class PersonRow
{
    public Guid Id { get; set; }

    /// <summary>The identity provider's stable subject. Not a name or an e-mail address.</summary>
    public string ExternalSubject { get; set; } = null!;
    public DateTimeOffset CreatedAt { get; set; }
}

internal sealed class MembershipRow
{
    public Guid PersonId { get; set; }
    public Guid OrganizationId { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}

internal sealed class MembershipRoleRow
{
    public Guid PersonId { get; set; }
    public MembershipRole Role { get; set; }
}

internal sealed class IdentityDbContext(DbContextOptions<IdentityDbContext> options) : DbContext(options)
{
    public const string Schema = "identity";

    public DbSet<PersonRow> Persons => Set<PersonRow>();
    public DbSet<MembershipRow> Memberships => Set<MembershipRow>();
    public DbSet<MembershipRoleRow> MembershipRoles => Set<MembershipRoleRow>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);

        modelBuilder.Entity<PersonRow>(e =>
        {
            e.ToTable("persons");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.ExternalSubject).HasMaxLength(300).IsRequired();
            e.HasIndex(x => x.ExternalSubject).IsUnique();
        });

        modelBuilder.Entity<MembershipRow>(e =>
        {
            // The person id is the key, so a person can belong to at most one organization (ORG-01).
            e.ToTable("memberships");
            e.HasKey(x => x.PersonId);
            e.Property(x => x.PersonId).ValueGeneratedNever();
            e.HasIndex(x => x.OrganizationId);
            e.HasOne<PersonRow>().WithOne().HasForeignKey<MembershipRow>(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<MembershipRoleRow>(e =>
        {
            e.ToTable("membership_roles");
            e.HasKey(x => new { x.PersonId, x.Role });
            e.Property(x => x.Role).HasConversion<string>().HasMaxLength(30);
            e.HasOne<MembershipRow>().WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
        });
    }
}

/// <summary>Used only by the EF tools. Creating a migration does not connect to a database.</summary>
internal sealed class IdentityDbContextFactory : Microsoft.EntityFrameworkCore.Design.IDesignTimeDbContextFactory<IdentityDbContext>
{
    public IdentityDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("ERIMEDO_DB") ?? "Database=erimedo_design_time";
        var options = new DbContextOptionsBuilder<IdentityDbContext>()
            .UseNpgsql(connectionString, npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", IdentityDbContext.Schema))
            .Options;
        return new IdentityDbContext(options);
    }
}

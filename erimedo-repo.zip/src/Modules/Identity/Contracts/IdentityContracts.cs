using Erimedo.Shared;

namespace Erimedo.Modules.Identity.Contracts;

public enum MembershipRole
{
    CompanyAdmin,
    Consultant,
    Buyer,
}

/// <summary>
/// Maps a login identity from the identity provider to our own pseudonymous person id. No names or e-mail
/// addresses are stored here; the identity provider holds those.
/// </summary>
public interface IPersonDirectory
{
    /// <summary>Returns the person for the provider's stable subject, creating it on first sign-in.</summary>
    Task<Guid> GetOrCreatePersonAsync(string externalSubject, CancellationToken cancellationToken);
}

/// <summary>A person's place in one organization. A person belongs to at most one (ORG-01).</summary>
public sealed record Membership(Guid PersonId, Guid OrganizationId, IReadOnlyCollection<MembershipRole> Roles);

/// <summary>Proof, established on the server, that a person acts for an organization in a role.</summary>
public sealed record OrganizationAccess(Guid PersonId, Guid OrganizationId, MembershipRole Role);

/// <summary>
/// The server-side check behind every command that acts for an organization. Callers take the organization
/// from the result, never from the request (CLAUDE.md section 6).
/// </summary>
public interface IMembershipAuthorizer
{
    /// <summary>
    /// Succeeds only when the person is a member holding the role. A missing membership and a missing role
    /// give the same failure (<c>authorization.forbidden</c>), so the answer does not reveal which.
    /// </summary>
    Task<Result<OrganizationAccess>> RequireRoleAsync(Guid personId, MembershipRole role, CancellationToken cancellationToken);
}

/// <summary>
/// Changes who belongs to an organization. The caller must already have authorized the change: the person's
/// request was approved by a company admin, or the actor is an admin of that organization.
/// </summary>
public interface IMembershipService
{
    Task<Membership?> GetMembershipAsync(Guid personId, CancellationToken cancellationToken);

    /// <summary>Adds the role, creating the membership if needed. Fails if the person belongs to another organization.</summary>
    Task<Result> GrantRoleAsync(Guid personId, Guid organizationId, MembershipRole role, CancellationToken cancellationToken);

    /// <summary>
    /// Removes the role. The last company admin of an organization cannot be removed (ORG-02). Removing a
    /// person's last role ends the membership (ORG-03).
    /// </summary>
    Task<Result> RevokeRoleAsync(Guid personId, Guid organizationId, MembershipRole role, CancellationToken cancellationToken);
}

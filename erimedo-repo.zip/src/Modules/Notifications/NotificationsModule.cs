using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Notifications;

/// <summary>Entry point of the Notifications module. Everything else in the module is internal.</summary>
public static class NotificationsModule
{
    public static IServiceCollection AddNotificationsModule(this IServiceCollection services) => services;
}

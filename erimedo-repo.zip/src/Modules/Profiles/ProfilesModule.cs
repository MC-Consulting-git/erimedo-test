using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Profiles.Disclosure;
using Erimedo.Modules.Profiles.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Profiles;

/// <summary>Entry point of the Profiles module. Everything else in the module is internal.</summary>
public static class ProfilesModule
{
    public const string ConnectionStringName = "Erimedo";

    /// <summary>
    /// Registers persistence and the disclosure service when the connection string "Erimedo" is configured.
    /// The Host must also register an <see cref="IEntitlementLookup"/> that answers from the Wallet module.
    /// </summary>
    public static IServiceCollection AddProfilesModule(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString(ConnectionStringName);
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            return services;
        }

        services.AddDbContext<ProfilesDbContext>(options => options.UseNpgsql(
            connectionString,
            npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", ProfilesDbContext.Schema)));
        services.AddScoped<IContactDisclosureService, ContactDisclosureService>();
        services.AddScoped<IProfileCatalog, ProfileCatalog>();
        return services;
    }

    /// <summary>Applies the module's migrations. For development and tests; production uses a migration bundle.</summary>
    public static async Task MigrateDatabaseAsync(IServiceProvider services, CancellationToken cancellationToken)
    {
        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetService<ProfilesDbContext>();
        if (db is not null)
        {
            await db.Database.MigrateAsync(cancellationToken);
        }
    }
}

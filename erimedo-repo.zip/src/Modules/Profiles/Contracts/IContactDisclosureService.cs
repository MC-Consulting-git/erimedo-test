using Erimedo.Shared;

namespace Erimedo.Modules.Profiles.Contracts;

/// <summary>
/// The only way to read a consultant's contact details. The server checks the buyer organization's
/// entitlement and writes an audit record before anything is returned. Contact details must never be
/// part of a search result, a list DTO, a shared cache or client-side state (CLAUDE.md section 6).
/// The caller must have established the buyer's organization and role on the server; ids sent by the
/// client are never trusted for ownership.
/// </summary>
public interface IContactDisclosureService
{
    Task<Result<ContactDetails>> DiscloseAsync(DisclosureRequest request, CancellationToken cancellationToken);
}

public sealed record DisclosureRequest(Guid OrganizationId, Guid PersonId, Guid ConsultantProfileId);

/// <summary>Personal data. This is the only contract type that may carry it.</summary>
public sealed record ContactDetails(string FullName, string Email, string? Phone, DateTimeOffset AccessExpiresAt);

/// <summary>
/// What Profiles needs to know from outside: does this organization hold active access to this consultant?
/// Profiles does not know the Wallet module. The Host connects the two.
/// </summary>
public interface IEntitlementLookup
{
    Task<EntitlementProof?> FindActiveAsync(Guid organizationId, Guid consultantProfileId, CancellationToken cancellationToken);
}

public sealed record EntitlementProof(Guid EntitlementId, DateTimeOffset ExpiresAt);

/// <summary>Safe to show in lists and search results: contains no personal data.</summary>
public sealed record ProfileSummary(Guid ProfileId, int ConsultantNumber, bool IsPublished);

public interface IProfileCatalog
{
    Task<ProfileSummary?> GetSummaryAsync(Guid profileId, CancellationToken cancellationToken);
}

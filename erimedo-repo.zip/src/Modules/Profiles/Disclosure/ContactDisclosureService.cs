using Erimedo.Modules.Profiles.Contracts;
using Erimedo.Modules.Profiles.Persistence;
using Erimedo.Shared;
using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Profiles.Disclosure;

internal sealed class ContactDisclosureService(ProfilesDbContext db, IEntitlementLookup entitlements, TimeProvider time)
    : IContactDisclosureService
{
    public async Task<Result<ContactDetails>> DiscloseAsync(DisclosureRequest request, CancellationToken cancellationToken)
    {
        if (request is null
            || request.OrganizationId == Guid.Empty
            || request.PersonId == Guid.Empty
            || request.ConsultantProfileId == Guid.Empty)
        {
            return Result<ContactDetails>.Failure("disclosure.invalid_request", "Organization, person and consultant are required.");
        }

        // An unpublished profile is hidden from buyers, whatever they once bought. The same answer as for
        // an unknown id, so the response does not reveal which profiles exist.
        var profile = await db.Profiles.AsNoTracking()
            .SingleOrDefaultAsync(p => p.Id == request.ConsultantProfileId && p.IsPublished, cancellationToken);
        if (profile is null)
        {
            return Result<ContactDetails>.Failure("disclosure.not_found", "The consultant was not found.");
        }

        var proof = await entitlements.FindActiveAsync(request.OrganizationId, request.ConsultantProfileId, cancellationToken);
        if (proof is null)
        {
            return Result<ContactDetails>.Failure("disclosure.no_entitlement", "The organization has no active access to this consultant.");
        }

        // The audit record is saved before the details leave this method. If saving fails, nothing is disclosed.
        db.DisclosureAudit.Add(new DisclosureAuditRow
        {
            Id = Guid.NewGuid(),
            ConsultantProfileId = request.ConsultantProfileId,
            OrganizationId = request.OrganizationId,
            PersonId = request.PersonId,
            EntitlementId = proof.EntitlementId,
            Kind = ProfilesDbContext.ContactKind,
            DisclosedAt = time.GetUtcNow().ToUniversalTime(),
        });
        await db.SaveChangesAsync(cancellationToken);

        return Result<ContactDetails>.Success(
            new ContactDetails(profile.ContactFullName, profile.ContactEmail, profile.ContactPhone, proof.ExpiresAt));
    }
}

internal sealed class ProfileCatalog(ProfilesDbContext db) : IProfileCatalog
{
    public async Task<ProfileSummary?> GetSummaryAsync(Guid profileId, CancellationToken cancellationToken)
    {
        // Selects only the columns that are safe to show. The contact columns are never read here.
        return await db.Profiles.AsNoTracking()
            .Where(p => p.Id == profileId)
            .Select(p => new ProfileSummary(p.Id, p.ConsultantNumber, p.IsPublished))
            .SingleOrDefaultAsync(cancellationToken);
    }
}

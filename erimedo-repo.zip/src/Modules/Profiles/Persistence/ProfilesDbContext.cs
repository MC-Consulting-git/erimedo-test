using Microsoft.EntityFrameworkCore;

namespace Erimedo.Modules.Profiles.Persistence;

internal sealed class ProfileRow
{
    public Guid Id { get; set; }

    /// <summary>The stable number buyers see before purchase instead of a name (ADR-0006).</summary>
    public int ConsultantNumber { get; set; }
    public bool IsPublished { get; set; }

    // Personal data. Only ContactDisclosureService reads these columns.
    public string ContactFullName { get; set; } = null!;
    public string ContactEmail { get; set; } = null!;
    public string? ContactPhone { get; set; }
}

/// <summary>Who saw what, when and under which entitlement. Holds ids only, never personal data.</summary>
internal sealed class DisclosureAuditRow
{
    public Guid Id { get; set; }
    public Guid ConsultantProfileId { get; set; }
    public Guid OrganizationId { get; set; }
    public Guid PersonId { get; set; }
    public Guid EntitlementId { get; set; }
    public string Kind { get; set; } = null!;
    public DateTimeOffset DisclosedAt { get; set; }
}

internal sealed class ProfilesDbContext(DbContextOptions<ProfilesDbContext> options) : DbContext(options)
{
    public const string Schema = "profiles";
    public const string ContactKind = "contact";

    public DbSet<ProfileRow> Profiles => Set<ProfileRow>();
    public DbSet<DisclosureAuditRow> DisclosureAudit => Set<DisclosureAuditRow>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(Schema);

        modelBuilder.Entity<ProfileRow>(e =>
        {
            e.ToTable("consultant_profiles");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.ConsultantNumber).UseIdentityByDefaultColumn();
            e.HasIndex(x => x.ConsultantNumber).IsUnique();
            e.Property(x => x.ContactFullName).HasMaxLength(200).IsRequired();
            e.Property(x => x.ContactEmail).HasMaxLength(320).IsRequired();
            e.Property(x => x.ContactPhone).HasMaxLength(50);
        });

        modelBuilder.Entity<DisclosureAuditRow>(e =>
        {
            // No foreign key to the profile on purpose: the audit trail is kept 2 years (ADR-0003),
            // longer than the profile, which is deleted within 30 days of account deletion.
            e.ToTable("disclosure_audit");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.Kind).HasMaxLength(30).IsRequired();
            e.HasIndex(x => new { x.ConsultantProfileId, x.DisclosedAt });
            e.HasIndex(x => new { x.OrganizationId, x.DisclosedAt });
        });
    }
}

/// <summary>Used only by the EF tools. Creating a migration does not connect to a database.</summary>
internal sealed class ProfilesDbContextFactory : Microsoft.EntityFrameworkCore.Design.IDesignTimeDbContextFactory<ProfilesDbContext>
{
    public ProfilesDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("ERIMEDO_DB") ?? "Database=erimedo_design_time";
        var options = new DbContextOptionsBuilder<ProfilesDbContext>()
            .UseNpgsql(connectionString, npgsql => npgsql.MigrationsHistoryTable("__ef_migrations", ProfilesDbContext.Schema))
            .Options;
        return new ProfilesDbContext(options);
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Erimedo.Modules.Profiles.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class InitialProfiles : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "profiles");

            migrationBuilder.CreateTable(
                name: "consultant_profiles",
                schema: "profiles",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    ConsultantNumber = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    IsPublished = table.Column<bool>(type: "boolean", nullable: false),
                    ContactFullName = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    ContactEmail = table.Column<string>(type: "character varying(320)", maxLength: 320, nullable: false),
                    ContactPhone = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_consultant_profiles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "disclosure_audit",
                schema: "profiles",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    ConsultantProfileId = table.Column<Guid>(type: "uuid", nullable: false),
                    OrganizationId = table.Column<Guid>(type: "uuid", nullable: false),
                    PersonId = table.Column<Guid>(type: "uuid", nullable: false),
                    EntitlementId = table.Column<Guid>(type: "uuid", nullable: false),
                    Kind = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false),
                    DisclosedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_disclosure_audit", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_consultant_profiles_ConsultantNumber",
                schema: "profiles",
                table: "consultant_profiles",
                column: "ConsultantNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_disclosure_audit_ConsultantProfileId_DisclosedAt",
                schema: "profiles",
                table: "disclosure_audit",
                columns: new[] { "ConsultantProfileId", "DisclosedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_disclosure_audit_OrganizationId_DisclosedAt",
                schema: "profiles",
                table: "disclosure_audit",
                columns: new[] { "OrganizationId", "DisclosedAt" });

            // The audit trail cannot be edited. Rows may be deleted only after the 2 year retention in
            // ADR-0003, so a retention job can clean up but nobody can erase recent disclosures.
            migrationBuilder.Sql(@"
CREATE FUNCTION profiles.guard_disclosure_audit() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'DELETE' AND OLD.""DisclosedAt"" < now() - interval '2 years' THEN
        RETURN OLD;
    END IF;
    RAISE EXCEPTION 'The disclosure audit is append-only: % on % is not allowed', TG_OP, TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER disclosure_audit_rows BEFORE UPDATE OR DELETE ON profiles.disclosure_audit
    FOR EACH ROW EXECUTE FUNCTION profiles.guard_disclosure_audit();
CREATE TRIGGER disclosure_audit_truncate BEFORE TRUNCATE ON profiles.disclosure_audit
    FOR EACH STATEMENT EXECUTE FUNCTION profiles.guard_disclosure_audit();");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "consultant_profiles",
                schema: "profiles");

            migrationBuilder.DropTable(
                name: "disclosure_audit",
                schema: "profiles");
            migrationBuilder.Sql("DROP FUNCTION IF EXISTS profiles.guard_disclosure_audit();");
        }
    }
}

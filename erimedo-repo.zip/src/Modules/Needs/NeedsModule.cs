using Microsoft.Extensions.DependencyInjection;

namespace Erimedo.Modules.Needs;

/// <summary>Entry point of the Needs module. Everything else in the module is internal.</summary>
public static class NeedsModule
{
    public static IServiceCollection AddNeedsModule(this IServiceCollection services) => services;
}
